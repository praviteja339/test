import { useState } from "react";
import {
  Box, Typography, TextField, Button, InputAdornment,
  Alert, CircularProgress, Snackbar
} from "@mui/material";
import LockIcon from "@mui/icons-material/Lock";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";
import { C, cardStyle, inputStyle, btnPrimary } from "./lightStyles";

export default function SDMPin() {
  const [form, setForm] = useState({
    currentMPin: "",
    newMPin: "",
    confirmMPin: "",
  });
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState("");
  const [snackbar, setSnackbar] = useState({ open: false, message: "" });

  const handleChange = (field) => (e) => {
    // allow only digits
    const val = e.target.value.replace(/\D/g, "");
    setForm((prev) => ({ ...prev, [field]: val }));
  };

  const handleSubmit = async () => {
    setError("");

    // ── validation ──
    if (!form.currentMPin || !form.newMPin || !form.confirmMPin) {
      setError("All fields are required.");
      return;
    }
    if (form.newMPin.length < 4 || form.newMPin.length > 6) {
      setError("New M-Pin must be 4–6 digits.");
      return;
    }
    if (form.newMPin !== form.confirmMPin) {
      setError("New M-Pin and confirmation do not match.");
      return;
    }

    // ── read userId & token from localStorage ──
    const userId = localStorage.getItem("userId");
    const token  = localStorage.getItem("token");

    if (!userId || !token) {
      setError("Session expired. Please log in again.");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(
        `https://slabpay.azurewebsites.net/api/v1/users/${userId}/mpin`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            oldMPin: form.currentMPin,
            newMPin: form.newMPin,
          }),
        }
      );

      const data = await response.json();

      if (response.ok && data.success) {
        setSnackbar({ open: true, message: data.message || "MPin changed successfully" });
        setForm({ currentMPin: "", newMPin: "", confirmMPin: "" });
      } else {
        setError(data.message || "Failed to update M-Pin. Please try again.");
      }
    } catch (err) {
      setError("Network error. Please check your connection and try again.");
    } finally {
      setLoading(false);
    }
  };

  const fields = [
    { label: "Current M-Pin", field: "currentMPin" },
    { label: "New M-Pin",     field: "newMPin" },
    { label: "Re-Enter M-Pin", field: "confirmMPin" },
  ];

  return (
    <Box sx={{ p: 4 }}>
      {/* header banner */}
      <Box sx={{ background: "linear-gradient(135deg,#ede9fe,#f5f3ff)", borderRadius: "14px", px: 3, py: 1.5, mb: 3, borderLeft: "4px solid #7c3aed" }}>
        <Typography sx={{ fontSize: 11, fontWeight: 700, letterSpacing: "2px", textTransform: "uppercase", color: "#7c3aed" }}>
          Super Distributor — Slabpay
        </Typography>
      </Box>

      <Typography sx={{ fontSize: 22, fontWeight: 800, mb: 3, color: C.text1 }}>
        Change M-Pin
      </Typography>

      <Box sx={{ ...cardStyle, maxWidth: 640 }}>
        {/* icon + hint */}
        <Box sx={{ mb: 2.5 }}>
          <Box sx={{ width: 48, height: 48, borderRadius: "14px", background: "#fef3c7", display: "flex", alignItems: "center", justifyContent: "center", mb: 2, fontSize: 22 }}>
            🔑
          </Box>
          <Typography sx={{ fontSize: 14, color: C.text2, lineHeight: 1.6 }}>
            Your M-Pin is a 4–6 digit numeric PIN used for quick transaction authentication.
          </Typography>
        </Box>

        {/* error alert */}
        {error && (
          <Alert severity="error" sx={{ mb: 2, borderRadius: "10px" }} onClose={() => setError("")}>
            {error}
          </Alert>
        )}

        {/* fields */}
        <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", md: "1fr 1fr" }, gap: 2 }}>
          {fields.map(({ label, field }) => (
            <TextField
              key={field}
              label={label}
              type="password"
              inputProps={{ maxLength: 6, inputMode: "numeric" }}
              fullWidth
              value={form[field]}
              onChange={handleChange(field)}
              sx={inputStyle}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <LockIcon sx={{ color: C.text3, fontSize: 18 }} />
                  </InputAdornment>
                ),
              }}
            />
          ))}
        </Box>

        {/* submit */}
        <Box sx={{ mt: 3, display: "flex", justifyContent: "flex-end" }}>
          <Button
            onClick={handleSubmit}
            disabled={loading}
            sx={{
              ...btnPrimary,
              height: "42px",
              px: 4,
              background: "linear-gradient(135deg,#7c3aed,#6d28d9)",
              boxShadow: "0 4px 12px rgba(124,58,237,0.3)",
              "&:hover": { boxShadow: "0 6px 16px rgba(124,58,237,0.4)" },
              "&.Mui-disabled": { background: "#c4b5fd", color: "#fff" },
            }}
          >
            {loading ? <CircularProgress size={20} sx={{ color: "#fff" }} /> : "Update M-Pin"}
          </Button>
        </Box>
      </Box>

      {/* success snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() => setSnackbar({ open: false, message: "" })}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        <Alert
          icon={<CheckCircleOutlineIcon fontSize="inherit" />}
          severity="success"
          sx={{ borderRadius: "10px", fontWeight: 600 }}
          onClose={() => setSnackbar({ open: false, message: "" })}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}