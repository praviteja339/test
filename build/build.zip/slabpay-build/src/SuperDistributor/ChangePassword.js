import { useState } from "react";
import {
  Box, Typography, TextField, Button, InputAdornment,
  Alert, CircularProgress, Snackbar
} from "@mui/material";
import LockIcon from "@mui/icons-material/Lock";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";

// ── paste your actual shared style imports here ──
const C = { text1: "#1e1b4b", text2: "#6b7280", text3: "#9ca3af" };
const cardStyle = { background: "#fff", borderRadius: "16px", p: 3, boxShadow: "0 2px 16px rgba(124,58,237,0.08)" };
const inputStyle = {
  "& .MuiOutlinedInput-root": {
    borderRadius: "10px",
    "& fieldset": { borderColor: "#e5e7eb" },
    "&:hover fieldset": { borderColor: "#7c3aed" },
    "&.Mui-focused fieldset": { borderColor: "#7c3aed" },
  },
  "& .MuiInputLabel-root.Mui-focused": { color: "#7c3aed" },
};
const btnPrimary = {
  borderRadius: "10px", fontWeight: 700, fontSize: 14,
  textTransform: "none", color: "#fff",
};
// ─────────────────────────────────────────────────

export default function SDChangePassword() {
  const [form, setForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError]   = useState("");
  const [snackbar, setSnackbar] = useState({ open: false, message: "" });

  const handleChange = (field) => (e) =>
    setForm((prev) => ({ ...prev, [field]: e.target.value }));

  const handleSubmit = async () => {
    setError("");

    // ── client-side validation ──
    if (!form.currentPassword || !form.newPassword || !form.confirmPassword) {
      setError("All fields are required.");
      return;
    }
    if (form.newPassword.length < 8) {
      setError("New password must be at least 8 characters.");
      return;
    }
    if (form.newPassword !== form.confirmPassword) {
      setError("New password and confirmation do not match.");
      return;
    }

    // ── read userId & token from localStorage ──
    const userId = localStorage.getItem("userId");
    const token  = localStorage.getItem("token");

    if (!userId || !token) {
      setError("Session expired. Please log in again.");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(
        `https://slabpay.azurewebsites.net/api/v1/users/${userId}/password`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            oldPassword: form.currentPassword,
            newPassword: form.newPassword,
          }),
        }
      );

      const data = await response.json();

      if (response.ok && data.success) {
        // ── success ──
        setSnackbar({ open: true, message: data.message || "Password changed successfully" });
        setForm({ currentPassword: "", newPassword: "", confirmPassword: "" });
      } else {
        // ── server-side error ──
        setError(data.message || "Failed to change password. Please try again.");
      }
    } catch (err) {
      setError("Network error. Please check your connection and try again.");
    } finally {
      setLoading(false);
    }
  };

  const fields = [
    { label: "Current Password", field: "currentPassword" },
    { label: "New Password",     field: "newPassword" },
    { label: "Re-Enter New Password", field: "confirmPassword" },
  ];

  return (
    <Box sx={{ p: 4 }}>
      {/* header banner */}
      <Box sx={{ background: "linear-gradient(135deg,#ede9fe,#f5f3ff)", borderRadius: "14px", px: 3, py: 1.5, mb: 3, borderLeft: "4px solid #7c3aed" }}>
        <Typography sx={{ fontSize: 11, fontWeight: 700, letterSpacing: "2px", textTransform: "uppercase", color: "#7c3aed" }}>
          Super Distributor — Slabpay
        </Typography>
      </Box>

      <Typography sx={{ fontSize: 22, fontWeight: 800, mb: 3, color: C.text1 }}>
        Change Password
      </Typography>

      <Box sx={{ ...cardStyle, maxWidth: 640 }}>
        {/* icon + hint */}
        <Box sx={{ mb: 2.5 }}>
          <Box sx={{ width: 48, height: 48, borderRadius: "14px", background: "#ede9fe", display: "flex", alignItems: "center", justifyContent: "center", mb: 2 }}>
            <LockIcon sx={{ color: "#7c3aed", fontSize: 24 }} />
          </Box>
          <Typography sx={{ fontSize: 14, color: C.text2, lineHeight: 1.6 }}>
            Password must be at least 8 characters with a mix of letters and numbers.
          </Typography>
        </Box>

        {/* error alert */}
        {error && (
          <Alert severity="error" sx={{ mb: 2, borderRadius: "10px" }} onClose={() => setError("")}>
            {error}
          </Alert>
        )}

        {/* fields */}
        <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", md: "1fr 1fr" }, gap: 2 }}>
          {fields.map(({ label, field }) => (
            <TextField
              key={field}
              label={label}
              type="password"
              fullWidth
              value={form[field]}
              onChange={handleChange(field)}
              sx={inputStyle}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <LockIcon sx={{ color: C.text3, fontSize: 18 }} />
                  </InputAdornment>
                ),
              }}
            />
          ))}
        </Box>

        {/* submit */}
        <Box sx={{ mt: 3, display: "flex", justifyContent: "flex-end" }}>
          <Button
            onClick={handleSubmit}
            disabled={loading}
            sx={{
              ...btnPrimary,
              height: "42px",
              px: 4,
              background: "linear-gradient(135deg,#7c3aed,#6d28d9)",
              boxShadow: "0 4px 12px rgba(124,58,237,0.3)",
              "&:hover": { boxShadow: "0 6px 16px rgba(124,58,237,0.4)" },
              "&.Mui-disabled": { background: "#c4b5fd", color: "#fff" },
            }}
          >
            {loading ? <CircularProgress size={20} sx={{ color: "#fff" }} /> : "Change Password"}
          </Button>
        </Box>
      </Box>

      {/* success snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() => setSnackbar({ open: false, message: "" })}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        <Alert
          icon={<CheckCircleOutlineIcon fontSize="inherit" />}
          severity="success"
          sx={{ borderRadius: "10px", fontWeight: 600 }}
          onClose={() => setSnackbar({ open: false, message: "" })}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}