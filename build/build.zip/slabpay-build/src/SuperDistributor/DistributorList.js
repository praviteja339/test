import { Box, Typography, TextField, Button, Paper, Chip, Dialog, DialogTitle, DialogContent, DialogActions, CircularProgress, Alert, Snackbar } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import AddIcon from "@mui/icons-material/Add";
import DownloadIcon from "@mui/icons-material/Download";
import CloseIcon from "@mui/icons-material/Close";
import { useState, useEffect } from "react";
import { C, cardStyle, inputStyle, btnPrimary, btnOutline, tableHeader } from "./lightStyles";

const BASE_URL = "https://slabpay.azurewebsites.net";

function getFromStorage(key) {
  return localStorage.getItem(key);
}

const defaultForm = {
  userName: "",
  registeredMobileNo: "",
  password: "",
  company: "",
  area: "",
  city: "",
  pincode: "",
  gstStateCode: "",
  emailId: "",
  roleId: 3,
  mpin: "",
};

export default function SDDistributorList() {
  const [distributors, setDistributors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState("");

  // Modal state
  const [openModal, setOpenModal] = useState(false);
  const [form, setForm] = useState(defaultForm);
  const [formLoading, setFormLoading] = useState(false);
  const [formError, setFormError] = useState(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: "", severity: "success" });

  const userId = getFromStorage("userId");
  const token = getFromStorage("token");

  // Fetch distributors on mount
  useEffect(() => {
    fetchDistributors();
  }, []);

  async function fetchDistributors() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`${BASE_URL}/api/v1/users/superdist/${userId}/distributors`, {
        method: "GET",
        headers: {
          "accept": "*/*",
          "Authorization": `Bearer ${token}`,
        },
      });
      const data = await res.json();
      if (data.success) {
        setDistributors(data.data);
      } else {
        setError("Failed to fetch distributors.");
      }
    } catch (err) {
      setError("Network error: " + err.message);
    } finally {
      setLoading(false);
    }
  }

  // Add Distributor
  async function handleAddDistributor() {
    setFormLoading(true);
    setFormError(null);
    const creatorId = getFromStorage("userId");
    try {
      const res = await fetch(`${BASE_URL}/__api__/users/distributor?creatorId=${creatorId}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`,
        },
        body: JSON.stringify({
          ...form,
          roleId: Number(form.roleId),
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSnackbar({ open: true, message: "Distributor created successfully!", severity: "success" });
        setOpenModal(false);
        setForm(defaultForm);
        fetchDistributors(); // refresh list
      } else {
        setFormError(data.message || "Failed to create distributor.");
      }
    } catch (err) {
      setFormError("Network error: " + err.message);
    } finally {
      setFormLoading(false);
    }
  }

  function handleFormChange(e) {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  }

  const filtered = distributors.filter(d =>
    d.userName?.toLowerCase().includes(search.toLowerCase()) ||
    d.registeredMobileNo?.includes(search) ||
    d.company?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <Box sx={{ p: 3 }}>
      {/* Header Banner */}
      <Box sx={{ background: "linear-gradient(135deg,#ede9fe,#f5f3ff)", borderRadius: "14px", px: 3, py: 1.5, mb: 2, borderLeft: "4px solid #7c3aed", display: "flex", alignItems: "center" }}>
        <Typography sx={{ fontSize: 11, fontWeight: 700, letterSpacing: "2px", textTransform: "uppercase", color: "#7c3aed" }}>
          Super Distributor — Slabpay
        </Typography>
      </Box>

      <Typography sx={{ fontSize: 20, fontWeight: 800, mb: 3, color: C.text1 }}>Distributor List</Typography>

      <Paper sx={cardStyle}>
        {/* Toolbar */}
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2.5 }}>
          <TextField
            size="small"
            placeholder="Search distributor..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            sx={{ ...inputStyle, width: 240 }}
            InputProps={{ startAdornment: <SearchIcon sx={{ color: C.text3, fontSize: 18, mr: 0.5 }} /> }}
          />
          <Box sx={{ display: "flex", gap: 1 }}>
            <Button startIcon={<AddIcon />} sx={btnPrimary} onClick={() => { setOpenModal(true); setFormError(null); setForm(defaultForm); }}>
              Add Distributor
            </Button>
            <Button startIcon={<DownloadIcon />} sx={btnOutline}>Export</Button>
          </Box>
        </Box>

        {/* Error */}
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

        {/* Table Header */}
        <Box sx={{ ...tableHeader, gridTemplateColumns: "80px 1fr 1fr 130px 120px 100px 100px" }}>
          {["ID", "Username", "Company", "Mobile", "Balance", "Status", "Actions"].map(h => <span key={h}>{h}</span>)}
        </Box>

        {/* Loading */}
        {loading ? (
          <Box sx={{ display: "flex", justifyContent: "center", py: 5 }}>
            <CircularProgress size={32} sx={{ color: "#7c3aed" }} />
          </Box>
        ) : filtered.length === 0 ? (
          <Typography sx={{ textAlign: "center", py: 5, color: C.text3, fontSize: 13 }}>No distributors found.</Typography>
        ) : filtered.map((d, i) => (
          <Box
            key={d.id}
            sx={{
              display: "grid",
              gridTemplateColumns: "80px 1fr 1fr 130px 120px 100px 100px",
              alignItems: "center",
              py: 2,
              px: 0.5,
              borderBottom: i < filtered.length - 1 ? `1px solid ${C.border}` : "none",
              "&:hover": { background: C.surface2 },
              borderRadius: "8px",
              transition: "background 0.15s",
            }}
          >
            <Typography sx={{ fontSize: 12, fontWeight: 700, color: "#7c3aed" }}>D-{d.id}</Typography>
            <Box>
              <Typography sx={{ fontSize: 13, fontWeight: 600, color: C.text1 }}>{d.userName}</Typography>
              <Typography sx={{ fontSize: 11, color: C.text3 }}>{d.emailId}</Typography>
            </Box>
            <Typography sx={{ fontSize: 12, color: C.text2 }}>{d.company}</Typography>
            <Typography sx={{ fontSize: 12, color: C.text3 }}>{d.registeredMobileNo}</Typography>
            <Typography sx={{ fontSize: 13, fontWeight: 700, color: d.balance > 100 ? C.secondary : C.danger }}>
              ₹{(d.balance ?? 0).toFixed(2)}
            </Typography>
            <Chip
              label={d.isLocked ? "Locked" : "Active"}
              size="small"
              sx={{
                background: d.isLocked ? C.dangerLight : C.secondaryLight,
                color: d.isLocked ? C.danger : C.secondary,
                fontWeight: 700,
                fontSize: 11,
              }}
            />
            <Button size="small" sx={{ color: C.primary, fontSize: 12, fontWeight: 700, textTransform: "none", minWidth: 0 }}>View</Button>
          </Box>
        ))}
      </Paper>

      {/* Add Distributor Modal */}
      <Dialog open={openModal} onClose={() => setOpenModal(false)} maxWidth="sm" fullWidth PaperProps={{ sx: { borderRadius: "16px" } }}>
        <DialogTitle sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontWeight: 800, fontSize: 17 }}>
          Add Distributor
          <Button onClick={() => setOpenModal(false)} sx={{ minWidth: 0, color: C.text3 }}><CloseIcon fontSize="small" /></Button>
        </DialogTitle>
        <DialogContent dividers>
          {formError && <Alert severity="error" sx={{ mb: 2 }}>{formError}</Alert>}
          <Box sx={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 2, mt: 1 }}>
            {[
              { label: "Username", name: "userName" },
              { label: "Mobile No.", name: "registeredMobileNo" },
              { label: "Password", name: "password", type: "password" },
              { label: "MPIN", name: "mpin", type: "password" },
              { label: "Company", name: "company" },
              { label: "Email ID", name: "emailId", type: "email" },
              { label: "Area", name: "area" },
              { label: "City", name: "city" },
              { label: "Pincode", name: "pincode" },
              { label: "GST State Code", name: "gstStateCode" },
            ].map(({ label, name, type }) => (
              <TextField
                key={name}
                label={label}
                name={name}
                type={type || "text"}
                size="small"
                value={form[name]}
                onChange={handleFormChange}
                fullWidth
                sx={inputStyle}
              />
            ))}
          </Box>
        </DialogContent>
        <DialogActions sx={{ px: 3, py: 2 }}>
          <Button onClick={() => setOpenModal(false)} sx={btnOutline}>Cancel</Button>
          <Button
            onClick={handleAddDistributor}
            disabled={formLoading}
            sx={btnPrimary}
            startIcon={formLoading ? <CircularProgress size={16} color="inherit" /> : <AddIcon />}
          >
            {formLoading ? "Creating..." : "Create Distributor"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Success Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() => setSnackbar(s => ({ ...s, open: false }))}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert severity={snackbar.severity} sx={{ fontWeight: 600 }}>{snackbar.message}</Alert>
      </Snackbar>
    </Box>
  );
}