import { Box, Typography, TextField, Button, Paper, Chip, CircularProgress, Dialog, DialogTitle, DialogContent, DialogActions, IconButton, Alert, Snackbar, Grid } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import DownloadIcon from "@mui/icons-material/Download";
import AddIcon from "@mui/icons-material/Add";
import CloseIcon from "@mui/icons-material/Close";
import RefreshIcon from "@mui/icons-material/Refresh";
import { useState, useEffect } from "react";
import { C, cardStyle, inputStyle, btnPrimary, btnOutline, tableHeader } from "./lightStyles";

// ─── helpers ────────────────────────────────────────────────────────────────
const getLocal = (key) => localStorage.getItem(key) || "";

const EMPTY_FORM = {
  userName: "",
  registeredMobileNo: "",
  password: "",
  company: "",
  area: "",
  city: "",
  pincode: "",
  gstStateCode: "",
  emailId: "",
  distributorId: "",
  superDistId: "",
  roleId: 4,
  utype: "R",
  mpin: "",
};

// ─── field config ─────────────────────────────────────────────────────────
const FIELDS = [
  { id: "userName",            label: "Username",        required: true,  half: true  },
  { id: "registeredMobileNo",  label: "Mobile No.",      required: true,  half: true  },
  { id: "password",            label: "Password",        required: true,  half: true, type: "password" },
  { id: "mpin",                label: "MPIN",            required: true,  half: true, type: "password" },
  { id: "emailId",             label: "Email ID",        required: true,  half: false },
  { id: "company",             label: "Company",         required: false, half: true  },
  { id: "area",                label: "Area",            required: false, half: true  },
  { id: "city",                label: "City",            required: false, half: true  },
  { id: "pincode",             label: "Pincode",         required: false, half: true  },
  { id: "gstStateCode",        label: "GST State Code",  required: false, half: true  },
  { id: "distributorId",       label: "Distributor ID",  required: false, half: true  },
  { id: "superDistId",         label: "Super Dist. ID",  required: false, half: true  },
];

export default function SDRetailerList() {
  const superDistId = getLocal("userId");
  const token       = getLocal("token");
  const userName    = getLocal("userName");
  const roleName    = getLocal("roleName");

  // list state
  const [retailers, setRetailers]   = useState([]);
  const [loading, setLoading]       = useState(false);
  const [listError, setListError]   = useState("");
  const [search, setSearch]         = useState("");

  // modal state
  const [open, setOpen]             = useState(false);
  const [form, setForm]             = useState(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError]   = useState("");
  const [response, setResponse]     = useState(null);

  // snackbar
  const [snack, setSnack]           = useState({ open: false, msg: "", severity: "success" });

  // ── fetch retailers ────────────────────────────────────────────────────
  const fetchRetailers = async () => {
    if (!superDistId || !token) { setListError("Session missing. Please log in."); return; }
    setLoading(true);
    setListError("");
    try {
      const res = await fetch(
        `https://slabpay.azurewebsites.net/api/v1/users/superdist/${superDistId}/retailers`,
        { headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" } }
      );
      const data = await res.json();
      if (data.success) setRetailers(data.data || []);
      else setListError(data.message || "Failed to load retailers.");
    } catch (e) {
      setListError(`Network error: ${e.message}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchRetailers(); }, []);

  // ── form handlers ──────────────────────────────────────────────────────
  const handleChange = (e) => setForm(f => ({ ...f, [e.target.name]: e.target.value }));

  const handleOpen = () => {
    setForm({ ...EMPTY_FORM, superDistId: superDistId });
    setFormError("");
    setResponse(null);
    setOpen(true);
  };

  const handleClose = () => { if (!submitting) { setOpen(false); setResponse(null); setFormError(""); } };

  const handleSubmit = async () => {
    // validate required
    const missing = FIELDS.filter(f => f.required && !form[f.id]?.toString().trim());
    if (missing.length) { setFormError(`Required: ${missing.map(f => f.label).join(", ")}`); return; }
    setFormError("");
    setSubmitting(true);
    setResponse(null);

    const payload = {
      ...form,
      roleId:        Number(form.roleId)        || 4,
      distributorId: Number(form.distributorId) || undefined,
      superDistId:   Number(form.superDistId)   || Number(superDistId),
    };

    try {
      const res = await fetch("https://slabpay.azurewebsites.net/api/v1/users", {
        method:  "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body:    JSON.stringify(payload),
      });
      const data = await res.json();
      setResponse(data);
      if (data.success) {
        setSnack({ open: true, msg: `Retailer "${data.data?.userName}" created successfully!`, severity: "success" });
        fetchRetailers();
      } else {
        setFormError(data.message || "Creation failed.");
      }
    } catch (e) {
      setFormError(`Request failed: ${e.message}`);
    } finally {
      setSubmitting(false);
    }
  };

  // ── filtered list ──────────────────────────────────────────────────────
  const filtered = retailers.filter(r =>
    [r.userName, r.registeredMobileNo, r.emailId, r.company, r.city]
      .some(v => v?.toLowerCase().includes(search.toLowerCase()))
  );

  // ── export CSV ─────────────────────────────────────────────────────────
  const exportCSV = () => {
    const cols = ["id","userName","registeredMobileNo","emailId","company","city","balance","isKYC","roleId"];
    const rows = [cols.join(","), ...filtered.map(r => cols.map(c => `"${r[c] ?? ""}"`).join(","))];
    const blob = new Blob([rows.join("\n")], { type: "text/csv" });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a"); a.href = url; a.download = "retailers.csv"; a.click();
  };

  // ── render ─────────────────────────────────────────────────────────────
  return (
    <Box sx={{ p: 3 }}>
      {/* Header banner */}
      <Box sx={{ background: "linear-gradient(135deg,#ede9fe,#f5f3ff)", borderRadius: "14px", px: 3, py: 1.5, mb: 2, borderLeft: "4px solid #7c3aed", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <Typography sx={{ fontSize: 11, fontWeight: 700, letterSpacing: "2px", textTransform: "uppercase", color: "#7c3aed" }}>
          {roleName} — {userName}
        </Typography>
        <Typography sx={{ fontSize: 11, color: "#7c3aed", fontWeight: 600 }}>ID: {superDistId}</Typography>
      </Box>

      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 3 }}>
        <Typography sx={{ fontSize: 20, fontWeight: 800, color: C.text1 }}>Retailers</Typography>
        <Box sx={{ display: "flex", gap: 1 }}>
          <Button startIcon={<RefreshIcon />} onClick={fetchRetailers} sx={btnOutline} size="small">Refresh</Button>
          <Button startIcon={<AddIcon />} onClick={handleOpen}
            sx={{ ...btnPrimary, background: "#7c3aed", "&:hover": { background: "#6d28d9" } }}>
            Add Retailer
          </Button>
        </Box>
      </Box>

      <Paper sx={cardStyle}>
        {/* Toolbar */}
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2.5 }}>
          <TextField size="small" placeholder="Search retailer..." value={search} onChange={e => setSearch(e.target.value)}
            sx={{ ...inputStyle, width: 240 }}
            InputProps={{ startAdornment: <SearchIcon sx={{ color: C.text3, fontSize: 18, mr: 0.5 }} /> }} />
          <Button startIcon={<DownloadIcon />} onClick={exportCSV} sx={btnOutline}>Export</Button>
        </Box>

        {/* Error */}
        {listError && <Alert severity="error" sx={{ mb: 2 }}>{listError}</Alert>}

        {/* Loading */}
        {loading ? (
          <Box sx={{ display: "flex", justifyContent: "center", py: 6 }}>
            <CircularProgress size={32} sx={{ color: "#7c3aed" }} />
          </Box>
        ) : (
          <>
            {/* Table header */}
            <Box sx={{ ...tableHeader, gridTemplateColumns: "80px 140px 1fr 130px 110px 90px 90px" }}>
              {["ID", "Username", "Email", "Mobile", "Company", "Status", "Actions"].map(h => <span key={h}>{h}</span>)}
            </Box>

            {/* Rows */}
            {filtered.length === 0 ? (
              <Box sx={{ py: 6, textAlign: "center" }}>
                <Typography sx={{ color: C.text3, fontSize: 14 }}>No retailers found.</Typography>
              </Box>
            ) : filtered.map((r, i) => (
              <Box key={r.id} sx={{
                display: "grid",
                gridTemplateColumns: "80px 140px 1fr 130px 110px 90px 90px",
                alignItems: "center", py: 2, px: 0.5,
                borderBottom: i < filtered.length - 1 ? `1px solid ${C.border}` : "none",
                "&:hover": { background: C.surface2 },
                borderRadius: "8px", transition: "background 0.15s"
              }}>
                <Typography sx={{ fontSize: 12, fontWeight: 700, color: "#7c3aed" }}>#{r.id}</Typography>
                <Typography sx={{ fontSize: 13, fontWeight: 600, color: C.text1 }}>{r.userName}</Typography>
                <Typography sx={{ fontSize: 12, color: C.text3 }}>{r.emailId}</Typography>
                <Typography sx={{ fontSize: 12, color: C.text3 }}>{r.registeredMobileNo}</Typography>
                <Typography sx={{ fontSize: 12, color: C.text2 }}>{r.company || "—"}</Typography>
                <Chip
                  label={r.isLocked ? "Locked" : "Active"}
                  size="small"
                  sx={{
                    background: r.isLocked ? C.dangerLight  : C.secondaryLight,
                    color:      r.isLocked ? C.danger       : C.secondary,
                    fontWeight: 700, fontSize: 11
                  }}
                />
                <Button size="small" sx={{ color: "#7c3aed", fontSize: 12, fontWeight: 700, textTransform: "none", minWidth: 0 }}>
                  View
                </Button>
              </Box>
            ))}
          </>
        )}
      </Paper>

      {/* ── Add Retailer Modal ─────────────────────────────────────────── */}
      <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth
        PaperProps={{ sx: { borderRadius: "16px", overflow: "hidden" } }}>

        <DialogTitle sx={{ background: "linear-gradient(135deg,#ede9fe,#f5f3ff)", borderBottom: "1px solid #e9d5ff", display: "flex", alignItems: "center", justifyContent: "space-between", py: 2 }}>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
            <Box sx={{ width: 36, height: 36, borderRadius: "8px", background: "#7c3aed", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <AddIcon sx={{ color: "white", fontSize: 20 }} />
            </Box>
            <Box>
              <Typography sx={{ fontWeight: 700, fontSize: 16, color: "#3b0764" }}>Add Retailer</Typography>
              <Typography sx={{ fontSize: 11, color: "#7c3aed" }}>POST /api/v1/users</Typography>
            </Box>
          </Box>
          <IconButton onClick={handleClose} size="small" disabled={submitting}>
            <CloseIcon fontSize="small" />
          </IconButton>
        </DialogTitle>

        <DialogContent sx={{ pt: 3, pb: 1 }}>
          {/* Creator pill */}
          <Box sx={{ background: "#f5f3ff", border: "1px solid #e9d5ff", borderRadius: "8px", px: 2, py: 1, mb: 2.5, display: "flex", gap: 2, alignItems: "center" }}>
            <Typography sx={{ fontSize: 12, color: "#7c3aed", fontWeight: 600 }}>Session: {userName}</Typography>
            <Typography sx={{ fontSize: 12, color: "#a78bfa" }}>|</Typography>
            <Typography sx={{ fontSize: 12, color: "#7c3aed" }}>SuperDist ID: <strong>{superDistId}</strong></Typography>
          </Box>

          {formError && <Alert severity="error" sx={{ mb: 2, borderRadius: "8px", fontSize: 13 }}>{formError}</Alert>}

          <Grid container spacing={2}>
            {FIELDS.map(f => (
              <Grid item xs={12} sm={f.half ? 6 : 12} key={f.id}>
                <TextField
                  fullWidth size="small"
                  label={f.label + (f.required ? " *" : "")}
                  name={f.id}
                  type={f.type || "text"}
                  value={form[f.id]}
                  onChange={handleChange}
                  disabled={submitting}
                  sx={{ "& .MuiOutlinedInput-root": { borderRadius: "8px", fontSize: 13 }, "& label": { fontSize: 13 } }}
                />
              </Grid>
            ))}
          </Grid>

          {/* API Response preview */}
          {response && (
            <Box sx={{ mt: 3, background: "#0f172a", borderRadius: "10px", p: 2 }}>
              <Typography sx={{ fontSize: 11, color: "#475569", fontWeight: 700, letterSpacing: "0.06em", textTransform: "uppercase", mb: 1 }}>
                API Response &nbsp;
                <Chip label={response.success ? "200 OK" : "Error"} size="small"
                  sx={{ background: response.success ? "#064e3b" : "#7f1d1d", color: response.success ? "#6ee7b7" : "#fca5a5", fontSize: 10, height: 18 }} />
              </Typography>
              <Box component="pre" sx={{ fontFamily: "'DM Mono', monospace", fontSize: 11, color: "#94a3b8", whiteSpace: "pre-wrap", wordBreak: "break-all", maxHeight: 200, overflowY: "auto", m: 0 }}>
                {JSON.stringify(response, null, 2)}
              </Box>
            </Box>
          )}
        </DialogContent>

        <DialogActions sx={{ px: 3, py: 2, borderTop: "1px solid #f1f5f9", gap: 1 }}>
          <Button onClick={handleClose} disabled={submitting}
            sx={{ ...btnOutline, px: 3 }}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={submitting}
            startIcon={submitting ? <CircularProgress size={16} sx={{ color: "white" }} /> : <AddIcon />}
            sx={{ ...btnPrimary, background: "#7c3aed", "&:hover": { background: "#6d28d9" }, px: 3 }}>
            {submitting ? "Creating..." : "Create Retailer"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar */}
      <Snackbar open={snack.open} autoHideDuration={4000} onClose={() => setSnack(s => ({ ...s, open: false }))}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}>
        <Alert severity={snack.severity} onClose={() => setSnack(s => ({ ...s, open: false }))} sx={{ borderRadius: "10px" }}>
          {snack.msg}
        </Alert>
      </Snackbar>
    </Box>
  );
}