import { createTheme } from '@mui/material/styles';

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: '#1a56db',
      light: '#3b7af7',
      dark: '#1244b8',
      contrastText: '#ffffff',
    },
    secondary: {
      main: '#0e9f6e',
      light: '#31c48d',
      dark: '#057a55',
      contrastText: '#ffffff',
    },
    error:   { main: '#e02424' },
    warning: { main: '#d97706' },
    info:    { main: '#0891b2' },
    success: { main: '#0e9f6e' },
    background: {
      default: '#f8faff',
      paper:   '#ffffff',
    },
    text: {
      primary:   '#0f1623',
      secondary: '#3a4563',
      disabled:  '#7a8aab',
    },
    divider: '#e5eaf5',
  },
  typography: {
    fontFamily: "'Plus Jakarta Sans', sans-serif",
    h1: { fontWeight: 800 },
    h2: { fontWeight: 800 },
    h3: { fontWeight: 700 },
    h4: { fontWeight: 700 },
    h5: { fontWeight: 700 },
    h6: { fontWeight: 700 },
    button: { fontWeight: 600, textTransform: 'none' },
  },
  shape: { borderRadius: 12 },
  shadows: [
    'none',
    '0 1px 3px rgba(15,22,35,0.06)',
    '0 2px 6px rgba(15,22,35,0.08)',
    '0 4px 12px rgba(15,22,35,0.08)',
    '0 6px 16px rgba(15,22,35,0.1)',
    '0 8px 24px rgba(15,22,35,0.1)',
    '0 10px 28px rgba(15,22,35,0.12)',
    '0 12px 32px rgba(15,22,35,0.12)',
    '0 14px 36px rgba(15,22,35,0.14)',
    '0 16px 40px rgba(15,22,35,0.14)',
    '0 18px 44px rgba(15,22,35,0.16)',
    '0 20px 48px rgba(15,22,35,0.16)',
    '0 22px 52px rgba(15,22,35,0.18)',
    '0 24px 56px rgba(15,22,35,0.18)',
    '0 26px 60px rgba(15,22,35,0.2)',
    '0 28px 64px rgba(15,22,35,0.2)',
    '0 30px 68px rgba(15,22,35,0.22)',
    '0 32px 72px rgba(15,22,35,0.22)',
    '0 34px 76px rgba(15,22,35,0.24)',
    '0 36px 80px rgba(15,22,35,0.24)',
    '0 38px 84px rgba(15,22,35,0.26)',
    '0 40px 88px rgba(15,22,35,0.26)',
    '0 42px 92px rgba(15,22,35,0.28)',
    '0 44px 96px rgba(15,22,35,0.28)',
    '0 46px 100px rgba(15,22,35,0.3)',
  ],
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 10,
          fontWeight: 600,
          textTransform: 'none',
        },
        containedPrimary: {
          background: 'linear-gradient(135deg, #1a56db, #3b7af7)',
          boxShadow: '0 4px 12px rgba(26,86,219,0.25)',
          '&:hover': {
            boxShadow: '0 6px 18px rgba(26,86,219,0.4)',
          },
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 16,
          border: '1px solid #e5eaf5',
          boxShadow: '0 1px 4px rgba(15,22,35,0.04)',
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          backgroundImage: 'none',
        },
      },
    },
    MuiCssBaseline: {
      styleOverrides: `
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 5px; height: 5px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #d0d8ee; border-radius: 99px; }
        ::-webkit-scrollbar-thumb:hover { background: #7a8aab; }
      `,
    },
  },
});

export default theme;
