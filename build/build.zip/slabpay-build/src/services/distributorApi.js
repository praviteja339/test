// src/services/distributorApi.js
import api from './api';

/**
 * All API calls for the Distributor role.
 * Components import this module and never call api.get/post directly —
 * keeping endpoint URLs in one place makes future changes trivial.
 */

// ── Helpers ───────────────────────────────────────────────────────────────────

/** Returns today's date as yyyy-mm-dd (default for date pickers) */
export const today = () => new Date().toISOString().split('T')[0];

/** Returns date N days ago as yyyy-mm-dd */
export const daysAgo = (n) => {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d.toISOString().split('T')[0];
};

/** Reads a key from localStorage first, then sessionStorage */
export const getUser = (key) =>
  localStorage.getItem(key) || sessionStorage.getItem(key) || '';

// ── Dashboard ─────────────────────────────────────────────────────────────────

export const getDashboardStats = (userId) =>
  api.get(`/api/v1/dashboard/stats?userId=${userId}`);

export const getRecentLedger = (accountId, from, to) =>
  api.get(`/api/v1/ledger/account/${accountId}/date-range?from=${from}&to=${to}`);

// ── Retailers ─────────────────────────────────────────────────────────────────

export const getMyRetailers = (distId) =>
  api.get(`/api/v1/users/distributor/${distId}/retailers`);

// ── Balance Transfer ──────────────────────────────────────────────────────────

/**
 * POST /api/v1/balance/transfer
 * @param {Object} payload  { fromUserId, toUserId, amount, narration? }
 */
export const transferBalance = (payload) =>
  api.post('/api/v1/balance/transfer', payload);

// ── Ledger ────────────────────────────────────────────────────────────────────

export const getLedgerSummary = (accountId, from, to) =>
  api.get(`/api/v1/ledger/account/${accountId}/summary?from=${from}&to=${to}`);

/**
 * GET /api/v1/ledger/distributor/{distId}/transfers
 * @param {string|null} retailerId  Optional retailer filter
 */
export const getBalanceList = (distId, from, to, retailerId = null) => {
  const params = new URLSearchParams({ from, to });
  if (retailerId) params.set('retailerId', retailerId);
  return api.get(`/api/v1/ledger/distributor/${distId}/transfers?${params}`);
};

// ── Top-Up ────────────────────────────────────────────────────────────────────

export const submitTopUpRequest = (payload) =>
  api.post('/api/v1/topup', payload);

export const getTopUpHistory = (requesterId, from, to) =>
  api.get(`/api/v1/topup/requester/${requesterId}?from=${from}&to=${to}`);

// ── Commission ────────────────────────────────────────────────────────────────

export const getCommissionDetails = (accountId, from, to) =>
  api.get(`/api/v1/commission/account/${accountId}?from=${from}&to=${to}`);

export const getCommissionLedger = (accountId, from, to) =>
  api.get(`/api/v1/commission/ledger/${accountId}?from=${from}&to=${to}`);

// ── Settings ──────────────────────────────────────────────────────────────────

export const changePassword = (userId, payload) =>
  api.patch(`/api/v1/users/${userId}/password`, payload);

export const changeMPin = (userId, payload) =>
  api.patch(`/api/v1/users/${userId}/mpin`, payload);
