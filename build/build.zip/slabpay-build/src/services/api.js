// src/services/api.js
import axios from 'axios';

/**
 * Shared axios instance used by all service modules.
 * — Automatically attaches Bearer token from localStorage / sessionStorage.
 * — Redirects to /login on 401 (expired/invalid token).
 * — Centralises base URL so a single env var switch targets any environment.
 */
const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'https://slabpay.azurewebsites.net',
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
});

// ── Request interceptor: inject JWT ──────────────────────────────────────────
api.interceptors.request.use(
  (config) => {
    const token =
      localStorage.getItem('token') || sessionStorage.getItem('token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  },
  (error) => Promise.reject(error)
);

// ── Response interceptor: handle 401 globally ─────────────────────────────────
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.clear();
      sessionStorage.clear();
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default api;
