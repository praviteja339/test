/**
 * adminApi.js
 * Centralised API layer for the Admin role.
 * All calls go through the shared axios instance (auto-attaches JWT, handles 401 redirect).
 */
import api from './api';

// ─── helpers ─────────────────────────────────────────────────────────────────

const userId = () => localStorage.getItem('userId') || '1';
const fmt    = (d) => (d instanceof Date ? d.toISOString().split('T')[0] : d);

// ─── Dashboard ────────────────────────────────────────────────────────────────

export const getDashboardStats = () =>
  api.get('/api/v1/dashboard/stats', { params: { userId: userId() } });

// ─── Users ────────────────────────────────────────────────────────────────────

export const getUsersByType  = (type)        => api.get(`/api/v1/users/type/${type}`);
export const getAllUsers      = ()            => api.get('/api/v1/users');
export const getUserById      = (id)          => api.get(`/api/v1/users/${id}`);
export const createUser       = (body)        => api.post('/api/v1/users', body);
export const updateUserStatus = (id, status)  => api.patch(`/api/v1/users/${id}/status`, null, { params: { status } });
export const lockUser         = (id, lock)    => api.patch(`/api/v1/users/${id}/lock`, null, { params: { lock } });
export const updateBalance    = (id, amount, operation) =>
  api.patch(`/api/v1/users/${id}/balance`, { amount, operation });
export const changePassword   = (id, body)   => api.patch(`/api/v1/users/${id}/password`, body);
export const updateApiChannels= (id, body)   => api.patch(`/api/v1/users/${id}/api-channels`, body);

// Hierarchy helpers (used by master tables)
export const getDistributors     = () => getUsersByType('D');
export const getSuperDistributors= () => getUsersByType('S');
export const getRetailers        = () => getUsersByType('R');

export const createDistributor    = (body) =>
  api.post(`/__api__/users/distributor?creatorId=${userId()}`, body);
export const createSuperDistributor = (body) =>
  api.post(`/__api__/users/super-distributor?creatorId=${userId()}`, body);

// ─── Enquiries (KYC pipeline / Verification list) ─────────────────────────────

export const getEnquiries     = ()        => api.get('/api/enquiry');
export const getEnquiryById   = (id)      => api.get(`/api/enquiry/${id}`);
export const acceptEnquiry    = (id)      => api.patch(`/api/enquiry/${id}/accept`);
export const rejectEnquiry    = (id, reason) =>
  api.patch(`/api/enquiry/${id}/reject`, { reason });
export const generateCreds    = (id)      => api.post(`/api/enquiry/${id}/generate-credentials`);

// ─── Top-ups ──────────────────────────────────────────────────────────────────

export const getAllTopUps        = ()       => api.get('/api/v1/topup');
export const getPendingTopUps   = (parentId) =>
  api.get(`/api/v1/topup/pending/parent/${parentId}`);
export const approveTopUp       = (id)     => api.patch(`/api/v1/topup/${id}/approve`);
export const rejectTopUp        = (id, body) => api.patch(`/api/v1/topup/${id}/reject`, body);

// ─── Transactions ─────────────────────────────────────────────────────────────

export const getTransactionsByAccount = (accountId) =>
  api.get(`/api/v1/transactions/account/${accountId}`);
export const getTransactionsByDateRange = (params) =>
  api.get('/api/v1/transactions/date-range', { params });
export const updateTransactionStatus = (id, statusId) =>
  api.patch(`/api/v1/transactions/${id}/status`, null, { params: { statusId } });

// ─── Ledger ───────────────────────────────────────────────────────────────────

export const getLedger = (accountId, params) =>
  api.get(`/api/v1/ledger/account/${accountId}`, { params });
export const getLedgerBalance = (accountId) =>
  api.get(`/api/v1/ledger/account/${accountId}/balance`);
export const getLedgerByDateRange = (accountId, from, to) =>
  api.get(`/api/v1/ledger/account/${accountId}/date-range`, {
    params: { from: fmt(from), to: fmt(to) },
  });
export const getDistTransfers = (distId) =>
  api.get(`/api/v1/ledger/distributor/${distId}/transfers`);

// ─── Commission (earned) ──────────────────────────────────────────────────────

export const getCommissionDetails = (accountId, from, to) =>
  api.get(`/api/v1/commission/account/${accountId}`, {
    params: { from: fmt(from), to: fmt(to) },
  });
export const getCommissionLedger = (accountId, from, to) =>
  api.get(`/api/v1/commission/ledger/${accountId}`, {
    params: { from: fmt(from), to: fmt(to) },
  });

// ─── Commission Config (Admin-managed rates) ──────────────────────────────────

export const getCommissionConfigs  = ()           => api.get('/api/v1/commission/config');
export const upsertCommissionConfig= (body)       => api.post('/api/v1/commission/config', body);
export const updateCommissionConfig= (id, body)   => api.put(`/api/v1/commission/config/${id}`, body);

export const getCommissionSlabs    = ()           => api.get('/api/v1/commission/config/slabs');
export const createCommissionSlab  = (body)       => api.post('/api/v1/commission/config/slabs', body);
export const updateCommissionSlab  = (id, body)   => api.put(`/api/v1/commission/config/slabs/${id}`, body);
export const deleteCommissionSlab  = (id)         => api.delete(`/api/v1/commission/config/slabs/${id}`);

// ─── Charges ──────────────────────────────────────────────────────────────────

export const getChargeSettings  = ()      => api.get('/api/v1/charges/settings');
export const updateChargeSettings= (body) => api.put('/api/v1/charges/settings', body);

// ─── Banks ────────────────────────────────────────────────────────────────────

export const getBanks            = ()           => api.get('/api/v1/banks');
export const createBank          = (body)       => api.post('/api/v1/banks', body);
export const updateBank          = (id, body)   => api.put(`/api/v1/banks/${id}`, body);
export const deleteBank          = (id)         => api.delete(`/api/v1/banks/${id}`);
export const toggleBankTransfer  = (id, enabled) =>
  api.patch(`/api/v1/banks/${id}/fund-transfer`, null, { params: { enabled } });

// ─── Roles ────────────────────────────────────────────────────────────────────

export const getRoles           = ()           => api.get('/api/v1/roles');
export const getRoleById        = (id)         => api.get(`/api/v1/roles/${id}`);
export const createRole         = (body)       => api.post('/api/v1/roles', body);
export const updatePermissions  = (id, body)   => api.put(`/api/v1/roles/${id}/permissions`, body);
export const getAllMenus         = ()           => api.get('/api/v1/roles/menus');

// ─── System Settings ──────────────────────────────────────────────────────────

export const getSettings    = ()      => api.get('/api/v1/settings');
export const updateSettings = (body)  => api.put('/api/v1/settings', body);

// ─── Admin Balance (via user balance endpoint) ────────────────────────────────

export const getAdminBalance = (adminId) =>
  api.get(`/api/v1/users/${adminId}`);
export const setAdminBalance = (adminId, amount) =>
  api.patch(`/api/v1/users/${adminId}/balance`, { amount, operation: 'SET' });
export const getAdminLedger  = (adminId) =>
  api.get(`/api/v1/ledger/account/${adminId}`);

// ─── OTP ──────────────────────────────────────────────────────────────────────

export const generateOtp = (body) => api.post('/api/v1/otp/generate', body);
export const verifyOtp   = (body) => api.post('/api/v1/otp/verify', body);
