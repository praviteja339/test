import { useNavigate } from 'react-router-dom';

// Maps SD page keys (used in superdistributor folder) to actual route paths in agent
export const SD_PAGE_PATHS = {
  // SD pages
  'sd-dashboard':          '/sd/dashboard',
  'sd-add-balance':        '/sd/add-balance',
  'sd-topup-request':      '/sd/topup-request',
  'sd-ledger':             '/sd/ledger',
  'sd-topup-history':      '/sd/topup-history',
  'sd-commission-ledger':  '/sd/commission-ledger',
  'sd-commission-details': '/sd/commission-details',
  'sd-balance-list':       '/sd/balance-list',
  'sd-distributor-list':   '/sd/distributor-list',
  'sd-change-password':    '/sd/change-password',
  'sd-change-mpin':        '/sd/change-mpin',
  // Auth
  'login':                 '/login',
  'dashboard':             '/dashboard',
};

/**
 * Returns a navigate function compatible with SD page components.
 * SD pages call navigate('sd-dashboard') style; this maps keys to paths.
 */
export function useSDNavigate() {
  const rrNavigate = useNavigate();
  return (key) => {
    const path = SD_PAGE_PATHS[key] ?? `/${key}`;
    rrNavigate(path);
  };
}
