import { useEffect } from "react";

/**
 * useScrollReveal
 * Adds the "visible" class to any element with the "reveal" class
 * when it enters the viewport (IntersectionObserver).
 *
 * Call this inside every page component that uses reveal animations.
 */
export default function useScrollReveal(deps = []) {
  useEffect(() => {
    const reveals = document.querySelectorAll(".reveal");

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) e.target.classList.add("visible");
        });
      },
      { threshold: 0.12 }
    );

    reveals.forEach((el) => {
      el.classList.remove("visible");
      observer.observe(el);
    });

    // Immediately reveal anything already visible in the viewport
    setTimeout(() => {
      reveals.forEach((el) => {
        if (el.getBoundingClientRect().top < window.innerHeight) {
          el.classList.add("visible");
        }
      });
    }, 50);

    return () => observer.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
}
