import { useEffect } from "react";

/**
 * useCursor
 * Drives the two-part custom cursor (dot + ring) that follows the mouse.
 */
export default function useCursor() {
  useEffect(() => {
    const cursor = document.getElementById("cursor");
    const ring   = document.getElementById("cursor-ring");
    if (!cursor || !ring) return;

    let mx = 0, my = 0, rx = 0, ry = 0;
    let rafId;

    const onMouseMove = (e) => {
      mx = e.clientX;
      my = e.clientY;
    };

    const animate = () => {
      cursor.style.left = `${mx}px`;
      cursor.style.top  = `${my}px`;
      rx += (mx - rx) * 0.12;
      ry += (my - ry) * 0.12;
      ring.style.left = `${rx}px`;
      ring.style.top  = `${ry}px`;
      rafId = requestAnimationFrame(animate);
    };

    document.addEventListener("mousemove", onMouseMove);
    rafId = requestAnimationFrame(animate);

    return () => {
      document.removeEventListener("mousemove", onMouseMove);
      cancelAnimationFrame(rafId);
    };
  }, []);
}
