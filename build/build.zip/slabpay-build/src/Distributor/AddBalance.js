// src/Distributor/AddBalance.js
import { useState, useEffect } from 'react';
import {
  Box, Typography, Paper, TextField, Button,
  CircularProgress, Alert, InputAdornment,
} from '@mui/material';
import SearchIcon     from '@mui/icons-material/Search';
import AddIcon        from '@mui/icons-material/Add';
import RefreshIcon    from '@mui/icons-material/Refresh';
import { cardStyle, inputStyle, btnPrimary, C } from './lightStyles';
import { getMyRetailers, transferBalance, getUser } from '../services/distributorApi';

const fmt = (v) =>
  Number(v || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export default function AddBalance() {
  const distId = getUser('userId');

  const [retailers, setRetailers]   = useState([]);
  const [selected,  setSelected]    = useState(null);
  const [amount,    setAmount]      = useState('');
  const [narration, setNarration]   = useState('');
  const [search,    setSearch]      = useState('');
  const [toast,     setToast]       = useState(null);

  const [loadingList,     setLoadingList]     = useState(true);
  const [loadingTransfer, setLoadingTransfer] = useState(false);
  const [listError,       setListError]       = useState(null);
  const [transferError,   setTransferError]   = useState(null);

  // ── Load retailer list ──────────────────────────────────────────────────────
  const loadRetailers = async () => {
    setLoadingList(true);
    setListError(null);
    try {
      const res = await getMyRetailers(distId);
      setRetailers(res.data.data || []);
    } catch (e) {
      setListError(e.response?.data?.error || 'Failed to load retailers');
    } finally {
      setLoadingList(false);
    }
  };

  useEffect(() => { loadRetailers(); }, [distId]);

  // ── Filtered retailer rows ──────────────────────────────────────────────────
  const filtered = retailers.filter((r) => {
    const q = search.toLowerCase();
    return (
      r.userName?.toLowerCase().includes(q) ||
      r.company?.toLowerCase().includes(q)  ||
      r.registeredMobileNo?.includes(q)
    );
  });

  // ── Submit balance transfer ─────────────────────────────────────────────────
  const handleTransfer = async () => {
    if (!selected)       return setTransferError('Please select a retailer first.');
    if (!amount || Number(amount) <= 0)
                         return setTransferError('Enter a valid amount greater than ₹0.');
    if (Number(amount) > Number(getUser('balance') || 99999999))
                         return setTransferError('Amount exceeds your available balance.');

    setLoadingTransfer(true);
    setTransferError(null);
    try {
      const res = await transferBalance({
        fromUserId: Number(distId),
        toUserId:   selected.id,
        amount:     Number(amount),
        narration:  narration.trim() || undefined,
      });

      const data = res.data.data;
      // Update local retailer balance optimistically
      setRetailers((prev) =>
        prev.map((r) =>
          r.id === selected.id
            ? { ...r, balance: data.toBalanceAfter }
            : r
        )
      );

      setToast({ msg: `₹${fmt(amount)} transferred to ${selected.userName}`, type: 'success' });
      setAmount('');
      setNarration('');
      setSelected(null);
      setTimeout(() => setToast(null), 4000);
    } catch (e) {
      setTransferError(e.response?.data?.error || 'Transfer failed. Please try again.');
    } finally {
      setLoadingTransfer(false);
    }
  };

  return (
    <Box sx={{ p: 3, position: 'relative' }}>

      {/* Toast */}
      {toast && (
        <Box sx={{
          position: 'fixed', top: 24, right: 24, zIndex: 9999,
          background: toast.type === 'success' ? C.secondaryLight : C.dangerLight,
          border: `1px solid ${toast.type === 'success' ? C.secondary : C.danger}`,
          borderRadius: '12px', px: 3, py: 1.5,
          color: toast.type === 'success' ? C.secondary : C.danger,
          fontWeight: 700, fontSize: 14, boxShadow: '0 8px 24px rgba(15,22,35,0.12)',
          display: 'flex', alignItems: 'center', gap: 1,
        }}>
          <span>{toast.type === 'success' ? '✅' : '❌'}</span> {toast.msg}
        </Box>
      )}

      <Box sx={{ background: 'linear-gradient(135deg, #e8efff, #f0f5ff)', borderRadius: '14px',
        px: 3, py: 1.5, mb: 2, borderLeft: '4px solid #1a56db' }}>
        <Typography sx={{ fontSize: 11, fontWeight: 700, letterSpacing: '2px',
          textTransform: 'uppercase', color: C.primary }}>
          Welcome to Slabpay
        </Typography>
      </Box>
      <Typography sx={{ fontSize: 20, fontWeight: 800, mb: 3, color: C.text1 }}>
        Add Balance
      </Typography>

      {listError && (
        <Alert severity="error" sx={{ mb: 2, borderRadius: '10px' }} onClose={() => setListError(null)}>
          {listError}
        </Alert>
      )}

      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', lg: '1fr 360px' }, gap: 2 }}>

        {/* ── Retailer Table ── */}
        <Paper sx={cardStyle}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2.5 }}>
            <Typography sx={{ fontWeight: 700, fontSize: 15, color: C.text1 }}>
              Select Retailer
              {retailers.length > 0 && (
                <Box component="span" sx={{ ml: 1, px: 1.5, py: 0.3, borderRadius: '20px',
                  background: C.primaryLight, color: C.primary, fontSize: 11, fontWeight: 700 }}>
                  {retailers.length}
                </Box>
              )}
            </Typography>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <TextField
                size="small" placeholder="Search retailer…" value={search}
                onChange={(e) => setSearch(e.target.value)}
                sx={{ ...inputStyle, width: 220 }}
                InputProps={{ startAdornment:
                  <InputAdornment position="start">
                    <SearchIcon sx={{ color: C.text3, fontSize: 18 }} />
                  </InputAdornment>
                }}
              />
              <Button onClick={loadRetailers} sx={{ minWidth: 0, px: 1.5,
                border: `1px solid ${C.border}`, borderRadius: '8px', color: C.text2 }}>
                <RefreshIcon fontSize="small" />
              </Button>
            </Box>
          </Box>

          {/* Table header */}
          <Box sx={{ display: 'grid', gridTemplateColumns: '50px 1fr 1fr 110px 110px',
            gap: 1, borderBottom: `2px solid ${C.border}`, pb: 1, mb: 1,
            fontSize: 11, fontWeight: 700, color: C.text3, textTransform: 'uppercase',
            letterSpacing: '0.5px', px: 1 }}>
            <span>ID</span><span>Name</span><span>Shop / Company</span>
            <span>Mobile</span><span style={{ textAlign: 'right' }}>Balance</span>
          </Box>

          {loadingList
            ? <Box sx={{ display: 'flex', justifyContent: 'center', py: 5 }}>
                <CircularProgress size={28} />
              </Box>
            : filtered.length === 0
              ? <Box sx={{ textAlign: 'center', py: 6, color: C.text3 }}>
                  <Box sx={{ fontSize: 36, mb: 1 }}>🔍</Box>
                  <Typography sx={{ fontSize: 13, color: C.text2 }}>No retailers found</Typography>
                </Box>
              : filtered.map((r) => (
                  <Box
                    key={r.id}
                    onClick={() => setSelected(selected?.id === r.id ? null : r)}
                    sx={{
                      display: 'grid', gridTemplateColumns: '50px 1fr 1fr 110px 110px',
                      gap: 1, py: 1.5, px: 1, borderRadius: '10px', cursor: 'pointer',
                      background: selected?.id === r.id ? C.primaryLight : 'transparent',
                      border: `1.5px solid ${selected?.id === r.id ? C.primary : 'transparent'}`,
                      transition: 'all 0.18s ease', mb: 0.5,
                      '&:hover': { background: selected?.id === r.id ? C.primaryLight : C.surface2 },
                    }}
                  >
                    <Typography sx={{ fontSize: 13, fontWeight: 600, color: C.text3 }}>
                      #{r.id}
                    </Typography>
                    <Box>
                      <Typography sx={{ fontSize: 13, fontWeight: 700, color: C.text1 }}>
                        {r.userName}
                      </Typography>
                    </Box>
                    <Typography sx={{ fontSize: 12, color: C.text2 }}>
                      {r.company || '—'}
                    </Typography>
                    <Typography sx={{ fontSize: 12, color: C.text3 }}>
                      {r.registeredMobileNo}
                    </Typography>
                    <Typography sx={{
                      fontSize: 13, fontWeight: 700, textAlign: 'right',
                      color: Number(r.balance || 0) > 100 ? C.secondary : C.danger,
                    }}>
                      ₹{fmt(r.balance)}
                    </Typography>
                  </Box>
                ))
          }
        </Paper>

        {/* ── Transfer Panel ── */}
        <Paper sx={cardStyle}>
          <Typography sx={{ fontWeight: 700, fontSize: 15, color: C.text1, mb: 2.5,
            pb: 2, borderBottom: `1px solid ${C.border}` }}>
            Add Balance
          </Typography>

          {transferError && (
            <Alert severity="error" sx={{ mb: 2, borderRadius: '10px', fontSize: 13 }}
              onClose={() => setTransferError(null)}>
              {transferError}
            </Alert>
          )}

          {selected ? (
            <Box>
              {/* Selected retailer card */}
              <Box sx={{ background: C.primaryLight, borderRadius: '12px', p: 2, mb: 2.5,
                border: `1px solid ${C.border}` }}>
                <Typography sx={{ fontSize: 11, color: C.text3, fontWeight: 600, mb: 0.5 }}>
                  Selected Retailer
                </Typography>
                <Typography sx={{ fontSize: 14, fontWeight: 800, color: C.primary }}>
                  {selected.userName}
                </Typography>
                <Typography sx={{ fontSize: 12, color: C.text2 }}>
                  {selected.company || selected.city || ''}
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 1 }}>
                  <Typography sx={{ fontSize: 11, color: C.text3 }}>Current Balance:</Typography>
                  <Typography sx={{ fontSize: 13, fontWeight: 700, color: C.secondary }}>
                    ₹{fmt(selected.balance)}
                  </Typography>
                </Box>
              </Box>

              <TextField
                label="Amount to Add (₹)"
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                inputProps={{ min: 1 }}
                fullWidth
                sx={{ ...inputStyle, mb: 2 }}
              />
              <TextField
                label="Narration / Note (optional)"
                value={narration}
                onChange={(e) => setNarration(e.target.value)}
                fullWidth
                sx={{ ...inputStyle, mb: 2.5 }}
              />

              <Button
                onClick={handleTransfer}
                disabled={loadingTransfer}
                startIcon={loadingTransfer
                  ? <CircularProgress size={16} color="inherit" />
                  : <AddIcon />}
                sx={{ ...btnPrimary, width: '100%', height: '46px' }}
              >
                {loadingTransfer ? 'Processing…' : 'Confirm Transfer'}
              </Button>
            </Box>
          ) : (
            <Box sx={{ textAlign: 'center', py: 5, color: C.text3 }}>
              <Box sx={{ fontSize: 44, mb: 1.5 }}>👆</Box>
              <Typography sx={{ fontWeight: 600, color: C.text2, fontSize: 14 }}>
                Select a retailer
              </Typography>
              <Typography sx={{ fontSize: 12, mt: 0.5 }}>
                Click a row from the table to add balance
              </Typography>
            </Box>
          )}
        </Paper>
      </Box>
    </Box>
  );
}
