// src/Distributor/BalanceList.js
import { useState, useEffect } from 'react';
import {
  Box, Typography, TextField, MenuItem, Button, Grid, Paper,
  CircularProgress, Alert,
} from '@mui/material';
import SearchIcon   from '@mui/icons-material/Search';
import DownloadIcon from '@mui/icons-material/Download';
import GroupIcon    from '@mui/icons-material/Group';
import { cardStyle, statCard, inputStyle, btnPrimary, btnOutline, tableHeader, C }
  from './lightStyles';
import { getMyRetailers, getBalanceList, getUser, today, daysAgo }
  from '../services/distributorApi';

const fmt   = (v) => Number(v || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 });
const fmtDt = (dt) => dt ? new Date(dt).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }) : '—';

export default function BalanceList() {
  const distId = getUser('userId');

  const [from,      setFrom]      = useState(daysAgo(30));
  const [to,        setTo]        = useState(today());
  const [retailers, setRetailers] = useState([]);
  const [retailerId,setRetailerId]= useState('');
  const [records,   setRecords]   = useState([]);
  const [loading,   setLoading]   = useState(false);
  const [error,     setError]     = useState(null);

  // Load retailer dropdown once
  useEffect(() => {
    getMyRetailers(distId)
      .then((res) => setRetailers(res.data.data || []))
      .catch(() => {});
  }, [distId]);

  const fetchData = async () => {
    if (!from || !to) return setError('Please select both From and To dates.');
    setLoading(true);
    setError(null);
    try {
      const res = await getBalanceList(distId, from, to, retailerId || null);
      setRecords(res.data.data || []);
    } catch (e) {
      setError(e.response?.data?.error || 'Failed to load balance list.');
    } finally {
      setLoading(false);
    }
  };

  // Aggregates
  const totalGiven       = records.reduce((s, r) => s + Number(r.amount || 0), 0);
  const uniqueRetailers  = new Set(records.map((r) => r.accountId)).size;

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ background: 'linear-gradient(135deg, #e8efff, #f0f5ff)', borderRadius: '14px',
        px: 3, py: 1.5, mb: 2, borderLeft: '4px solid #1a56db' }}>
        <Typography sx={{ fontSize: 11, fontWeight: 700, letterSpacing: '2px',
          textTransform: 'uppercase', color: C.primary }}>Welcome to Slabpay</Typography>
      </Box>
      <Typography sx={{ fontSize: 20, fontWeight: 800, mb: 3, color: C.text1 }}>Balance List</Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 2, borderRadius: '10px' }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {/* Filter bar */}
      <Paper sx={cardStyle}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} md={2}>
            <TextField type="date" label="From Date" value={from}
              onChange={(e) => setFrom(e.target.value)}
              InputLabelProps={{ shrink: true }} fullWidth sx={inputStyle} />
          </Grid>
          <Grid item xs={12} md={2}>
            <TextField type="date" label="Upto Date" value={to}
              onChange={(e) => setTo(e.target.value)}
              InputLabelProps={{ shrink: true }} fullWidth sx={inputStyle} />
          </Grid>
          <Grid item xs={12} md={3}>
            <TextField select label="Select Retailer" value={retailerId}
              onChange={(e) => setRetailerId(e.target.value)} fullWidth sx={inputStyle}>
              <MenuItem value="">All Retailers</MenuItem>
              {retailers.map((r) => (
                <MenuItem key={r.id} value={r.id}>{r.userName}</MenuItem>
              ))}
            </TextField>
          </Grid>
          <Grid item xs={12} md={2}>
            <Button startIcon={loading ? <CircularProgress size={16} color="inherit" /> : <SearchIcon />}
              fullWidth sx={btnPrimary} onClick={fetchData} disabled={loading}>
              {loading ? 'Loading…' : 'Get Data'}
            </Button>
          </Grid>
          <Grid item xs={12} md={3} textAlign="right">
            <Button startIcon={<DownloadIcon />} sx={btnOutline} disabled={records.length === 0}>
              Export Excel
            </Button>
          </Grid>
        </Grid>
      </Paper>

      {/* Summary cards */}
      <Grid container spacing={2} mt={1}>
        {[
          { label: 'Total Retailers',    value: uniqueRetailers,         accent: C.primary,
            icon: <GroupIcon sx={{ fontSize: 22, color: C.primary }} /> },
          { label: 'Total Balance Given',value: `₹${fmt(totalGiven)}`,  accent: C.secondary },
          { label: 'Transactions',       value: records.length,          accent: '#0891b2'  },
          { label: 'Avg per Transfer',   value: records.length > 0 ? `₹${fmt(totalGiven / records.length)}` : '₹0.00',
            accent: C.warning },
        ].map((item, i) => (
          <Grid item xs={12} md={3} key={i}>
            <Paper sx={{ ...statCard, borderLeft: `4px solid ${item.accent}`,
              display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <Box>
                <Typography sx={{ fontSize: 11, color: C.text3, fontWeight: 600,
                  textTransform: 'uppercase', letterSpacing: '0.5px' }}>{item.label}</Typography>
                <Typography sx={{ fontSize: 20, fontWeight: 800, color: item.accent, mt: 0.5 }}>
                  {item.value}
                </Typography>
              </Box>
              {item.icon && (
                <Box sx={{ background: C.primaryLight, p: 1.2, borderRadius: '10px' }}>
                  {item.icon}
                </Box>
              )}
            </Paper>
          </Grid>
        ))}
      </Grid>

      {/* Records table */}
      <Paper sx={{ ...cardStyle, mt: 3 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
          <Box>
            <Typography sx={{ fontWeight: 700, fontSize: 15, color: C.text1 }}>Balance Details</Typography>
            <Typography sx={{ fontSize: 12, color: C.text3, mt: 0.3 }}>
              Total Balance Given: ₹{fmt(totalGiven)}
            </Typography>
          </Box>
          <Box sx={{ px: 2, py: 0.5, borderRadius: '20px', background: C.primaryLight,
            fontSize: 12, color: C.primary, fontWeight: 700 }}>
            {records.length} Records
          </Box>
        </Box>

        <Box sx={{ ...tableHeader, gridTemplateColumns: '60px 1fr 2fr 1fr 1fr 1fr' }}>
          {['Entry No', 'Date', 'Narration', 'Retailer ID', 'Amount', 'Balance After']
            .map((h) => <span key={h}>{h}</span>)}
        </Box>

        {loading
          ? <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}><CircularProgress /></Box>
          : records.length === 0
            ? <Box sx={{ textAlign: 'center', py: 8, color: C.text3 }}>
                <Box sx={{ fontSize: 40, mb: 1 }}>💰</Box>
                <Typography sx={{ fontWeight: 600, color: C.text2 }}>No balance records found</Typography>
                <Typography sx={{ fontSize: 12, mt: 0.5 }}>Set filters and click Get Data</Typography>
              </Box>
            : records.map((row, i) => (
                <Box key={row.ledgerId} sx={{
                  display: 'grid', gridTemplateColumns: '60px 1fr 2fr 1fr 1fr 1fr',
                  gap: 1, py: 1.4, px: 1, borderRadius: '8px', alignItems: 'center',
                  background: i % 2 === 0 ? 'transparent' : C.surface2,
                  borderBottom: `1px solid ${C.border}`, fontSize: 13,
                }}>
                  <span style={{ color: C.text3, fontWeight: 600 }}>#{row.ledgerId}</span>
                  <span style={{ color: C.text3, fontSize: 12 }}>{fmtDt(row.createdDate)}</span>
                  <span>{row.narration || '—'}</span>
                  <span style={{ color: C.text2 }}>#{row.accountId}</span>
                  <span style={{ fontWeight: 700, color: C.secondary }}>₹{fmt(row.amount)}</span>
                  <span style={{ fontWeight: 600 }}>₹{fmt(row.balance)}</span>
                </Box>
              ))
        }
      </Paper>
    </Box>
  );
}
