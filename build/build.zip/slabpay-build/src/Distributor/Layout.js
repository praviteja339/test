import { useState, useRef, useEffect } from "react";
import { useNavigate, useLocation, Routes, Route } from "react-router-dom";
import {
  Box, Typography, Drawer, AppBar, Toolbar, IconButton, Avatar,
  Tooltip, Badge, Paper, Divider, MenuItem, useMediaQuery, useTheme,
} from "@mui/material";
import {
  Home, AddCircleOutline, TrendingUp, Description, History,
  BarChart, People, SyncAlt, Lock, PhoneAndroid, Notifications,
  KeyboardArrowDown, Person, ExitToApp, Settings,
  Menu as MenuIcon, ChevronLeft,
} from "@mui/icons-material";
import AddBalance from "./AddBalance";
import DashboardPage from "./DashboardPage";
import TopUpRequestDark from "./TopupRequest";
import LedgerReport from "./LedgerReport";
import TopupHistory from "./TopupHistory";
import CommisionLedger from "./CommisionLedger";
import CommisionDetails from "./CommisionDetails";
import BalanceList from "./BalanceList";
import ChangePassword from "./ChangePassword";
import MPin from "./MPin";
import ProfilePage from "../components/ProfilePage";

const SIDEBAR_W = 252;
const SIDEBAR_COLLAPSED_W = 68;
const PRIMARY = "#1a56db";

const navGroups = [
  {
    label: "MAIN",
    items: [
      { icon: <Home fontSize="small" />,            label: "Dashboard",            path: "/distributor/dashboard"          },
      { icon: <AddCircleOutline fontSize="small" />, label: "Add Balance",          path: "/distributor/add-balance"        },
      { icon: <TrendingUp fontSize="small" />,       label: "Top Up Request",       path: "/distributor/topup",  badge: 2   },
    ],
  },
  {
    label: "REPORTS",
    items: [
      { icon: <Description fontSize="small" />, label: "Ledger Details",       path: "/distributor/ledger"             },
      { icon: <History fontSize="small" />,      label: "Top Up History",       path: "/distributor/history"            },
      { icon: <BarChart fontSize="small" />,     label: "Commission Ledger",    path: "/distributor/commission-ledger"  },
      { icon: <BarChart fontSize="small" />,     label: "Commission Details",   path: "/distributor/commission-details" },
      { icon: <Description fontSize="small" />, label: "Add Balance List",     path: "/distributor/balance-list"       },
      { icon: <People fontSize="small" />,       label: "Retailer List",        path: "/distributor/retailer"           },
      { icon: <SyncAlt fontSize="small" />,      label: "Retailer Transactions",path: "/distributor/transactions"       },
    ],
  },
  {
    label: "SETTINGS",
    items: [
      { icon: <Lock fontSize="small" />,        label: "Change Password", path: "/distributor/password" },
      { icon: <PhoneAndroid fontSize="small" />, label: "Change M-Pin",   path: "/distributor/mpin"     },
    ],
  },
];

const allNavItems = navGroups.flatMap(g => g.items);

function ProfileDropdown({ navigate }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const name  = localStorage.getItem("userName")  || sessionStorage.getItem("userName")  || "Distributor";
  const email = localStorage.getItem("email")     || sessionStorage.getItem("email")     || "";
  const role  = localStorage.getItem("roleName")  || sessionStorage.getItem("roleName")  || "Distributor";
  const initials = name.slice(0, 2).toUpperCase();

  useEffect(() => {
    const h = e => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);

  const handleLogout = () => { localStorage.clear(); sessionStorage.clear(); navigate("/login"); };

  return (
    <Box ref={ref} sx={{ position: "relative" }}>
      <Box onClick={() => setOpen(o => !o)} sx={{ display: "flex", alignItems: "center", gap: 1, background: "#f8faff", border: "1px solid #e5eaf5", borderRadius: "10px", px: 1.5, py: 0.8, cursor: "pointer", "&:hover": { background: "#eef2fb" } }}>
        <Box sx={{ width: 28, height: 28, borderRadius: "8px", background: "linear-gradient(135deg, #1a56db, #0e9f6e)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 700, fontSize: 11 }}>{initials}</Box>
        <Box sx={{ display: { xs: "none", sm: "block" } }}>
          <Typography sx={{ fontSize: 12, fontWeight: 700, color: "#0f1623", lineHeight: 1.2 }}>{name}</Typography>
          <Typography sx={{ fontSize: 10, color: "#7a8aab" }}>{role}</Typography>
        </Box>
        <KeyboardArrowDown sx={{ color: "#b0bcd4", fontSize: 16, transition: "transform 0.2s", transform: open ? "rotate(180deg)" : "none", display: { xs: "none", sm: "block" } }} />
      </Box>
      {open && (
        <Paper elevation={4} sx={{ position: "absolute", right: 0, top: "calc(100% + 8px)", width: 220, borderRadius: "14px", zIndex: 9999, border: "1px solid #e5eaf5", overflow: "hidden" }}>
          <Box sx={{ px: 2, py: 2, background: "#f8faff" }}>
            <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
              <Avatar sx={{ width: 38, height: 38, background: "linear-gradient(135deg, #1a56db, #0e9f6e)", fontSize: 14, fontWeight: 800 }}>{initials}</Avatar>
              <Box>
                <Typography sx={{ fontSize: 13, fontWeight: 700, color: "#0f1623" }}>{name}</Typography>
                <Typography sx={{ fontSize: 11, color: "#7a8aab", wordBreak: "break-all" }}>{email}</Typography>
              </Box>
            </Box>
          </Box>
          <Divider />
          <Box sx={{ py: 0.5 }}>
            <MenuItem onClick={() => { setOpen(false); navigate("/distributor/profile"); }} sx={{ gap: 1.5, px: 2, py: 1.2, fontSize: 13, color: "#0f1623", "&:hover": { background: "#f8faff" } }}>
              <Person fontSize="small" sx={{ color: "#7a8aab" }} /> My Profile
            </MenuItem>
            <Divider />
            <MenuItem onClick={handleLogout} sx={{ gap: 1.5, px: 2, py: 1.2, fontSize: 13, color: "#dc2626", fontWeight: 600, "&:hover": { background: "#fef2f2" } }}>
              <ExitToApp fontSize="small" /> Logout
            </MenuItem>
          </Box>
        </Paper>
      )}
    </Box>
  );
}

export default function DistributorLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"));

  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileOpen, setMobileOpen] = useState(false);

  // Auth guard – redirect to login if token missing
  useEffect(() => {
    if (!localStorage.getItem("token")) {
      navigate("/login", { replace: true });
    }
  }, [navigate]);

  useEffect(() => { if (isMobile) setSidebarOpen(false); else setSidebarOpen(true); }, [isMobile]);
  useEffect(() => { setMobileOpen(false); }, [location.pathname]);

  const currentItem = allNavItems.find(i => location.pathname.startsWith(i.path));
  const collapsed = !isMobile && !sidebarOpen;
  const drawerWidth = collapsed ? SIDEBAR_COLLAPSED_W : SIDEBAR_W;

  const SidebarContent = () => (
    <>
      <Box sx={{ px: collapsed ? 1 : 3, py: 2.5, borderBottom: "1px solid #f0f4fb", display: "flex", alignItems: "center", justifyContent: collapsed ? "center" : "flex-start", gap: 1.5, minHeight: 64 }}>
        <Box sx={{ width: 40, height: 40, borderRadius: "12px", background: "linear-gradient(135deg, #1a56db, #3b7af7)", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 4px 12px rgba(26,86,219,0.3)", color: "#fff", fontWeight: 800, fontSize: 14, flexShrink: 0 }}>SP</Box>
        {!collapsed && (
          <Box>
            <Typography sx={{ fontWeight: 800, fontSize: 17, color: "#0f1623", letterSpacing: "-0.3px", lineHeight: 1.1 }}>SLAB<span style={{ color: PRIMARY }}>PAY</span></Typography>
            <Typography sx={{ fontSize: 9.5, color: "#7a8aab", letterSpacing: "0.5px", fontWeight: 500 }}>DISTRIBUTOR PORTAL</Typography>
          </Box>
        )}
      </Box>

      <Box sx={{ flex: 1, overflowY: "auto", px: collapsed ? 1 : 1.5, py: 1.5 }}>
        {navGroups.map(group => (
          <Box key={group.label} sx={{ mb: 1 }}>
            {!collapsed && <Typography sx={{ fontSize: 10, fontWeight: 700, letterSpacing: "1.2px", color: "#b0bcd4", px: 1.5, py: 1, mb: 0.5 }}>{group.label}</Typography>}
            {collapsed && <Box sx={{ my: 0.5, mx: 1, height: "1px", background: "#f0f4fb" }} />}
            {group.items.map(item => {
              const active = location.pathname.startsWith(item.path);
              return (
                <Tooltip key={item.path} title={collapsed ? item.label : ""} placement="right">
                  <Box onClick={() => navigate(item.path)} sx={{ display: "flex", alignItems: "center", gap: collapsed ? 0 : 1.5, px: collapsed ? 1 : 1.5, py: 1, borderRadius: "10px", mb: 0.5, cursor: "pointer", justifyContent: collapsed ? "center" : "flex-start", background: active ? "linear-gradient(135deg, #e8efff, #f0f5ff)" : "transparent", color: active ? PRIMARY : "#3a4563", borderLeft: collapsed ? "none" : (active ? `3px solid ${PRIMARY}` : "3px solid transparent"), transition: "all 0.18s ease", "&:hover": { background: active ? "linear-gradient(135deg, #e8efff, #f0f5ff)" : "#f8faff", color: active ? PRIMARY : "#0f1623" } }}>
                    <Box sx={{ color: active ? PRIMARY : "#7a8aab", display: "flex", flexShrink: 0 }}>{item.icon}</Box>
                    {!collapsed && <Typography sx={{ fontSize: 13.5, fontWeight: active ? 700 : 500, flex: 1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{item.label}</Typography>}
                    {!collapsed && item.badge && <Box sx={{ background: PRIMARY, color: "#fff", fontSize: 10, fontWeight: 700, px: 1, py: 0.3, borderRadius: "20px", lineHeight: 1.4, minWidth: 18, textAlign: "center" }}>{item.badge}</Box>}
                  </Box>
                </Tooltip>
              );
            })}
          </Box>
        ))}
      </Box>

      {!collapsed && (
        <Box sx={{ p: 1.5, borderTop: "1px solid #f0f4fb" }}>
          <Box onClick={() => navigate("/distributor/profile")} sx={{ display: "flex", alignItems: "center", gap: 1.5, background: "#f8faff", borderRadius: "12px", p: 1.5, border: "1px solid #e5eaf5", cursor: "pointer", "&:hover": { background: "#f0f4fb" } }}>
            <Box sx={{ width: 36, height: 36, borderRadius: "10px", background: "linear-gradient(135deg, #1a56db, #0e9f6e)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 700, fontSize: 14, flexShrink: 0 }}>
              {(localStorage.getItem("userName") || sessionStorage.getItem("userName") || "D").slice(0,2).toUpperCase()}
            </Box>
            <Box sx={{ flex: 1, minWidth: 0 }}>
              <Typography sx={{ fontSize: 13, fontWeight: 700, color: "#0f1623", lineHeight: 1.2 }}>{localStorage.getItem("userName") || sessionStorage.getItem("userName") || "Distributor"}</Typography>
              <Typography sx={{ fontSize: 11, color: "#7a8aab" }}>{localStorage.getItem("roleName") || sessionStorage.getItem("roleName") || "Distributor"}</Typography>
            </Box>
            <KeyboardArrowDown sx={{ color: "#b0bcd4", fontSize: 18 }} />
          </Box>
        </Box>
      )}
    </>
  );

  return (
    <Box sx={{ display: "flex", height: "100vh", background: "#f8faff" }}>
      {!isMobile && (
        <Box sx={{ width: drawerWidth, flexShrink: 0, transition: "width 0.25s ease", background: "#ffffff", borderRight: "1px solid #e5eaf5", display: "flex", flexDirection: "column", boxShadow: "2px 0 12px rgba(15,22,35,0.04)", overflow: "hidden", height: "100vh" }}>
          <SidebarContent />
        </Box>
      )}
      {isMobile && (
        <Drawer variant="temporary" open={mobileOpen} onClose={() => setMobileOpen(false)} ModalProps={{ keepMounted: true }} sx={{ "& .MuiDrawer-paper": { width: SIDEBAR_W, background: "#ffffff", display: "flex", flexDirection: "column", overflow: "hidden" } }}>
          <SidebarContent />
        </Drawer>
      )}

      <Box sx={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", minWidth: 0 }}>
        <AppBar position="static" elevation={0} sx={{ background: "#ffffff", borderBottom: "1px solid #e5eaf5", color: "#0f1623", height: 64, flexShrink: 0 }}>
          <Toolbar sx={{ height: 64, px: { xs: 2, sm: 3 }, gap: 1.5 }}>
            <IconButton onClick={() => isMobile ? setMobileOpen(o => !o) : setSidebarOpen(o => !o)} sx={{ color: "#3a4563", background: "#f8faff", border: "1px solid #e5eaf5", borderRadius: "10px", width: 38, height: 38 }}>
              {(!isMobile && sidebarOpen) ? <ChevronLeft fontSize="small" /> : <MenuIcon fontSize="small" />}
            </IconButton>
            <Box sx={{ flex: 1 }}>
              <Typography sx={{ fontSize: { xs: 14, sm: 17 }, fontWeight: 700, color: "#0f1623" }}>{currentItem?.label || "Dashboard"}</Typography>
              <Typography sx={{ fontSize: 12, color: "#7a8aab", mt: 0.2, display: { xs: "none", sm: "block" } }}>SlabPay Distributor Portal</Typography>
            </Box>
            <Tooltip title="Notifications">
              <IconButton sx={{ color: "#3a4563", background: "#f8faff", border: "1px solid #e5eaf5", borderRadius: "10px", width: 38, height: 38 }}>
                <Badge badgeContent={2} color="error" sx={{ "& .MuiBadge-badge": { fontSize: 9 } }}><Notifications fontSize="small" /></Badge>
              </IconButton>
            </Tooltip>
            <ProfileDropdown navigate={navigate} />
          </Toolbar>
        </AppBar>

        <Box sx={{ flex: 1, overflowY: "auto", p: { xs: 1.5, sm: 2 } }}>
          <Routes>
            <Route path="dashboard"          element={<DashboardPage />} />
            <Route path="add-balance"        element={<AddBalance />} />
            <Route path="topup"              element={<TopUpRequestDark />} />
            <Route path="ledger"             element={<LedgerReport />} />
            <Route path="history"            element={<TopupHistory />} />
            <Route path="commission-ledger"  element={<CommisionLedger />} />
            <Route path="commission-details" element={<CommisionDetails />} />
            <Route path="balance-list"       element={<BalanceList />} />
            <Route path="password"           element={<ChangePassword />} />
            <Route path="mpin"               element={<MPin />} />
            <Route path="profile"            element={<ProfilePage accentColor={PRIMARY} gradientFrom="#1a56db" gradientTo="#3b7af7" portalLabel="Distributor Portal" />} />
            <Route path="*"                  element={<DashboardPage />} />
          </Routes>
        </Box>
      </Box>
    </Box>
  );
}
