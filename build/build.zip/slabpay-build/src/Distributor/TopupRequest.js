// src/Distributor/TopupRequest.js
import { useState } from 'react';
import { Box, Typography, TextField, Button, Paper, Alert, CircularProgress } from '@mui/material';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { cardStyle, inputStyle, btnPrimary, C } from './lightStyles';
import { submitTopUpRequest, getUser } from '../services/distributorApi';

const toWords = (n) => {
  const ones = ['','One','Two','Three','Four','Five','Six','Seven','Eight','Nine','Ten',
    'Eleven','Twelve','Thirteen','Fourteen','Fifteen','Sixteen','Seventeen','Eighteen','Nineteen'];
  const tens = ['','','Twenty','Thirty','Forty','Fifty','Sixty','Seventy','Eighty','Ninety'];
  if (!n || n === 0) return '';
  let w = '';
  if (Math.floor(n / 100000)) { w += toWords(Math.floor(n / 100000)) + ' Lakh '; n %= 100000; }
  if (Math.floor(n / 1000))   { w += toWords(Math.floor(n / 1000))   + ' Thousand '; n %= 1000; }
  if (Math.floor(n / 100))    { w += toWords(Math.floor(n / 100))    + ' Hundred '; n %= 100; }
  if (n >= 20) { w += tens[Math.floor(n / 10)] + ' '; n %= 10; }
  if (n > 0)    w += ones[n] + ' ';
  return w.trim();
};

const MODES = ['cash', 'neft', 'imps', 'rtgs'];

export default function TopUpRequest() {
  const userId   = getUser('userId');
  // parentId = the Super Distributor who will approve this request
  const parentId = getUser('parentId') || getUser('superDistId');

  const [mode,        setMode]        = useState('cash');
  const [amount,      setAmount]      = useState('');
  const [bankName,    setBankName]    = useState('');
  const [utrNumber,   setUtrNumber]   = useState('');
  const [txnDate,     setTxnDate]     = useState('');
  const [remark,      setRemark]      = useState('');
  const [fileName,    setFileName]    = useState('');
  const [inWords,     setInWords]     = useState('');

  const [loading,     setLoading]     = useState(false);
  const [error,       setError]       = useState(null);
  const [success,     setSuccess]     = useState(null);

  const handleAmount = (val) => {
    setAmount(val);
    setInWords(val && Number(val) > 0 ? toWords(parseInt(val)) + ' Rupees Only' : '');
  };

  const handleClear = () => {
    setMode('cash'); setAmount(''); setBankName('');
    setUtrNumber(''); setTxnDate(''); setRemark('');
    setFileName(''); setInWords('');
    setError(null); setSuccess(null);
  };

  const handleSubmit = async () => {
    // Client-side validation
    if (!amount || Number(amount) < 1)
      return setError('Please enter a valid amount (minimum ₹1).');
    if (!parentId)
      return setError('Parent account not found. Please log out and log in again.');
    if (mode !== 'cash' && !utrNumber.trim())
      return setError('UTR / Reference number is required for non-cash payments.');
    if (mode !== 'cash' && !txnDate)
      return setError('Transaction date is required for non-cash payments.');

    setLoading(true);
    setError(null);
    setSuccess(null);
    try {
      await submitTopUpRequest({
        requesterId:       Number(userId),
        parentId:          Number(parentId),
        amount:            Number(amount),
        mode:              mode.toUpperCase(),
        depositBankId:     null,
        depositTransId:    utrNumber.trim() || null,
        depositedDate:     txnDate || null,
        remark:            remark.trim() || null,
        slipFile:          fileName || null,
      });
      setSuccess(`Top-up request for ₹${Number(amount).toLocaleString('en-IN')} submitted successfully!`);
      handleClear();
    } catch (e) {
      setError(e.response?.data?.error || 'Failed to submit request. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ background: 'linear-gradient(135deg, #e8efff, #f0f5ff)', borderRadius: '14px',
        px: 3, py: 1.5, mb: 2, borderLeft: '4px solid #1a56db' }}>
        <Typography sx={{ fontSize: 11, fontWeight: 700, letterSpacing: '2px',
          textTransform: 'uppercase', color: C.primary }}>Welcome to Slabpay</Typography>
      </Box>
      <Typography sx={{ fontSize: 20, fontWeight: 800, mb: 3, color: C.text1 }}>Top Up Request</Typography>

      {error   && <Alert severity="error"   sx={{ mb: 2, borderRadius: '10px' }} onClose={() => setError(null)}>{error}</Alert>}
      {success && (
        <Alert severity="success" icon={<CheckCircleIcon />}
          sx={{ mb: 2, borderRadius: '10px', fontWeight: 600 }}
          onClose={() => setSuccess(null)}>
          {success}
        </Alert>
      )}

      <Paper sx={{ ...cardStyle, maxWidth: 740 }}>
        <Typography sx={{ fontSize: 15, fontWeight: 700, color: C.text1,
          mb: 2.5, pb: 2, borderBottom: `1px solid ${C.border}` }}>
          Submit New Request
        </Typography>

        {/* Mode selector */}
        <Box sx={{ mb: 3 }}>
          <Typography sx={{ fontSize: 12, fontWeight: 600, color: C.text3,
            textTransform: 'uppercase', letterSpacing: '0.8px', mb: 1 }}>
            Payment Mode
          </Typography>
          <Box sx={{ display: 'flex', gap: 1 }}>
            {MODES.map((m) => (
              <Box key={m} onClick={() => setMode(m)} sx={{
                px: 2.5, py: 1, borderRadius: '8px', cursor: 'pointer',
                fontWeight: mode === m ? 700 : 500, fontSize: 13,
                background: mode === m ? C.primaryLight : C.surface2,
                color:      mode === m ? C.primary    : C.text2,
                border:     `1.5px solid ${mode === m ? C.primary : C.border}`,
                textTransform: 'uppercase', letterSpacing: '0.5px',
                transition: 'all 0.18s ease',
              }}>{m}</Box>
            ))}
          </Box>
        </Box>

        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, gap: 2 }}>
          <TextField label="Amount (₹)" type="number" value={amount}
            onChange={(e) => handleAmount(e.target.value)}
            inputProps={{ min: 1 }} fullWidth sx={inputStyle} />
          <TextField label="Bank Name" value={bankName}
            onChange={(e) => setBankName(e.target.value)} fullWidth sx={inputStyle} />

          {mode !== 'cash' && (
            <>
              <TextField label="Reference / UTR Number" value={utrNumber}
                onChange={(e) => setUtrNumber(e.target.value)} fullWidth sx={inputStyle} />
              <TextField type="date" label="Transaction Date" value={txnDate}
                onChange={(e) => setTxnDate(e.target.value)}
                InputLabelProps={{ shrink: true }} fullWidth sx={inputStyle} />
            </>
          )}

          <TextField label="Remark (optional)" value={remark}
            onChange={(e) => setRemark(e.target.value)}
            sx={{ ...inputStyle, gridColumn: '1 / -1' }} fullWidth />

          {inWords && (
            <Box sx={{ gridColumn: '1 / -1', background: C.primaryLight, borderRadius: '10px',
              px: 2, py: 1.5, border: `1px solid ${C.border}` }}>
              <Typography sx={{ fontSize: 11, color: C.text3, fontWeight: 600, mb: 0.3 }}>
                Amount in Words
              </Typography>
              <Typography sx={{ fontSize: 13, fontWeight: 700, color: C.primary }}>{inWords}</Typography>
            </Box>
          )}
        </Box>

        {/* Upload */}
        <Box onClick={() => document.getElementById('slip-upload').click()} sx={{
          mt: 2.5, border: `2px dashed ${fileName ? C.primary : C.border2}`,
          borderRadius: '12px', p: 3, textAlign: 'center', cursor: 'pointer',
          transition: 'all 0.2s ease',
          background: fileName ? C.primaryLight : 'transparent',
          '&:hover': { borderColor: C.primary, background: C.primaryLight },
        }}>
          <input id="slip-upload" type="file" hidden accept="image/*,.pdf"
            onChange={(e) => setFileName(e.target.files?.[0]?.name || '')} />
          <UploadFileIcon sx={{ color: fileName ? C.primary : C.text3, fontSize: 32, mb: 1 }} />
          <Typography sx={{ fontSize: 13, fontWeight: 600, color: fileName ? C.primary : C.text2 }}>
            {fileName || 'Upload Payment Slip'}
          </Typography>
          <Typography sx={{ fontSize: 11, color: C.text3, mt: 0.5 }}>PNG, JPG, PDF — max 5MB</Typography>
        </Box>

        {/* Actions */}
        <Box sx={{ mt: 3, display: 'flex', justifyContent: 'flex-end', gap: 1.5 }}>
          <Button onClick={handleClear} disabled={loading}
            sx={{ color: C.text2, borderRadius: '10px', px: 3, textTransform: 'none',
              fontWeight: 600, border: `1px solid ${C.border}`,
              '&:hover': { background: C.surface2 } }}>
            Clear
          </Button>
          <Button onClick={handleSubmit} disabled={loading}
            startIcon={loading ? <CircularProgress size={16} color="inherit" /> : null}
            sx={{ ...btnPrimary, height: '42px', px: 4 }}>
            {loading ? 'Submitting…' : 'Submit Request'}
          </Button>
        </Box>
      </Paper>
    </Box>
  );
}
