// src/Distributor/DashboardPage.js
import { useState, useEffect } from 'react';
import { Box, Typography, Button, CircularProgress, Alert } from '@mui/material';
import { Download, Add } from '@mui/icons-material';
import {
  BarChart as ReBarChart, Bar, XAxis,
  ResponsiveContainer, Tooltip as RTooltip,
} from 'recharts';
import {
  getDashboardStats, getRecentLedger,
  getUser, today, daysAgo,
} from '../services/distributorApi';

// ── Design tokens ─────────────────────────────────────────────────────────────
const C = {
  primary:       '#1a56db', primaryLight:  '#e8efff',
  secondary:     '#0e9f6e', secondaryLight:'#e6faf3',
  danger:        '#e02424', dangerLight:   '#fde8e8',
  warning:       '#d97706', warningLight:  '#fef3c7',
  surface:       '#ffffff', surface2:      '#f8faff',
  surface3:      '#f0f4fb', border:        '#e5eaf5',
  border2:       '#d0d8ee', text1:         '#0f1623',
  text2:         '#3a4563', text3:         '#7a8aab',
};

const fmt = (v) =>
  Number(v || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

// ── Stat Card ─────────────────────────────────────────────────────────────────
function StatCard({ ico, label, value, sub, accent, accentLight, tag, loading }) {
  return (
    <Box sx={{
      background: C.surface, border: `1px solid ${C.border}`, borderRadius: '16px',
      p: '20px', position: 'relative', overflow: 'hidden', cursor: 'pointer',
      transition: 'all 0.25s ease',
      '&:hover': { transform: 'translateY(-4px)', boxShadow: '0 12px 32px rgba(15,22,35,0.1)' },
      '&::before': {
        content: '""', position: 'absolute', top: 0, right: 0,
        width: 100, height: 100, borderRadius: '50%',
        background: accent, opacity: 0.08, transform: 'translate(30%,-30%)',
      },
    }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
        <Box sx={{ width: 40, height: 40, borderRadius: '12px', background: accentLight,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 16, fontWeight: 800, color: accent }}>
          {ico}
        </Box>
        <Box sx={{ fontSize: 10, fontWeight: 700, px: 1.5, py: 0.5, borderRadius: '20px',
          background: accentLight, color: accent }}>
          {tag}
        </Box>
      </Box>
      <Typography sx={{ fontSize: 11, fontWeight: 600, letterSpacing: '1px',
        textTransform: 'uppercase', color: C.text3, mb: 0.5 }}>
        {label}
      </Typography>
      {loading
        ? <CircularProgress size={22} sx={{ color: accent, mt: 0.5 }} />
        : <Typography sx={{ fontSize: 26, fontWeight: 800, color: accent, letterSpacing: '-1px' }}>
            ₹{value}
          </Typography>
      }
      <Typography sx={{ fontSize: 12, color: C.text3, mt: 0.5 }}>{sub}</Typography>
    </Box>
  );
}

// ── Main component ─────────────────────────────────────────────────────────────
export default function DashboardPage() {
  const userId   = getUser('userId');
  const userName = getUser('userName');

  const [clock,  setClock]  = useState('');
  const [stats,  setStats]  = useState(null);
  const [txns,   setTxns]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [error,  setError]  = useState(null);

  // ── Live clock ──────────────────────────────────────────────────────────────
  useEffect(() => {
    const tick = () =>
      setClock(new Date().toLocaleTimeString('en-IN',
        { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  // ── Fetch dashboard data ────────────────────────────────────────────────────
  useEffect(() => {
    if (!userId) return;
    const load = async () => {
      setLoading(true);
      setError(null);
      try {
        const [statsRes, txnRes] = await Promise.all([
          getDashboardStats(userId),
          getRecentLedger(userId, daysAgo(7), today()),
        ]);
        setStats(statsRes.data.data);
        setTxns((txnRes.data.data || []).slice(0, 5)); // last 5 entries
      } catch (e) {
        setError(e.response?.data?.error || 'Failed to load dashboard data');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [userId]);

  // ── Build stat cards from live data ────────────────────────────────────────
  const statCards = [
    {
      ico: '₹', label: 'Current Balance',
      value: fmt(stats?.currentBalance),
      sub: 'Updated just now',
      accent: C.primary, accentLight: C.primaryLight, tag: 'Live',
    },
    {
      ico: '↓', label: "Today Cr. Balance",
      value: fmt(stats?.todayCreditBalance),
      sub: stats?.todayCreditBalance > 0 ? `+₹${fmt(stats?.todayCreditBalance)} today` : 'No credits today',
      accent: C.secondary, accentLight: C.secondaryLight, tag: 'Today',
    },
    {
      ico: '↑', label: "Today Dr. Balance",
      value: fmt(stats?.todayDebitBalance),
      sub: stats?.todayDebitBalance > 0 ? `-₹${fmt(stats?.todayDebitBalance)} today` : 'No debits today',
      accent: C.danger, accentLight: C.dangerLight, tag: 'Today',
    },
    {
      ico: '👥', label: 'Total Retailers',
      value: stats?.totalRetailers ?? '—',
      sub: 'Under your account',
      accent: C.warning, accentLight: C.warningLight, tag: 'Total',
    },
  ];

  const quickAccess = [
    { emoji: '📋', name: 'Ledger Statement',  sub: 'View full ledger history',   accent: C.primary },
    { emoji: '🧾', name: 'Commission Report', sub: 'Monthly summary',            accent: '#7c3aed' },
    { emoji: '👥', name: 'Retailer Directory',sub: `${stats?.totalRetailers ?? 0} active retailers`, accent: C.warning },
    { emoji: '🔐', name: 'Security Settings', sub: 'Password · M-Pin',           accent: C.danger },
  ];

  const greeting = (() => {
    const h = new Date().getHours();
    if (h < 12) return 'Good Morning';
    if (h < 17) return 'Good Afternoon';
    return 'Good Evening';
  })();

  return (
    <Box sx={{ p: '28px 28px 48px', background: '#f8faff', minHeight: '100%' }}>

      {/* Error banner */}
      {error && (
        <Alert severity="error" onClose={() => setError(null)} sx={{ mb: 2, borderRadius: '10px' }}>
          {error}
        </Alert>
      )}

      {/* Live ticker */}
      <Box sx={{
        display: 'flex', alignItems: 'center', gap: 2,
        background: C.surface, border: `1px solid ${C.border}`, borderRadius: '12px',
        px: 2.5, py: 1.5, mb: 3, boxShadow: '0 1px 4px rgba(15,22,35,0.05)',
      }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, background: C.primaryLight,
          borderRadius: '8px', px: 1.2, py: 0.5, flexShrink: 0 }}>
          <Box sx={{ width: 6, height: 6, borderRadius: '50%', background: C.primary,
            animation: 'pulse 2s infinite',
            '@keyframes pulse': { '0%,100%': { opacity: 1 }, '50%': { opacity: 0.4 } } }} />
          <Typography sx={{ fontSize: 10, fontWeight: 700, color: C.primary, letterSpacing: '1px' }}>
            LIVE
          </Typography>
        </Box>
        <Typography sx={{ fontSize: 13, color: C.text2 }}>
          Account: <strong style={{ color: C.text1 }}>{getUser('accountCode') || userId}</strong>
          <span style={{ color: C.text3, margin: '0 6px' }}>·</span>
          <strong style={{ color: C.text1 }}>{userName}</strong>
        </Typography>
        <Typography sx={{ ml: 'auto', fontSize: 12, color: C.text3, flexShrink: 0, fontWeight: 700 }}>
          {clock}
        </Typography>
      </Box>

      {/* Header */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 3 }}>
        <Box>
          <Typography sx={{ fontSize: 24, fontWeight: 800, color: C.text1, letterSpacing: '-0.5px' }}>
            {greeting}, <span style={{ color: C.primary }}>{userName}</span> 👋
          </Typography>
          <Typography sx={{ fontSize: 14, color: C.text3, mt: 0.5 }}>
            Here's your financial overview for today.
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 1.5 }}>
          <Button startIcon={<Download sx={{ fontSize: '14px !important' }} />}
            sx={{
              background: C.surface, border: `1px solid ${C.border2}`, color: C.text2,
              borderRadius: '10px', px: 2, py: 1, fontSize: 13, fontWeight: 600, textTransform: 'none',
              '&:hover': { background: C.surface3, borderColor: C.primary },
            }}>Export</Button>
          <Button startIcon={<Add sx={{ fontSize: '14px !important' }} />}
            sx={{
              background: `linear-gradient(135deg, ${C.primary}, #3b7af7)`,
              color: '#fff', borderRadius: '10px', px: 2, py: 1, fontSize: 13,
              fontWeight: 600, textTransform: 'none',
              boxShadow: '0 4px 14px rgba(26,86,219,0.3)',
              '&:hover': { boxShadow: '0 6px 20px rgba(26,86,219,0.45)', transform: 'translateY(-1px)' },
            }}>Add Balance</Button>
        </Box>
      </Box>

      {/* Stat Cards */}
      <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 2, mb: 3 }}>
        {statCards.map((card, i) => (
          <StatCard key={i} loading={loading} {...card} />
        ))}
      </Box>

      {/* Bottom panels */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
        <Typography sx={{ fontSize: 14, fontWeight: 700, color: C.text1, whiteSpace: 'nowrap' }}>
          Activity & Transactions
        </Typography>
        <Box sx={{ flex: 1, height: 1, background: C.border }} />
        <Typography sx={{ fontSize: 12, color: C.primary, cursor: 'pointer', whiteSpace: 'nowrap', fontWeight: 600 }}>
          View Reports →
        </Typography>
      </Box>

      <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 2 }}>

        {/* Recent Transactions */}
        <Box sx={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: '16px', p: 3 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2.5 }}>
            <Typography sx={{ fontSize: 14, fontWeight: 700, color: C.text1 }}>
              Recent Transactions (Last 7 Days)
            </Typography>
            <Typography sx={{ fontSize: 12, color: C.primary, cursor: 'pointer', fontWeight: 600 }}>
              See all →
            </Typography>
          </Box>

          {loading
            ? <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
                <CircularProgress size={28} />
              </Box>
            : txns.length === 0
              ? <Box sx={{ textAlign: 'center', py: 5, color: C.text3 }}>
                  <Box sx={{ fontSize: 36, mb: 1 }}>📭</Box>
                  <Typography sx={{ fontSize: 13, color: C.text2 }}>No transactions in the last 7 days</Typography>
                </Box>
              : <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
                  {txns.map((tx, i) => (
                    <Box key={i} sx={{
                      display: 'flex', alignItems: 'center', gap: 1.5,
                      px: 1, py: 1.2, borderRadius: '10px',
                      '&:hover': { background: C.surface2 },
                    }}>
                      <Box sx={{
                        width: 36, height: 36, borderRadius: '10px',
                        background: tx.oType === 'C' ? C.secondaryLight : C.dangerLight,
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        fontSize: 15, flexShrink: 0,
                      }}>
                        {tx.oType === 'C' ? '📥' : '📤'}
                      </Box>
                      <Box sx={{ flex: 1 }}>
                        <Typography sx={{ fontSize: 13.5, fontWeight: 600, color: C.text1 }}>
                          {tx.narration || tx.eType}
                        </Typography>
                        <Typography sx={{ fontSize: 11.5, color: C.text3 }}>
                          {new Date(tx.createdDate).toLocaleString('en-IN')}
                        </Typography>
                      </Box>
                      <Typography sx={{
                        fontSize: 13.5, fontWeight: 700,
                        color: tx.oType === 'C' ? C.secondary : C.danger,
                      }}>
                        {tx.oType === 'C' ? '+' : '−'}₹{fmt(tx.amount)}
                      </Typography>
                    </Box>
                  ))}
                </Box>
          }
        </Box>

        {/* Quick Access */}
        <Box sx={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: '16px', p: 3 }}>
          <Typography sx={{ fontSize: 14, fontWeight: 700, color: C.text1, mb: 2 }}>
            Quick Access
          </Typography>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
            {quickAccess.map((item, i) => (
              <Box key={i} sx={{
                display: 'flex', alignItems: 'center', gap: 1.5, p: 1.5,
                borderRadius: '12px', background: C.surface2, border: `1px solid ${C.border}`,
                cursor: 'pointer', transition: 'all 0.2s',
                '&:hover': { borderColor: item.accent, transform: 'translateX(4px)',
                  boxShadow: '0 4px 12px rgba(15,22,35,0.06)' },
              }}>
                <Box sx={{
                  width: 36, height: 36, borderRadius: '10px',
                  background: `${item.accent}18`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 17, flexShrink: 0,
                }}>{item.emoji}</Box>
                <Box sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 13, fontWeight: 600, color: C.text1 }}>
                    {item.name}
                  </Typography>
                  <Typography sx={{ fontSize: 11.5, color: C.text3 }}>{item.sub}</Typography>
                </Box>
                <Typography sx={{ color: C.text3, fontSize: 18, lineHeight: 1 }}>›</Typography>
              </Box>
            ))}
          </Box>
        </Box>
      </Box>
    </Box>
  );
}
