// src/Distributor/ChangePassword.js
import { useState } from 'react';
import {
  Box, Typography, TextField, Button, InputAdornment,
  IconButton, Alert, CircularProgress,
} from '@mui/material';
import LockIcon       from '@mui/icons-material/Lock';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import { cardStyle, inputStyle, btnPrimary, C } from './lightStyles';
import { changePassword, getUser } from '../services/distributorApi';

export default function ChangePassword() {
  const userId = getUser('userId');

  const [oldPassword,  setOldPassword]  = useState('');
  const [newPassword,  setNewPassword]  = useState('');
  const [confirmPass,  setConfirmPass]  = useState('');
  const [showOld,      setShowOld]      = useState(false);
  const [showNew,      setShowNew]      = useState(false);
  const [showConfirm,  setShowConfirm]  = useState(false);

  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState(null);
  const [success,  setSuccess]  = useState(null);

  const handleSubmit = async () => {
    setError(null);
    setSuccess(null);

    // Validation
    if (!oldPassword)          return setError('Please enter your current password.');
    if (newPassword.length < 8) return setError('New password must be at least 8 characters.');
    if (newPassword !== confirmPass) return setError('New passwords do not match.');
    if (newPassword === oldPassword) return setError('New password must differ from current password.');

    setLoading(true);
    try {
      await changePassword(userId, {
        oldPassword,
        newPassword,
      });
      setSuccess('Password changed successfully! Please use your new password on next login.');
      setOldPassword('');
      setNewPassword('');
      setConfirmPass('');
    } catch (e) {
      setError(e.response?.data?.error || 'Failed to change password. Check your current password.');
    } finally {
      setLoading(false);
    }
  };

  const toggleAdornment = (show, setShow) => (
    <InputAdornment position="end">
      <IconButton size="small" onClick={() => setShow(!show)} edge="end">
        {show ? <VisibilityOffIcon sx={{ fontSize: 18 }} /> : <VisibilityIcon sx={{ fontSize: 18 }} />}
      </IconButton>
    </InputAdornment>
  );

  return (
    <Box sx={{ p: 4 }}>
      <Box sx={{ background: 'linear-gradient(135deg, #e8efff, #f0f5ff)', borderRadius: '14px',
        px: 3, py: 1.5, mb: 3, borderLeft: '4px solid #1a56db' }}>
        <Typography sx={{ fontSize: 11, fontWeight: 700, letterSpacing: '2px',
          textTransform: 'uppercase', color: C.primary }}>Welcome to Slabpay</Typography>
      </Box>
      <Typography sx={{ fontSize: 22, fontWeight: 800, mb: 3, color: C.text1 }}>Change Password</Typography>

      {error   && <Alert severity="error"   sx={{ mb: 2, borderRadius: '10px' }} onClose={() => setError(null)}>{error}</Alert>}
      {success && <Alert severity="success" sx={{ mb: 2, borderRadius: '10px', fontWeight: 600 }} onClose={() => setSuccess(null)}>{success}</Alert>}

      <Box sx={{ ...cardStyle, maxWidth: 640 }}>
        <Box sx={{ mb: 2.5 }}>
          <Box sx={{ width: 48, height: 48, borderRadius: '14px', background: C.primaryLight,
            display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 2 }}>
            <LockIcon sx={{ color: C.primary, fontSize: 24 }} />
          </Box>
          <Typography sx={{ fontSize: 14, color: C.text2, lineHeight: 1.6 }}>
            Your password must be at least 8 characters and should not match your current password.
          </Typography>
        </Box>

        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <TextField
            label="Current Password" type={showOld ? 'text' : 'password'}
            value={oldPassword} onChange={(e) => setOldPassword(e.target.value)}
            fullWidth sx={inputStyle}
            InputProps={{
              startAdornment: <InputAdornment position="start"><LockIcon sx={{ color: C.text3, fontSize: 18 }} /></InputAdornment>,
              endAdornment: toggleAdornment(showOld, setShowOld),
            }}
          />
          <TextField
            label="New Password" type={showNew ? 'text' : 'password'}
            value={newPassword} onChange={(e) => setNewPassword(e.target.value)}
            fullWidth sx={inputStyle}
            InputProps={{
              startAdornment: <InputAdornment position="start"><LockIcon sx={{ color: C.text3, fontSize: 18 }} /></InputAdornment>,
              endAdornment: toggleAdornment(showNew, setShowNew),
            }}
          />
          <TextField
            label="Re-Enter New Password" type={showConfirm ? 'text' : 'password'}
            value={confirmPass} onChange={(e) => setConfirmPass(e.target.value)}
            fullWidth sx={inputStyle}
            error={confirmPass.length > 0 && confirmPass !== newPassword}
            helperText={confirmPass.length > 0 && confirmPass !== newPassword ? 'Passwords do not match' : ''}
            InputProps={{
              startAdornment: <InputAdornment position="start"><LockIcon sx={{ color: C.text3, fontSize: 18 }} /></InputAdornment>,
              endAdornment: toggleAdornment(showConfirm, setShowConfirm),
            }}
          />
        </Box>

        <Box sx={{ mt: 3, display: 'flex', justifyContent: 'flex-end', gap: 1.5 }}>
          <Button onClick={() => { setOldPassword(''); setNewPassword(''); setConfirmPass(''); setError(null); }}
            disabled={loading}
            sx={{ color: C.text2, borderRadius: '10px', px: 3, textTransform: 'none',
              fontWeight: 600, border: `1px solid ${C.border}`, '&:hover': { background: C.surface2 } }}>
            Clear
          </Button>
          <Button variant="contained" onClick={handleSubmit} disabled={loading}
            startIcon={loading ? <CircularProgress size={16} color="inherit" /> : null}
            sx={{ ...btnPrimary, height: '42px', px: 4 }}>
            {loading ? 'Changing…' : 'Change Password'}
          </Button>
        </Box>
      </Box>
    </Box>
  );
}
