// src/Distributor/MPin.js
import { useState } from 'react';
import {
  Box, Typography, TextField, Button, InputAdornment,
  IconButton, Alert, CircularProgress,
} from '@mui/material';
import VisibilityIcon    from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import { cardStyle, inputStyle, btnPrimary, C } from './lightStyles';
import { changeMPin, getUser } from '../services/distributorApi';

export default function MPin() {
  const userId = getUser('userId');

  const [oldMPin,   setOldMPin]   = useState('');
  const [newMPin,   setNewMPin]   = useState('');
  const [confirmPin,setConfirmPin]= useState('');
  const [showOld,   setShowOld]   = useState(false);
  const [showNew,   setShowNew]   = useState(false);
  const [showConf,  setShowConf]  = useState(false);

  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState(null);
  const [success,  setSuccess]  = useState(null);

  const onlyDigits = (val) => val.replace(/\D/g, '');

  const handleSubmit = async () => {
    setError(null);
    setSuccess(null);

    if (!oldMPin)                         return setError('Please enter your current M-Pin.');
    if (newMPin.length < 4)               return setError('New M-Pin must be 4–6 digits.');
    if (newMPin !== confirmPin)           return setError('New M-Pins do not match.');
    if (newMPin === oldMPin)              return setError('New M-Pin must differ from current M-Pin.');

    setLoading(true);
    try {
      await changeMPin(userId, { oldMPin, newMPin });
      setSuccess('M-Pin updated successfully!');
      setOldMPin(''); setNewMPin(''); setConfirmPin('');
    } catch (e) {
      setError(e.response?.data?.error || 'Failed to update M-Pin. Check your current M-Pin.');
    } finally {
      setLoading(false);
    }
  };

  const toggleAdornment = (show, setShow) => (
    <InputAdornment position="end">
      <IconButton size="small" onClick={() => setShow(!show)} edge="end">
        {show ? <VisibilityOffIcon sx={{ fontSize: 18 }} /> : <VisibilityIcon sx={{ fontSize: 18 }} />}
      </IconButton>
    </InputAdornment>
  );

  return (
    <Box sx={{ p: 4 }}>
      <Box sx={{ background: 'linear-gradient(135deg, #e8efff, #f0f5ff)', borderRadius: '14px',
        px: 3, py: 1.5, mb: 3, borderLeft: '4px solid #1a56db' }}>
        <Typography sx={{ fontSize: 11, fontWeight: 700, letterSpacing: '2px',
          textTransform: 'uppercase', color: C.primary }}>Welcome to Slabpay</Typography>
      </Box>
      <Typography sx={{ fontSize: 22, fontWeight: 800, mb: 3, color: C.text1 }}>Change M-Pin</Typography>

      {error   && <Alert severity="error"   sx={{ mb: 2, borderRadius: '10px' }} onClose={() => setError(null)}>{error}</Alert>}
      {success && <Alert severity="success" sx={{ mb: 2, borderRadius: '10px', fontWeight: 600 }} onClose={() => setSuccess(null)}>{success}</Alert>}

      <Box sx={{ ...cardStyle, maxWidth: 640 }}>
        <Box sx={{ mb: 2.5 }}>
          <Box sx={{ width: 48, height: 48, borderRadius: '14px', background: '#fef3c7',
            display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 2 }}>
            <span style={{ fontSize: 22 }}>🔑</span>
          </Box>
          <Typography sx={{ fontSize: 14, color: C.text2, lineHeight: 1.6 }}>
            Your M-Pin is a 4–6 digit numeric PIN used for quick transaction authentication.
            Do not share it with anyone.
          </Typography>
        </Box>

        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {[
            { label: 'Current M-Pin',    value: oldMPin,    set: (v) => setOldMPin(onlyDigits(v)),    show: showOld,    setShow: setShowOld },
            { label: 'New M-Pin',        value: newMPin,    set: (v) => setNewMPin(onlyDigits(v)),    show: showNew,    setShow: setShowNew },
            { label: 'Re-Enter M-Pin',   value: confirmPin, set: (v) => setConfirmPin(onlyDigits(v)), show: showConf,   setShow: setShowConf,
              error: confirmPin.length > 0 && confirmPin !== newMPin,
              helperText: confirmPin.length > 0 && confirmPin !== newMPin ? 'M-Pins do not match' : '' },
          ].map(({ label, value, set, show, setShow, error: fe, helperText }) => (
            <TextField
              key={label} label={label}
              type={show ? 'text' : 'password'}
              value={value} onChange={(e) => set(e.target.value)}
              inputProps={{ maxLength: 6, inputMode: 'numeric' }}
              error={!!fe} helperText={helperText}
              fullWidth sx={inputStyle}
              InputProps={{ endAdornment: toggleAdornment(show, setShow) }}
            />
          ))}
        </Box>

        <Box sx={{ mt: 3, display: 'flex', justifyContent: 'flex-end', gap: 1.5 }}>
          <Button onClick={() => { setOldMPin(''); setNewMPin(''); setConfirmPin(''); setError(null); }}
            disabled={loading}
            sx={{ color: C.text2, borderRadius: '10px', px: 3, textTransform: 'none',
              fontWeight: 600, border: `1px solid ${C.border}`, '&:hover': { background: C.surface2 } }}>
            Clear
          </Button>
          <Button variant="contained" onClick={handleSubmit} disabled={loading}
            startIcon={loading ? <CircularProgress size={16} color="inherit" /> : null}
            sx={{ ...btnPrimary, height: '42px', px: 4 }}>
            {loading ? 'Updating…' : 'Update M-Pin'}
          </Button>
        </Box>
      </Box>
    </Box>
  );
}
