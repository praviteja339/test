// src/Distributor/CommisionDetails.js
import { useState } from 'react';
import { Box, Typography, TextField, Button, Grid, Paper, CircularProgress, Alert }
  from '@mui/material';
import DownloadIcon from '@mui/icons-material/Download';
import SearchIcon   from '@mui/icons-material/Search';
import { cardStyle, statCard, inputStyle, btnPrimary, btnOutline, tableHeader, C }
  from './lightStyles';
import { getCommissionDetails, getUser, today, daysAgo } from '../services/distributorApi';

const fmt   = (v) => Number(v || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 });
const fmtDt = (dt) => dt ? new Date(dt).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }) : '—';

export default function CommisionDetails() {
  const userId = getUser('userId');

  const [from,    setFrom]    = useState(daysAgo(30));
  const [to,      setTo]      = useState(today());
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState(null);

  const fetchData = async () => {
    if (!from || !to) return setError('Please select both From and To dates.');
    setLoading(true);
    setError(null);
    try {
      const res = await getCommissionDetails(userId, from, to);
      setSummary(res.data.data);
    } catch (e) {
      setError(e.response?.data?.error || 'Failed to load commission details.');
    } finally {
      setLoading(false);
    }
  };

  const entries = summary?.entries || [];

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ background: 'linear-gradient(135deg, #e8efff, #f0f5ff)', borderRadius: '14px',
        px: 3, py: 1.5, mb: 2, borderLeft: '4px solid #1a56db' }}>
        <Typography sx={{ fontSize: 11, fontWeight: 700, letterSpacing: '2px',
          textTransform: 'uppercase', color: C.primary }}>Welcome to Slabpay</Typography>
      </Box>
      <Typography sx={{ fontSize: 20, fontWeight: 800, mb: 3, color: C.text1 }}>Commission Details</Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 2, borderRadius: '10px' }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {/* Filter bar */}
      <Grid container spacing={2} alignItems="center" mb={1}>
        <Grid item xs={12} md={3}>
          <TextField type="date" label="From Date" value={from}
            onChange={(e) => setFrom(e.target.value)}
            InputLabelProps={{ shrink: true }} fullWidth sx={inputStyle} />
        </Grid>
        <Grid item xs={12} md={3}>
          <TextField type="date" label="To Date" value={to}
            onChange={(e) => setTo(e.target.value)}
            InputLabelProps={{ shrink: true }} fullWidth sx={inputStyle} />
        </Grid>
        <Grid item xs={12} md={3}>
          <Button startIcon={loading ? <CircularProgress size={16} color="inherit" /> : <SearchIcon />}
            sx={btnPrimary} fullWidth onClick={fetchData} disabled={loading}>
            {loading ? 'Loading…' : 'Get Data'}
          </Button>
        </Grid>
        <Grid item xs={12} md={3} textAlign="right">
          <Button startIcon={<DownloadIcon />} sx={btnOutline} disabled={entries.length === 0}>
            Export Excel
          </Button>
        </Grid>
      </Grid>

      {/* Summary cards */}
      <Grid container spacing={2} mt={0.5}>
        {[
          { label: 'Opening Bal.',      value: `₹${fmt(summary?.openingBalance)}`,  accent: C.primary },
          { label: 'Total Commission',  value: `₹${fmt(summary?.totalCommission)}`, accent: C.secondary },
          { label: 'Entries',           value: entries.length,                       accent: '#0891b2' },
          { label: 'Closing Bal.',      value: `₹${fmt(summary?.closingBalance)}`,  accent: C.warning },
        ].map((item, i) => (
          <Grid item xs={12} md={3} key={i}>
            <Paper sx={{ ...statCard, borderLeft: `4px solid ${item.accent}` }}>
              <Typography sx={{ fontSize: 11, color: C.text3, fontWeight: 600,
                textTransform: 'uppercase', letterSpacing: '0.5px' }}>{item.label}</Typography>
              <Typography sx={{ fontSize: 20, fontWeight: 800, color: item.accent, mt: 0.5 }}>
                {item.value}
              </Typography>
            </Paper>
          </Grid>
        ))}
      </Grid>

      {/* Table */}
      <Paper sx={{ ...cardStyle, mt: 3 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2.5 }}>
          <Typography sx={{ fontWeight: 700, fontSize: 15, color: C.text1 }}>
            Commission Entries
          </Typography>
          <Box sx={{ px: 2, py: 0.5, borderRadius: '20px', background: C.primaryLight,
            fontSize: 12, color: C.primary, fontWeight: 700 }}>
            {entries.length} Records
          </Box>
        </Box>

        <Box sx={{ ...tableHeader,
          gridTemplateColumns: '60px 1fr 1fr 1fr 1fr 1fr 1fr' }}>
          {['ID', 'Date', 'Service', 'Amount', 'Dist %', 'Retailer %', 'Comp Comm']
            .map((h) => <span key={h}>{h}</span>)}
        </Box>

        {loading
          ? <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}><CircularProgress /></Box>
          : entries.length === 0
            ? <Box sx={{ textAlign: 'center', py: 8, color: C.text3 }}>
                <Box sx={{ fontSize: 40, mb: 1 }}>📊</Box>
                <Typography sx={{ fontWeight: 600, color: C.text2 }}>No commission records</Typography>
                <Typography sx={{ fontSize: 12, mt: 0.5 }}>Select date range and click Get Data</Typography>
              </Box>
            : entries.map((row, i) => (
                <Box key={row.id} sx={{
                  display: 'grid', gridTemplateColumns: '60px 1fr 1fr 1fr 1fr 1fr 1fr',
                  gap: 1, py: 1.4, px: 1, borderRadius: '8px', alignItems: 'center',
                  background: i % 2 === 0 ? 'transparent' : C.surface2,
                  borderBottom: `1px solid ${C.border}`, fontSize: 13,
                }}>
                  <span style={{ color: C.text3, fontWeight: 600 }}>#{row.id}</span>
                  <span style={{ color: C.text3, fontSize: 12 }}>{fmtDt(row.createdDate)}</span>
                  <span style={{ fontSize: 12 }}>{row.sType || '—'}</span>
                  <span style={{ fontWeight: 700, color: C.secondary }}>₹{fmt(row.amount)}</span>
                  <span style={{ fontSize: 12 }}>{row.distributorPercentage ?? '—'}%</span>
                  <span style={{ fontSize: 12 }}>{row.retailPercentage ?? '—'}%</span>
                  <span style={{ fontSize: 12, color: C.text3 }}>₹{fmt(row.compCommission)}</span>
                </Box>
              ))
        }
      </Paper>
    </Box>
  );
}
