import { useEffect } from "react";
import { Navigate, useNavigate } from "react-router-dom";

/**
 * ProtectedRoute
 * – Redirects to /login if no token found in localStorage.
 * – Pushes a dummy history entry so the browser Back button cannot
 *   return to a protected page after logout.
 */
export default function ProtectedRoute({ children, adminRoute = false }) {
  const token = localStorage.getItem("token");
  const navigate = useNavigate();

  useEffect(() => {
    if (!token) return;

    // Push a sentinel so Back button stays inside the app
    window.history.pushState(null, "", window.location.href);

    const handlePopState = () => {
      // If token is gone (user logged out) push back to login
      if (!localStorage.getItem("token")) {
        navigate("/login", { replace: true });
      } else {
        // Still logged in → re-push so Back stays blocked
        window.history.pushState(null, "", window.location.href);
      }
    };

    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, [token, navigate]);

  if (!token) {
    const loginPath = adminRoute ? "/admin/login" : "/login";
    return <Navigate to={loginPath} replace />;
  }

  return children;
}
