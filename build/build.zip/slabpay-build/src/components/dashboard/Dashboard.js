import React from 'react';
import { Box, Typography, Grid, Card } from '@mui/material';
import HomeIcon from '@mui/icons-material/HomeRounded';
import AddCircleIcon from '@mui/icons-material/AddCircleOutlineRounded';
import HistoryIcon from '@mui/icons-material/HistoryRounded';
import AssessmentIcon from '@mui/icons-material/AssessmentRounded';
import AccountBalanceWalletIcon from '@mui/icons-material/AccountBalanceWalletRounded';

const C = { primary: '#1a56db', primaryLight: '#e8efff', secondary: '#0e9f6e', danger: '#e02424', warning: '#d97706', text1: '#0f1623', text2: '#3a4563', text3: '#7a8aab', border: '#e5eaf5', surface2: '#f8faff' };

const StatCard = ({ label, value, color, bg, icon, delay }) => (
  <Card sx={{
    bgcolor: bg, p: 3, borderRadius: '20px', border: `1px solid ${C.border}`,
    position: 'relative', overflow: 'hidden', cursor: 'pointer',
    boxShadow: '0 2px 8px rgba(15,22,35,0.05)',
    transition: 'all 0.25s ease',
    '&:hover': { transform: 'translateY(-4px)', boxShadow: '0 12px 30px rgba(15,22,35,0.1)', borderColor: color },
  }}>
    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
      <Box>
        <Typography sx={{ fontSize: 11, fontWeight: 700, color: C.text3, textTransform: 'uppercase', letterSpacing: '1px', mb: 1 }}>{label}</Typography>
        <Typography sx={{ fontSize: 28, fontWeight: 800, color }}>{value}</Typography>
      </Box>
      <Box sx={{ width: 42, height: 42, borderRadius: '12px', background: `${color}18`, display: 'flex', alignItems: 'center', justifyContent: 'center', color }}>
        {icon}
      </Box>
    </Box>
  </Card>
);

const statCards = [
  { label: 'Current Balance', value: '₹363.30', color: C.primary, bg: C.primaryLight, icon: <AccountBalanceWalletIcon /> },
  { label: 'Today Credit', value: '₹0.00', color: C.secondary, bg: '#e6faf3', icon: <AddCircleIcon /> },
  { label: 'Today Debit', value: '₹0.00', color: C.danger, bg: '#fde8e8', icon: <HistoryIcon /> },
  { label: 'Total Transactions', value: '0', color: C.warning, bg: '#fef3c7', icon: <AssessmentIcon /> },
];

const Dashboard = () => (
  <Box sx={{ p: 4, background: '#f8faff', minHeight: '100vh' }}>
    <Box sx={{ mb: 3 }}>
      <Typography sx={{ fontSize: 22, fontWeight: 800, color: C.text1 }}>Overview</Typography>
      <Typography sx={{ fontSize: 13, color: C.text3, mt: 0.5 }}>Your financial summary at a glance.</Typography>
    </Box>
    <Grid container spacing={2.5}>
      {statCards.map((card, i) => (
        <Grid item xs={12} sm={6} md={3} key={i}>
          <StatCard {...card} delay={i * 0.1} />
        </Grid>
      ))}
    </Grid>

    <Box sx={{ mt: 4, p: 4, background: '#ffffff', borderRadius: '20px', border: `1px solid ${C.border}`, boxShadow: '0 2px 8px rgba(15,22,35,0.04)' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
        <HomeIcon sx={{ color: C.primary }} />
        <Typography sx={{ fontSize: 15, fontWeight: 700, color: C.text1 }}>Dashboard</Typography>
      </Box>
      <Typography sx={{ fontSize: 14, color: C.text3, lineHeight: 1.8 }}>
        Welcome to the SlabPay management portal. Use the navigation to access all features.
      </Typography>
    </Box>
  </Box>
);

export default Dashboard;
