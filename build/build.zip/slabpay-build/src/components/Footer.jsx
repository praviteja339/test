import { Box, Container, Grid, Typography, Divider, IconButton, Link } from '@mui/material';
import LanguageIcon from '@mui/icons-material/Language';
import ShareIcon from '@mui/icons-material/Share';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import TwitterIcon from '@mui/icons-material/Twitter';

const SERVICES_LIST = ['Payment Processing', 'Digital Wallets', 'Fintech APIs', 'Global Payouts'];
const COMPANY_LIST  = [{ label: 'Our Story', page: 'about' }, { label: 'Careers' }, { label: 'Press Kit' }, { label: 'Compliance' }];
const LEGAL_LIST    = ['Privacy Policy', 'Terms of Service', 'Cookie Settings', 'SLA'];

export default function Footer({ navigate }) {
  return (
    <Box component="footer" sx={{ background: '#ffffff', borderTop: '1px solid #e5eaf5', pt: 8, pb: 3 }}>
      <Container maxWidth="lg">
        <Grid container spacing={5} sx={{ mb: 6 }}>
          <Grid item xs={12} md={4}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 2, cursor: 'pointer' }} onClick={() => navigate?.('home')}>
              <Box sx={{
                width: 36, height: 36, borderRadius: '10px',
                background: 'linear-gradient(135deg, #1a56db, #3b7af7)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: '#fff', fontWeight: 800, fontSize: 13,
                boxShadow: '0 4px 12px rgba(26,86,219,0.25)',
              }}>SP</Box>
              <Typography variant="h6" sx={{ fontWeight: 800, color: '#0f1623', letterSpacing: '-0.3px' }}>
                Slab<span style={{ color: '#1a56db' }}>Pay</span>
              </Typography>
            </Box>
            <Typography variant="body2" sx={{ mb: 3, lineHeight: 1.8, color: '#7a8aab', fontSize: 14 }}>
              The Precision Architect of Fintech. Building the infrastructure of tomorrow's
              global economy with uncompromising technical excellence.
            </Typography>
            <Box sx={{ display: 'flex', gap: 1 }}>
              {[<LanguageIcon sx={{ fontSize: 18 }} />, <TwitterIcon sx={{ fontSize: 18 }} />, <LinkedInIcon sx={{ fontSize: 18 }} />].map((icon, i) => (
                <IconButton key={i} size="small" sx={{
                  border: '1.5px solid #e5eaf5', color: '#7a8aab', borderRadius: '8px',
                  '&:hover': { color: '#1a56db', borderColor: '#1a56db', background: '#e8efff' },
                  transition: 'all 0.2s ease',
                }}>{icon}</IconButton>
              ))}
            </Box>
          </Grid>

          {[
            { title: 'Services', items: SERVICES_LIST.map(s => ({ label: s, page: 'services' })) },
            { title: 'Company', items: COMPANY_LIST },
            { title: 'Legal', items: LEGAL_LIST.map(l => ({ label: l })) },
          ].map(({ title, items }) => (
            <Grid item xs={6} sm={4} md={2} key={title}>
              <Typography variant="subtitle2" sx={{ mb: 2, color: '#0f1623', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '1px', fontSize: '0.7rem' }}>
                {title}
              </Typography>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                {items.map(({ label, page }) => (
                  <Link
                    key={label}
                    component="button"
                    underline="none"
                    onClick={() => page && navigate?.(page)}
                    sx={{
                      color: '#7a8aab', fontSize: '0.875rem', textAlign: 'left', fontWeight: 500,
                      '&:hover': { color: '#1a56db' }, transition: 'color 0.2s',
                    }}
                  >{label}</Link>
                ))}
              </Box>
            </Grid>
          ))}
        </Grid>

        <Divider sx={{ borderColor: '#f0f4fb', mb: 3 }} />
        <Box sx={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 2, alignItems: 'center' }}>
          <Typography variant="body2" color="#7a8aab" sx={{ fontSize: 13 }}>
            © 2025 SlabPay E Com Solutions Pvt. Ltd. All rights reserved.
          </Typography>
          <Box sx={{ display: 'flex', gap: 3 }}>
            {['Privacy', 'Terms', 'Cookies'].map((l) => (
              <Link key={l} href="#" underline="none" sx={{ color: '#7a8aab', fontSize: '0.8rem', fontWeight: 500, '&:hover': { color: '#1a56db' } }}>
                {l}
              </Link>
            ))}
          </Box>
        </Box>
      </Container>
    </Box>
  );
}
