import { useState } from "react";
import {
  Box, Typography, Paper, Avatar, TextField, Button,
  Grid, Divider, Chip, Alert,
} from "@mui/material";
import PersonIcon from "@mui/icons-material/Person";
import EditIcon from "@mui/icons-material/Edit";
import SaveIcon from "@mui/icons-material/Save";
import EmailIcon from "@mui/icons-material/Email";
import PhoneIcon from "@mui/icons-material/Phone";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import BadgeIcon from "@mui/icons-material/Badge";

const C = { border: "#e5eaf5", text1: "#0f1623", text2: "#3a4563", text3: "#7a8aab" };

/**
 * Reusable ProfilePage
 * Props:
 *   accentColor  — e.g. "#dc2626" (admin red), "#1a56db" (blue), "#7c3aed" (purple)
 *   gradientFrom — gradient start for avatar bg
 *   gradientTo   — gradient end
 *   portalLabel  — e.g. "Admin Portal", "Distributor Portal"
 *   userData     — object with name, email, mobile, role, userId, city, state, joined
 */
export default function ProfilePage({
  accentColor = "#dc2626",
  gradientFrom = "#dc2626",
  gradientTo   = "#f87171",
  portalLabel  = "Portal",
  userData,
}) {
  // Default: read from storage, fallback to props
  const stored = {
    name:    localStorage.getItem("userName")  || sessionStorage.getItem("userName")  || userData?.name    || "Admin User",
    email:   localStorage.getItem("email")     || sessionStorage.getItem("email")     || userData?.email   || "admin@slabpay.com",
    role:    localStorage.getItem("roleName")  || sessionStorage.getItem("roleName")  || userData?.role    || "Admin",
    userId:  localStorage.getItem("userId")    || sessionStorage.getItem("userId")    || userData?.userId  || "1",
    mobile:  userData?.mobile  || "9876543210",
    city:    userData?.city    || "Hyderabad",
    state:   userData?.state   || "Telangana",
    joined:  userData?.joined  || "01 Jan 2025",
  };

  const [form, setForm] = useState(stored);
  const [editing, setEditing] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setEditing(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const inputStyle = {
    "& .MuiOutlinedInput-root": {
      borderRadius: "10px",
      "& fieldset": { borderColor: C.border },
      "&:hover fieldset": { borderColor: accentColor },
      "&.Mui-focused fieldset": { borderColor: accentColor, borderWidth: 2 },
    },
    "& .MuiInputLabel-root.Mui-focused": { color: accentColor },
  };

  const initials = form.name
    .split(" ")
    .map(w => w[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <Box>
      <Box sx={{ mb: 3 }}>
        <Typography sx={{ fontSize: 22, fontWeight: 800, color: C.text1 }}>My Profile</Typography>
        <Typography sx={{ fontSize: 13, color: C.text3 }}>View and manage your account information</Typography>
      </Box>

      {saved && (
        <Alert severity="success" sx={{ mb: 3, borderRadius: "10px" }}>
          Profile updated successfully!
        </Alert>
      )}

      {/* Top Card */}
      <Paper elevation={0} sx={{ borderRadius: "16px", border: `1px solid ${C.border}`, mb: 3, overflow: "hidden" }}>
        {/* Banner */}
        <Box sx={{
          height: 100,
          background: `linear-gradient(135deg, ${gradientFrom}, ${gradientTo})`,
          position: "relative",
        }} />

        <Box sx={{ px: 3, pb: 3 }}>
          {/* Avatar */}
          <Box sx={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", mt: -4, mb: 2, flexWrap: "wrap", gap: 2 }}>
            <Avatar sx={{
              width: 76, height: 76, fontSize: 26, fontWeight: 800,
              background: `linear-gradient(135deg, ${gradientFrom}, ${gradientTo})`,
              border: "4px solid #fff",
              boxShadow: "0 4px 14px rgba(0,0,0,0.15)",
            }}>
              {initials}
            </Avatar>
            <Box sx={{ display: "flex", gap: 1 }}>
              {!editing ? (
                <Button startIcon={<EditIcon />} variant="outlined" size="small"
                  onClick={() => setEditing(true)}
                  sx={{ borderRadius: "10px", borderColor: accentColor, color: accentColor, textTransform: "none", fontWeight: 600 }}>
                  Edit Profile
                </Button>
              ) : (
                <>
                  <Button variant="outlined" size="small" onClick={() => setEditing(false)}
                    sx={{ borderRadius: "10px", borderColor: C.border, color: C.text2, textTransform: "none" }}>Cancel</Button>
                  <Button startIcon={<SaveIcon />} variant="contained" size="small" onClick={handleSave}
                    sx={{ borderRadius: "10px", background: accentColor, textTransform: "none", fontWeight: 600, "&:hover": { background: gradientFrom } }}>
                    Save Changes
                  </Button>
                </>
              )}
            </Box>
          </Box>

          <Typography sx={{ fontSize: 20, fontWeight: 800, color: C.text1 }}>{form.name}</Typography>
          <Box sx={{ display: "flex", gap: 1, mt: 0.8, flexWrap: "wrap" }}>
            <Chip label={form.role} size="small"
              sx={{ background: `${accentColor}18`, color: accentColor, fontWeight: 700, fontSize: 12 }} />
            <Chip label={`ID: ${form.userId}`} size="small"
              sx={{ background: "#f3f4f6", color: C.text3, fontWeight: 600, fontSize: 11 }} />
            <Chip label={portalLabel} size="small"
              sx={{ background: "#e8efff", color: "#1a56db", fontWeight: 600, fontSize: 11 }} />
          </Box>
        </Box>
      </Paper>

      {/* Info Cards */}
      <Grid container spacing={3}>
        {/* Personal Info */}
        <Grid item xs={12} md={6}>
          <Paper elevation={0} sx={{ borderRadius: "16px", border: `1px solid ${C.border}`, p: 3 }}>
            <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, mb: 2.5 }}>
              <Box sx={{ width: 36, height: 36, borderRadius: "10px", background: `${accentColor}18`, display: "flex", alignItems: "center", justifyContent: "center", color: accentColor }}>
                <PersonIcon fontSize="small" />
              </Box>
              <Typography sx={{ fontWeight: 700, fontSize: 15, color: C.text1 }}>Personal Information</Typography>
            </Box>
            <Divider sx={{ mb: 2.5, borderColor: C.border }} />
            <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
              <TextField label="Full Name" value={form.name} disabled={!editing}
                onChange={e => setForm({ ...form, name: e.target.value })}
                InputProps={{ startAdornment: <PersonIcon sx={{ fontSize: 18, color: C.text3, mr: 1 }} /> }}
                size="small" fullWidth sx={inputStyle} />
              <TextField label="Email Address" value={form.email} disabled={!editing}
                onChange={e => setForm({ ...form, email: e.target.value })}
                InputProps={{ startAdornment: <EmailIcon sx={{ fontSize: 18, color: C.text3, mr: 1 }} /> }}
                size="small" fullWidth sx={inputStyle} />
              <TextField label="Mobile Number" value={form.mobile} disabled={!editing}
                onChange={e => setForm({ ...form, mobile: e.target.value })}
                InputProps={{ startAdornment: <PhoneIcon sx={{ fontSize: 18, color: C.text3, mr: 1 }} /> }}
                size="small" fullWidth sx={inputStyle} />
            </Box>
          </Paper>
        </Grid>

        {/* Account Info */}
        <Grid item xs={12} md={6}>
          <Paper elevation={0} sx={{ borderRadius: "16px", border: `1px solid ${C.border}`, p: 3 }}>
            <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, mb: 2.5 }}>
              <Box sx={{ width: 36, height: 36, borderRadius: "10px", background: "#e8efff", display: "flex", alignItems: "center", justifyContent: "center", color: "#1a56db" }}>
                <BadgeIcon fontSize="small" />
              </Box>
              <Typography sx={{ fontWeight: 700, fontSize: 15, color: C.text1 }}>Account Details</Typography>
            </Box>
            <Divider sx={{ mb: 2.5, borderColor: C.border }} />
            <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
              <TextField label="City" value={form.city} disabled={!editing}
                onChange={e => setForm({ ...form, city: e.target.value })}
                InputProps={{ startAdornment: <LocationOnIcon sx={{ fontSize: 18, color: C.text3, mr: 1 }} /> }}
                size="small" fullWidth sx={inputStyle} />
              <TextField label="State" value={form.state} disabled={!editing}
                onChange={e => setForm({ ...form, state: e.target.value })}
                InputProps={{ startAdornment: <LocationOnIcon sx={{ fontSize: 18, color: C.text3, mr: 1 }} /> }}
                size="small" fullWidth sx={inputStyle} />
              {[
                { label: "Role",       value: form.role },
                { label: "Member Since", value: form.joined },
              ].map(({ label, value }) => (
                <Box key={label} sx={{ display: "flex", justifyContent: "space-between", py: 1, borderBottom: `1px solid ${C.border}` }}>
                  <Typography sx={{ fontSize: 13, color: C.text3 }}>{label}</Typography>
                  <Typography sx={{ fontSize: 13, fontWeight: 700, color: C.text1 }}>{value}</Typography>
                </Box>
              ))}
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
}
