import React from 'react';

const MainContent = ({ isCollapsed, children }) => {
  return (
    <div className={`content ${isCollapsed ? 'collapsed' : ''}`}>
      {children}
    </div>
  );
};

export default MainContent;
