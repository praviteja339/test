import { useState, useEffect } from 'react';
import {
  AppBar, Toolbar, Box, Button, Typography,
  IconButton, Drawer, List, ListItemButton, ListItemText, useMediaQuery, useTheme,
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import CloseIcon from '@mui/icons-material/Close';
import { useNavigate } from "react-router-dom";

const links = [
  { key: 'home',     label: 'Home'     },
  { key: 'services', label: 'Services' },
  { key: 'about',    label: 'About Us' },
  { key: 'contact',  label: 'Contact'  },
];

export default function Navbar({ currentPage }) {
  const navigate = useNavigate();
  const [scrolled, setScrolled] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleNav = (key) => {
    const routes = { home: "/", services: "/services", about: "/about", contact: "/contact", login: "/login" };
    navigate(routes[key]);
    setDrawerOpen(false);
  };

  return (
    <>
      <AppBar
        position="fixed"
        elevation={0}
        sx={{
          background: scrolled ? 'rgba(255,255,255,0.95)' : 'rgba(255,255,255,0)',
          backdropFilter: scrolled ? 'blur(20px)' : 'none',
          borderBottom: scrolled ? '1px solid rgba(229,234,245,0.8)' : 'none',
          transition: 'all 0.3s ease',
          boxShadow: scrolled ? '0 2px 20px rgba(15,22,35,0.06)' : 'none',
        }}
      >
        <Toolbar sx={{ px: { xs: 2, md: 5 }, minHeight: { xs: 64, md: 72 }, justifyContent: 'space-between', position: 'relative' }}>
          {/* Logo */}
          <Box onClick={() => handleNav('home')} sx={{ display: 'flex', alignItems: 'center', gap: 1.5, cursor: 'pointer' }}>
            <Box sx={{
              width: 36, height: 36, borderRadius: '10px',
              background: 'linear-gradient(135deg, #1a56db, #3b7af7)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: '#fff', fontWeight: 800, fontSize: 13,
              boxShadow: '0 4px 12px rgba(26,86,219,0.3)',
            }}>SP</Box>
            <Typography variant="h6" sx={{ fontWeight: 800, letterSpacing: '-0.5px', color: '#0f1623' }}>
              Slab<span style={{ color: '#1a56db' }}>Pay</span>
            </Typography>
          </Box>

          {/* Desktop Nav */}
          {!isMobile && (
            <Box sx={{ position: 'absolute', left: '50%', transform: 'translateX(-50%)', display: 'flex', gap: 0.5 }}>
              {links.map(({ key, label }) => (
                <Button
                  key={key}
                  onClick={() => handleNav(key)}
                  sx={{
                    color: currentPage === key ? '#1a56db' : '#3a4563',
                    fontWeight: currentPage === key ? 700 : 500,
                    fontSize: 14,
                    position: 'relative', px: 2,
                    '&::after': {
                      content: '""', position: 'absolute', bottom: 6, left: '50%',
                      transform: 'translateX(-50%)',
                      width: currentPage === key ? '60%' : '0%', height: 2,
                      borderRadius: 1, backgroundColor: '#1a56db', transition: 'width 0.3s',
                    },
                    '&:hover::after': { width: '60%' },
                    '&:hover': { color: '#1a56db', background: 'transparent' },
                  }}
                >{label}</Button>
              ))}
            </Box>
          )}

          {/* CTA Buttons */}
          {!isMobile && (
            <Box sx={{ display: 'flex', gap: 1.5 }}>
              <Button
                variant="outlined"
                size="small"
                onClick={() => handleNav('login')}
                sx={{
                  borderColor: '#d0d8ee', color: '#3a4563', borderRadius: '8px',
                  fontWeight: 600, fontSize: 13, px: 2.5,
                  '&:hover': { borderColor: '#1a56db', color: '#1a56db', background: '#e8efff' },
                }}
              >Login</Button>
              <Button
                variant="contained"
                size="small"
                onClick={() => handleNav('contact')}
                sx={{
                  background: 'linear-gradient(135deg,#1a56db,#3b7af7)',
                  boxShadow: '0 4px 14px rgba(26,86,219,0.3)',
                  borderRadius: '8px', fontWeight: 600, fontSize: 13, px: 2.5,
                  '&:hover': { boxShadow: '0 6px 20px rgba(26,86,219,0.45)', transform: 'translateY(-1px)' },
                }}
              >Get Started</Button>
            </Box>
          )}

          {isMobile && (
            <IconButton onClick={() => setDrawerOpen(true)} sx={{ color: '#0f1623' }}>
              <MenuIcon />
            </IconButton>
          )}
        </Toolbar>
      </AppBar>

      {/* Mobile Drawer */}
      <Drawer
        anchor="right"
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        PaperProps={{ sx: { width: 280, background: '#ffffff', borderLeft: '1px solid #e5eaf5' } }}
      >
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', p: 2.5, borderBottom: '1px solid #f0f4fb' }}>
          <Typography sx={{ fontWeight: 800, fontSize: 17, color: '#0f1623' }}>
            Slab<span style={{ color: '#1a56db' }}>Pay</span>
          </Typography>
          <IconButton onClick={() => setDrawerOpen(false)} sx={{ color: '#7a8aab' }}><CloseIcon /></IconButton>
        </Box>
        <List sx={{ px: 1.5, py: 1 }}>
          {links.map(({ key, label }) => (
            <ListItemButton
              key={key}
              onClick={() => handleNav(key)}
              selected={currentPage === key}
              sx={{
                borderRadius: '10px', mb: 0.5, fontWeight: 600,
                '&.Mui-selected': { background: '#e8efff', color: '#1a56db' },
                '&:hover': { background: '#f8faff' },
              }}
            >
              <ListItemText primary={label} primaryTypographyProps={{ fontWeight: 600, fontSize: 14 }} />
            </ListItemButton>
          ))}
        </List>
        <Box sx={{ px: 2.5, mt: 2, display: 'flex', flexDirection: 'column', gap: 1.5 }}>
          <Button variant="outlined" fullWidth onClick={() => handleNav('login')}
            sx={{ borderColor: '#d0d8ee', color: '#3a4563', borderRadius: '10px', fontWeight: 600 }}>
            Login
          </Button>
          <Button variant="contained" fullWidth onClick={() => handleNav('contact')}
            sx={{ background: 'linear-gradient(135deg,#1a56db,#3b7af7)', borderRadius: '10px', fontWeight: 600, boxShadow: '0 4px 12px rgba(26,86,219,0.3)' }}>
            Get Started
          </Button>
        </Box>
      </Drawer>
    </>
  );
}
