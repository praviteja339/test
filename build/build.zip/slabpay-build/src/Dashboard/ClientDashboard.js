import React from "react";
import { Container, Box, Typography } from "@mui/material";

const C = { primary: '#1a56db', primaryLight: '#e8efff', text1: '#0f1623', text3: '#7a8aab', border: '#e5eaf5', surface2: '#f8faff' };

const ClientDashboard = ({ isCollapsed }) => {
  return (
    <Box sx={{ minHeight: "100vh", background: C.surface2, py: 4 }}>
      <Container maxWidth="xl">
        <Box sx={{ p: 4, background: '#ffffff', borderRadius: '20px', border: `1px solid ${C.border}`, boxShadow: '0 2px 8px rgba(15,22,35,0.04)' }}>
          <Box sx={{ width: 48, height: 48, borderRadius: '14px', background: C.primaryLight, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, mb: 2 }}>👤</Box>
          <Typography sx={{ fontSize: 22, fontWeight: 800, color: C.text1, mb: 1 }}>Client Dashboard</Typography>
          <Typography sx={{ fontSize: 14, color: C.text3, lineHeight: 1.8 }}>
            Welcome to your SlabPay client portal. Your reports and analytics will appear here.
          </Typography>
        </Box>
      </Container>
    </Box>
  );
};

export default ClientDashboard;
