import React, { useState } from "react";
import {
  Box, Typography, Card, CardContent, Button,
  Grid, Divider, ToggleButton, ToggleButtonGroup, Chip,
} from "@mui/material";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";

const C = { primary: '#1a56db', primaryLight: '#e8efff', secondary: '#0e9f6e', text1: '#0f1623', text2: '#3a4563', text3: '#7a8aab', border: '#e5eaf5', surface2: '#f8faff' };

const plans = [
  {
    key: "basic", name: "Basic", desc: "For individuals and small teams",
    monthly: 1999, yearly: Math.round(1999 * 12 * 0.8), oldPrice: 2499,
    features: ["Access to all APIs", "Usage reports & analytics", "3,000 monthly transactions"],
    extra: "Wallet charges apply as per usage.",
  },
  {
    key: "medium", name: "Medium", desc: "For growing businesses",
    monthly: 3999, yearly: Math.round(3999 * 12 * 0.8), oldPrice: 4999,
    popular: true,
    features: ["Everything in Basic", "Overdraft feature", "Extended API Limits", "7,000 monthly transactions"],
    extra: "Wallet charges apply as per usage.",
  },
  {
    key: "golden", name: "Golden", desc: "For enterprises with high usage",
    monthly: 6999, yearly: Math.round(6999 * 12 * 0.8), oldPrice: 8999,
    features: ["Everything in Medium", "Dedicated Account Manager", "Private Slack Channel", "15,000 monthly transactions"],
    extra: "Wallet charges apply as per usage.",
  },
];

const ApiPlanCards2 = () => {
  const [billingCycle, setBillingCycle] = useState("monthly");

  return (
    <Box sx={{ py: 8, px: 4, background: C.surface2, minHeight: '100vh' }}>
      <Box sx={{ textAlign: 'center', mb: 6 }}>
        <Typography sx={{ fontSize: { xs: 28, md: 40 }, fontWeight: 800, color: C.text1, letterSpacing: '-1px', mb: 2 }}>
          Pricing Plans
        </Typography>
        <Typography sx={{ fontSize: 16, color: C.text3, mb: 4 }}>
          Choose the plan that fits your business needs.
        </Typography>
        <ToggleButtonGroup
          value={billingCycle}
          exclusive
          onChange={(e, val) => val && setBillingCycle(val)}
          sx={{ border: `1px solid ${C.border}`, borderRadius: '12px', overflow: 'hidden', background: '#fff' }}
        >
          <ToggleButton value="monthly" sx={{ px: 4, fontWeight: 700, textTransform: 'none', '&.Mui-selected': { background: C.primary, color: '#fff' } }}>
            Monthly
          </ToggleButton>
          <ToggleButton value="yearly" sx={{ px: 4, fontWeight: 700, textTransform: 'none', '&.Mui-selected': { background: C.primary, color: '#fff' } }}>
            Yearly <Chip label="Save 20%" size="small" sx={{ ml: 1, background: '#e6faf3', color: C.secondary, fontWeight: 700, fontSize: 10 }} />
          </ToggleButton>
        </ToggleButtonGroup>
      </Box>

      <Grid container spacing={3} justifyContent="center" maxWidth={1000} mx="auto">
        {plans.map((plan) => (
          <Grid item xs={12} md={4} key={plan.key}>
            <Card sx={{
              borderRadius: '20px', border: plan.popular ? `2px solid ${C.primary}` : `1px solid ${C.border}`,
              background: plan.popular ? 'linear-gradient(135deg, #1a56db, #3b7af7)' : '#ffffff',
              boxShadow: plan.popular ? '0 16px 48px rgba(26,86,219,0.3)' : '0 2px 8px rgba(15,22,35,0.05)',
              transition: 'all 0.25s ease',
              '&:hover': { transform: 'translateY(-4px)', boxShadow: plan.popular ? '0 24px 60px rgba(26,86,219,0.4)' : '0 12px 36px rgba(15,22,35,0.1)' },
              position: 'relative', overflow: 'visible',
            }}>
              {plan.popular && (
                <Box sx={{ position: 'absolute', top: -14, left: '50%', transform: 'translateX(-50%)' }}>
                  <Chip label="⭐ Most Popular" sx={{ background: '#fef3c7', color: '#d97706', fontWeight: 700, fontSize: 12, boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }} />
                </Box>
              )}
              <CardContent sx={{ p: 4 }}>
                <Typography sx={{ fontSize: 20, fontWeight: 800, color: plan.popular ? '#fff' : C.text1, mb: 0.5 }}>{plan.name}</Typography>
                <Typography sx={{ fontSize: 13, color: plan.popular ? 'rgba(255,255,255,0.7)' : C.text3, mb: 3 }}>{plan.desc}</Typography>
                <Box sx={{ display: 'flex', alignItems: 'baseline', gap: 0.5, mb: 1 }}>
                  <Typography sx={{ fontSize: 36, fontWeight: 800, color: plan.popular ? '#fff' : C.primary }}>
                    ₹{billingCycle === 'monthly' ? plan.monthly.toLocaleString() : Math.round(plan.yearly / 12).toLocaleString()}
                  </Typography>
                  <Typography sx={{ fontSize: 13, color: plan.popular ? 'rgba(255,255,255,0.6)' : C.text3 }}>/month</Typography>
                </Box>
                {billingCycle === 'yearly' && (
                  <Typography sx={{ fontSize: 12, color: plan.popular ? 'rgba(255,255,255,0.7)' : C.secondary, mb: 2 }}>
                    Billed ₹{plan.yearly.toLocaleString()} / year
                  </Typography>
                )}
                <Divider sx={{ borderColor: plan.popular ? 'rgba(255,255,255,0.15)' : C.border, my: 2 }} />
                <Box sx={{ mb: 3 }}>
                  {plan.features.map((feat) => (
                    <Box key={feat} sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1.5 }}>
                      <CheckCircleIcon sx={{ fontSize: 16, color: plan.popular ? '#fff' : C.secondary, flexShrink: 0 }} />
                      <Typography sx={{ fontSize: 13.5, fontWeight: 500, color: plan.popular ? 'rgba(255,255,255,0.85)' : C.text2 }}>{feat}</Typography>
                    </Box>
                  ))}
                </Box>
                <Button fullWidth sx={{
                  borderRadius: '12px', height: 46, fontWeight: 700, textTransform: 'none', fontSize: 15,
                  background: plan.popular ? 'rgba(255,255,255,0.2)' : C.primary,
                  color: '#fff',
                  border: plan.popular ? '1.5px solid rgba(255,255,255,0.4)' : 'none',
                  boxShadow: plan.popular ? 'none' : '0 4px 14px rgba(26,86,219,0.3)',
                  '&:hover': {
                    background: plan.popular ? 'rgba(255,255,255,0.35)' : '#1244b8',
                    transform: 'translateY(-1px)',
                  },
                }}>Get Started</Button>
                <Typography sx={{ fontSize: 11, color: plan.popular ? 'rgba(255,255,255,0.5)' : C.text3, textAlign: 'center', mt: 1.5 }}>{plan.extra}</Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default ApiPlanCards2;
