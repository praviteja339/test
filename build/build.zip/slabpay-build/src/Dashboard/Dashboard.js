import React, { useState } from "react";
import { Card, Container, Grid, Typography, Box } from "@mui/material";
import {
  ApiOutlined, GroupOutlined, ApartmentOutlined,
  CancelOutlined, PhoneOutlined,
} from "@mui/icons-material";

const SectionHeader = ({ title }) => (
  <Box sx={{ display: "flex", alignItems: "center", mb: 3 }}>
    <Typography sx={{ fontSize: 11, fontWeight: 700, letterSpacing: "1.2px", color: "#7a8aab", mr: 2, textTransform: "uppercase" }}>
      {title}
    </Typography>
    <Box sx={{ flexGrow: 1, height: "1px", background: "#e5eaf5" }} />
  </Box>
);

const StatCard = ({ label, value, icon, bg, color }) => (
  <Card sx={{
    borderRadius: "16px", p: 3,
    background: bg,
    display: "flex", justifyContent: "space-between", alignItems: "center",
    minHeight: 110, transition: "0.25s ease",
    boxShadow: "0 2px 8px rgba(15,22,35,0.05)",
    border: "1px solid rgba(255,255,255,0.8)",
    "&:hover": { transform: "translateY(-5px)", boxShadow: "0 10px 28px rgba(15,22,35,0.1)" },
  }}>
    <Box>
      <Typography sx={{ fontSize: 11, fontWeight: 700, color: "#7a8aab", textTransform: "uppercase", letterSpacing: "0.8px", mb: 0.5 }}>
        {label}
      </Typography>
      <Typography sx={{ fontSize: 28, fontWeight: 800, color, mt: 0.5 }}>{value}</Typography>
    </Box>
    <Box sx={{ background: "rgba(255,255,255,0.6)", borderRadius: "12px", p: 1.2, backdropFilter: "blur(4px)" }}>
      {React.cloneElement(icon, { sx: { fontSize: 28, color } })}
    </Box>
  </Card>
);

const Dashboard = () => {
  const [counts] = useState({
    totalClients: 0, totalTransactions: 0, todaySuccess: 0,
    todayFailed: 0, webRedirection: 0, sdkOtp: 0,
    sdkFaceAuth: 0, generateId: 0, gotoConsentPage: 0,
  });

  const stats = [
    { key: "totalClients",      label: "Total Clients",   icon: <GroupOutlined />,     bg: "#e8efff", color: "#1a56db" },
    { key: "totalTransactions", label: "Transactions",    icon: <ApiOutlined />,       bg: "#e6faf3", color: "#0e9f6e" },
    { key: "todaySuccess",      label: "Success",         icon: <ApartmentOutlined />, bg: "#d1fae5", color: "#059669" },
    { key: "todayFailed",       label: "Failed",          icon: <CancelOutlined />,    bg: "#fde8e8", color: "#e02424" },
    { key: "webRedirection",    label: "NPCI Page",       icon: <PhoneOutlined />,     bg: "#fef3c7", color: "#d97706" },
    { key: "sdkOtp",            label: "SDK OTP",         icon: <PhoneOutlined />,     bg: "#ede9fe", color: "#7c3aed" },
    { key: "sdkFaceAuth",       label: "Face Auth",       icon: <PhoneOutlined />,     bg: "#e0f2fe", color: "#0284c7" },
    { key: "generateId",        label: "Generate ID",     icon: <ApiOutlined />,       bg: "#fef9c3", color: "#ca8a04" },
    { key: "gotoConsentPage",   label: "Consent Page",   icon: <ApartmentOutlined />, bg: "#e0e7ff", color: "#4338ca" },
  ];

  return (
    <Container maxWidth="xl" sx={{ py: 4 }}>
      <SectionHeader title="System Overview" />
      <Grid container spacing={2.5}>
        {stats.map((item) => (
          <Grid item xs={12} sm={6} md={4} lg={2.4} key={item.key}>
            <StatCard label={item.label} value={counts[item.key]} icon={item.icon} bg={item.bg} color={item.color} />
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default Dashboard;
