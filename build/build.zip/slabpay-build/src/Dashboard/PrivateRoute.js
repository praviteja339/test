import React from "react";
import { Navigate, Outlet } from "react-router-dom";

const PrivateRoute = () => {
  // Simple check - in production this would check auth state
  const isAuthenticated = sessionStorage.getItem("slabpay_auth") === "true";
  return isAuthenticated ? <Outlet /> : <Navigate to="/login" replace />;
};

export default PrivateRoute;
