import React, { useState } from "react";
import { Container, Box, Typography, Button, Card, Grid, TextField, Chip, Paper } from "@mui/material";

const C = { primary: '#1a56db', primaryLight: '#e8efff', secondary: '#0e9f6e', danger: '#e02424', text1: '#0f1623', text2: '#3a4563', text3: '#7a8aab', border: '#e5eaf5', surface2: '#f8faff' };

const inputStyle = {
  "& .MuiOutlinedInput-root": {
    background: "#ffffff", borderRadius: "10px", color: "#0f1623",
    "& fieldset": { borderColor: "#e5eaf5" },
    "&:hover fieldset": { borderColor: "#1a56db" },
    "&.Mui-focused fieldset": { borderColor: "#1a56db" },
  },
  "& .MuiInputLabel-root": { color: "#7a8aab" },
};

const ReportsPage = ({ isCollapsed }) => {
  const [activeTab, setActiveTab] = useState("usage");
  const tabs = [{ key: "usage", label: "Usage Report" }, { key: "summary", label: "Summary" }, { key: "hits", label: "API Hits" }];

  return (
    <Box sx={{ background: '#f8faff', minHeight: '100vh' }}>
      <Container maxWidth="xl" sx={{ py: 4 }}>
        <Box sx={{ mb: 3 }}>
          <Typography sx={{ fontSize: 22, fontWeight: 800, color: C.text1 }}>Reports</Typography>
          <Typography sx={{ fontSize: 13, color: C.text3, mt: 0.5 }}>Detailed usage and transaction reports.</Typography>
        </Box>

        {/* Tabs */}
        <Box sx={{ display: 'flex', gap: 1, mb: 3, p: 0.5, background: '#ffffff', borderRadius: '12px', border: `1px solid ${C.border}`, width: 'fit-content' }}>
          {tabs.map(tab => (
            <Button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              sx={{
                borderRadius: '10px', px: 3, py: 1, textTransform: 'none', fontWeight: 700, fontSize: 14,
                background: activeTab === tab.key ? C.primary : 'transparent',
                color: activeTab === tab.key ? '#fff' : C.text2,
                '&:hover': { background: activeTab === tab.key ? C.primary : C.surface2 },
              }}
            >{tab.label}</Button>
          ))}
        </Box>

        {/* Filter Bar */}
        <Paper sx={{ p: 3, borderRadius: '16px', border: `1px solid ${C.border}`, background: '#ffffff', mb: 3 }}>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} md={3}>
              <TextField type="date" label="From Date" InputLabelProps={{ shrink: true }} fullWidth sx={inputStyle} />
            </Grid>
            <Grid item xs={12} md={3}>
              <TextField type="date" label="To Date" InputLabelProps={{ shrink: true }} fullWidth sx={inputStyle} />
            </Grid>
            <Grid item xs={12} md={3}>
              <TextField label="Client ID" fullWidth sx={inputStyle} />
            </Grid>
            <Grid item xs={12} md={3}>
              <Button sx={{ background: `linear-gradient(135deg, ${C.primary}, #3b7af7)`, color: '#fff', borderRadius: '10px', height: 56, px: 3, textTransform: 'none', fontWeight: 700, boxShadow: '0 4px 12px rgba(26,86,219,0.25)', width: '100%' }}>
                Fetch Report
              </Button>
            </Grid>
          </Grid>
        </Paper>

        {/* Empty State */}
        <Paper sx={{ p: 6, borderRadius: '16px', border: `1px solid ${C.border}`, background: '#ffffff', textAlign: 'center' }}>
          <Box sx={{ fontSize: 52, mb: 2 }}>📊</Box>
          <Typography sx={{ fontSize: 18, fontWeight: 700, color: C.text1, mb: 1 }}>No Report Data</Typography>
          <Typography sx={{ fontSize: 14, color: C.text3 }}>Set filters above and click Fetch Report to view data.</Typography>
        </Paper>
      </Container>
    </Box>
  );
};

export default ReportsPage;
