import { useEffect, useState } from "react";
import {
  Box, Typography, Grid, Paper, Chip, Avatar,
  LinearProgress, CircularProgress, Alert,
} from "@mui/material";
import {
  AccountBalanceWallet, HourglassEmpty, AccountBalance,
  PendingActions, CompareArrows, People, PersonAdd, Verified,
} from "@mui/icons-material";
import { getDashboardStats, getEnquiries } from "../services/adminApi";

const A = "#dc2626";
const C = { bg: "#f8faff", card: "#ffffff", border: "#e5eaf5", text1: "#0f1623", text2: "#3a4563", text3: "#7a8aab" };

const fmt = (n) =>
  n == null ? "₹0.00" : "₹" + Number(n).toLocaleString("en-IN", { minimumFractionDigits: 2 });

const statusChip = (status) =>
  ({ pending: { label:"Pending",bg:"#fffbeb",color:"#d97706" },
     PENDING:  { label:"Pending",bg:"#fffbeb",color:"#d97706" },
     approved: { label:"Approved",bg:"#ecfdf5",color:"#059669" },
     ACCEPTED: { label:"Accepted",bg:"#ecfdf5",color:"#059669" },
     rejected: { label:"Rejected",bg:"#fef2f2",color:"#dc2626" },
     REJECTED: { label:"Rejected",bg:"#fef2f2",color:"#dc2626" },
     CONVERTED:{ label:"Converted",bg:"#e8efff",color:"#1a56db" },
  }[status] ?? { label: status, bg:"#f3f4f6", color:"#6b7280" });

const StatCard = ({ label, value, icon, color, light }) => (
  <Paper elevation={0} sx={{ p:2.5, borderRadius:"16px", border:"1px solid #e5eaf5", height:"100%" }}>
    <Box sx={{ width:44,height:44,borderRadius:"12px",background:light,display:"flex",alignItems:"center",justifyContent:"center",color,mb:1.5 }}>
      {icon}
    </Box>
    <Typography sx={{ fontSize:11,fontWeight:700,color:"#7a8aab",letterSpacing:"0.06em",textTransform:"uppercase",mb:0.5 }}>
      {label}
    </Typography>
    <Typography sx={{ fontSize:20,fontWeight:800,color:"#0f1623" }}>{value}</Typography>
  </Paper>
);

export default function DashboardPage() {
  const [stats, setStats]       = useState(null);
  const [enquiries, setEnquiries] = useState([]);
  const [loading, setLoading]   = useState(true);
  const [error, setError]       = useState(null);

  useEffect(() => {
    Promise.all([getDashboardStats(), getEnquiries()])
      .then(([sRes, eRes]) => {
        setStats(sRes.data.data);
        const list = Array.isArray(eRes.data.data) ? eRes.data.data : [];
        setEnquiries(list.slice(0,5));
      })
      .catch(() => setError("Failed to load dashboard data."))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Box sx={{ display:"flex",justifyContent:"center",mt:8 }}><CircularProgress sx={{ color:A }} /></Box>;
  if (error)   return <Alert severity="error" sx={{ borderRadius:"12px" }}>{error}</Alert>;

  const s = stats || {};
  const totalNet = (s.totalSuperDistributors||0) + (s.totalDistributors||0) + (s.totalRetailers||0);

  const topCards = [
    { label:"Admin Balance",      value:fmt(s.currentBalance),       icon:<AccountBalanceWallet sx={{fontSize:24}}/>, color:"#1a56db", light:"#e8efff" },
    { label:"Today's Credit",     value:fmt(s.todayCreditBalance),   icon:<AccountBalance sx={{fontSize:24}}/>,       color:"#0e9f6e", light:"#ecfdf5" },
    { label:"Today's Debit",      value:fmt(s.todayDebitBalance),    icon:<HourglassEmpty sx={{fontSize:24}}/>,       color:A,         light:"#fef2f2" },
    { label:"Commission Balance", value:fmt(s.commissionBalance),    icon:<AccountBalanceWallet sx={{fontSize:24}}/>, color:"#7c3aed", light:"#f5f3ff" },
    { label:"Pending Top-ups",    value:String(s.pendingTopups||0),  icon:<PendingActions sx={{fontSize:24}}/>,       color:"#f59e0b", light:"#fffbeb" },
  ];
  const botCards = [
    { label:"Total Users",        value:String(s.totalUsers||0),            icon:<People sx={{fontSize:24}}/>,      color:"#1a56db", light:"#e8efff" },
    { label:"Super Distributors", value:String(s.totalSuperDistributors||0),icon:<CompareArrows sx={{fontSize:24}}/>,color:"#7c3aed", light:"#f5f3ff" },
    { label:"Distributors",       value:String(s.totalDistributors||0),     icon:<People sx={{fontSize:24}}/>,      color:"#0e9f6e", light:"#ecfdf5" },
    { label:"Retailers / Agents", value:String(s.totalRetailers||0),        icon:<PersonAdd sx={{fontSize:24}}/>,   color:"#f59e0b", light:"#fffbeb" },
    { label:"KYC Pending Review", value:String(s.kycPendingReview||0),      icon:<Verified sx={{fontSize:24}}/>,    color:A,         light:"#fef2f2" },
  ];
  const roleStats = [
    { role:"Super Distributors", count:s.totalSuperDistributors||0, color:"#7c3aed" },
    { role:"Distributors",       count:s.totalDistributors||0,      color:"#1a56db" },
    { role:"Retailers / Agents", count:s.totalRetailers||0,         color:"#0e9f6e" },
  ].map(r => ({ ...r, pct: totalNet ? Math.round((r.count/totalNet)*100) : 0 }));

  return (
    <Box>
      <Grid container spacing={2} sx={{ mb:2.5 }}>
        {topCards.map(c => <Grid item xs={12} sm={6} md={4} lg={2.4} key={c.label}><StatCard {...c}/></Grid>)}
      </Grid>
      <Grid container spacing={2} sx={{ mb:3 }}>
        {botCards.map(c => <Grid item xs={12} sm={6} md={4} lg={2.4} key={c.label}><StatCard {...c}/></Grid>)}
      </Grid>

      <Grid container spacing={2.5}>
        <Grid item xs={12} lg={8}>
          <Paper elevation={0} sx={{ borderRadius:"16px", border:"1px solid #e5eaf5" }}>
            <Box sx={{ px:3,py:2,borderBottom:"1px solid #e5eaf5" }}>
              <Typography sx={{ fontWeight:800,color:"#0f1623" }}>Recent Enquiries</Typography>
              <Typography sx={{ fontSize:12,color:"#7a8aab" }}>Latest KYC onboarding submissions</Typography>
            </Box>
            {enquiries.length===0
              ? <Box sx={{ p:4,textAlign:"center" }}><Typography sx={{ color:"#7a8aab",fontSize:13 }}>No enquiries yet.</Typography></Box>
              : enquiries.map((e,i) => {
                  const sc = statusChip(e.status);
                  return (
                    <Box key={i} sx={{ px:3,py:1.5,borderTop:"1px solid #f0f0f0",display:"flex",alignItems:"center",gap:2 }}>
                      <Avatar sx={{ width:36,height:36,fontSize:14,bgcolor:"#e8efff",color:"#1a56db" }}>
                        {(e.applicantName||e.name||"?")[0]}
                      </Avatar>
                      <Box sx={{ flex:1 }}>
                        <Typography sx={{ fontWeight:700,fontSize:14,color:"#0f1623" }}>{e.applicantName||e.name}</Typography>
                        <Typography sx={{ fontSize:12,color:"#7a8aab" }}>
                          {e.userType||e.role} · {e.createdDate ? new Date(e.createdDate).toLocaleDateString("en-IN") : "—"}
                        </Typography>
                      </Box>
                      <Chip label={sc.label} size="small" sx={{ background:sc.bg,color:sc.color,fontWeight:600,fontSize:11 }}/>
                    </Box>
                  );
                })
            }
          </Paper>
        </Grid>

        <Grid item xs={12} lg={4}>
          <Paper elevation={0} sx={{ p:3,borderRadius:"16px",border:"1px solid #e5eaf5" }}>
            <Typography sx={{ fontWeight:800,mb:0.5,color:"#0f1623" }}>User Network</Typography>
            <Typography sx={{ fontSize:12,color:"#7a8aab",mb:2.5 }}>{totalNet.toLocaleString("en-IN")} total members</Typography>
            {roleStats.map(r => (
              <Box key={r.role} sx={{ mb:2.5 }}>
                <Box sx={{ display:"flex",justifyContent:"space-between",mb:0.8 }}>
                  <Typography sx={{ fontSize:13,color:"#3a4563" }}>{r.role}</Typography>
                  <Typography sx={{ fontSize:13,fontWeight:700 }}>{r.count.toLocaleString("en-IN")}</Typography>
                </Box>
                <LinearProgress variant="determinate" value={r.pct}
                  sx={{ height:6,borderRadius:4,backgroundColor:"#f0f0f0",
                    "& .MuiLinearProgress-bar":{ backgroundColor:r.color,borderRadius:4 } }}/>
              </Box>
            ))}
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
}
