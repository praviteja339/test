import { useState, useEffect, useCallback } from "react";
import {
  Box, Typography, Paper, Chip, Button, TextField, Dialog, DialogTitle,
  DialogContent, DialogActions, Grid, Select, MenuItem, InputAdornment,
  Tabs, Tab, CircularProgress, Alert, Snackbar, IconButton, Tooltip,
} from "@mui/material";
import { Edit, Save, Add, Delete, Refresh } from "@mui/icons-material";
import {
  getCommissionConfigs, upsertCommissionConfig, updateCommissionConfig,
  getCommissionSlabs, createCommissionSlab, updateCommissionSlab, deleteCommissionSlab,
} from "../services/adminApi";

const A = "#dc2626";
const C = { border:"#e5eaf5", text1:"#0f1623", text2:"#3a4563", text3:"#7a8aab" };
const SERVICES = ["Money Transfer","Micro ATM","BBPS","AEPS","Travel Booking","Recharge"];

const roleColors = {
  sdPct:    { color:"#7c3aed", bg:"#ede9fe", label:"Super Dist." },
  distPct:  { color:"#1a56db", bg:"#e8efff", label:"Distributor" },
  agentPct: { color:"#059669", bg:"#ecfdf5", label:"Agent" },
};

export default function CommissionManagement() {
  const [tab,       setTab]       = useState(0);
  const [configs,   setConfigs]   = useState([]);
  const [slabs,     setSlabs]     = useState([]);
  const [loading,   setLoading]   = useState(true);
  const [toast,     setToast]     = useState({ open:false, msg:"", sev:"success" });
  const [editRow,   setEditRow]   = useState(null);
  const [editOpen,  setEditOpen]  = useState(false);
  const [slabEdit,  setSlabEdit]  = useState(null);
  const [slabOpen,  setSlabOpen]  = useState(false);
  const [addSlabOpen,setAddSlabOpen]=useState(false);
  const [newSlab,  setNewSlab]    = useState({ serviceType:SERVICES[0],minAmt:"",maxAmt:"",agentRate:"",distRate:"",sdRate:"" });
  const [saving,    setSaving]    = useState(false);

  const showToast = (msg, sev="success") => setToast({ open:true, msg, sev });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [cRes, sRes] = await Promise.all([getCommissionConfigs(), getCommissionSlabs()]);
      setConfigs(Array.isArray(cRes.data.data) ? cRes.data.data : []);
      setSlabs(Array.isArray(sRes.data.data) ? sRes.data.data : []);
    } catch { showToast("Failed to load commission data.", "error"); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleSaveConfig = async () => {
    setSaving(true);
    try {
      if (editRow.id) await updateCommissionConfig(editRow.id, editRow);
      else            await upsertCommissionConfig(editRow);
      showToast("Commission config saved.");
      setEditOpen(false); load();
    } catch { showToast("Failed to save config.", "error"); }
    finally { setSaving(false); }
  };

  const handleSaveSlab = async () => {
    setSaving(true);
    try {
      await updateCommissionSlab(slabEdit.id, slabEdit);
      showToast("Slab updated."); setSlabOpen(false); load();
    } catch { showToast("Failed to update slab.", "error"); }
    finally { setSaving(false); }
  };

  const handleAddSlab = async () => {
    setSaving(true);
    try {
      await createCommissionSlab(newSlab);
      showToast("Slab created."); setAddSlabOpen(false);
      setNewSlab({ serviceType:SERVICES[0],minAmt:"",maxAmt:"",agentRate:"",distRate:"",sdRate:"" });
      load();
    } catch { showToast("Failed to create slab.", "error"); }
    finally { setSaving(false); }
  };

  const handleDeleteSlab = async (id) => {
    try { await deleteCommissionSlab(id); showToast("Slab deleted."); load(); }
    catch { showToast("Failed to delete slab.", "error"); }
  };

  const pct = (v) => `${Number(v||0).toFixed(3)}%`;

  const ColHeader = ({ children }) => (
    <Typography sx={{ fontSize:11,fontWeight:700,color:C.text3,textTransform:"uppercase",letterSpacing:"0.05em" }}>{children}</Typography>
  );

  return (
    <Box>
      <Box sx={{ mb:3,display:"flex",alignItems:"flex-start",justifyContent:"space-between",flexWrap:"wrap",gap:2 }}>
        <Box>
          <Typography sx={{ fontSize:22,fontWeight:800,color:C.text1 }}>Commission Management</Typography>
          <Typography sx={{ fontSize:13,color:C.text3 }}>Set commission percentages and slabs for all services</Typography>
        </Box>
        <Tooltip title="Refresh"><IconButton onClick={load} sx={{ border:`1px solid ${C.border}`,borderRadius:"10px" }}><Refresh fontSize="small"/></IconButton></Tooltip>
      </Box>

      <Tabs value={tab} onChange={(_,v)=>setTab(v)} sx={{ mb:3,"& .MuiTab-root":{ textTransform:"none",fontWeight:600 },"& .Mui-selected":{ color:A },"& .MuiTabs-indicator":{ background:A } }}>
        <Tab label="Commission Rates"/>
        <Tab label="Amount Slabs"/>
      </Tabs>

      {loading ? (
        <Box sx={{ display:"flex",justifyContent:"center",mt:6 }}><CircularProgress sx={{ color:A }}/></Box>
      ) : tab===0 ? (
        /* ── Commission Rates ── */
        <Paper elevation={0} sx={{ borderRadius:"16px",border:`1px solid ${C.border}`,overflow:"hidden" }}>
          <Box sx={{ display:"grid",gridTemplateColumns:"1.4fr 0.9fr 0.9fr 0.9fr 0.7fr 0.7fr 0.6fr 0.5fr",
            gap:1,px:2.5,py:1.5,background:"#f8faff",borderBottom:`1px solid ${C.border}` }}>
            {["Service","Super Dist %","Distributor %","Agent %","TDS %","Min Slab","Max Slab",""].map(h=>(
              <ColHeader key={h}>{h}</ColHeader>
            ))}
          </Box>
          {configs.length===0 ? (
            <Box sx={{ p:5,textAlign:"center" }}>
              <Typography sx={{ color:C.text3 }}>No configs found. Add one using the button below.</Typography>
              <Button variant="contained" startIcon={<Add/>} sx={{ mt:2,background:A,borderRadius:"10px",textTransform:"none","&:hover":{background:"#b91c1c"} }}
                onClick={()=>{ setEditRow({serviceType:SERVICES[0],sdPct:0,distPct:0,agentPct:0,tdsPct:10,minSlab:0,maxSlab:0,flatFee:false}); setEditOpen(true); }}>
                Add First Config
              </Button>
            </Box>
          ) : configs.map(c=>(
            <Box key={c.id} sx={{ display:"grid",gridTemplateColumns:"1.4fr 0.9fr 0.9fr 0.9fr 0.7fr 0.7fr 0.6fr 0.5fr",
              gap:1,px:2.5,py:1.5,borderBottom:`1px solid ${C.border}`,"&:hover":{background:"#fafbff"},alignItems:"center" }}>
              <Typography sx={{ fontSize:13,fontWeight:700,color:C.text1 }}>{c.serviceType}</Typography>
              {["sdPct","distPct","agentPct"].map(k=>(
                <Chip key={k} label={pct(c[k])} size="small"
                  sx={{ background:roleColors[k].bg,color:roleColors[k].color,fontWeight:700,fontSize:12 }}/>
              ))}
              <Typography sx={{ fontSize:13,color:C.text2 }}>{pct(c.tdsPct)}</Typography>
              <Typography sx={{ fontSize:13,color:C.text2 }}>₹{Number(c.minSlab||0).toLocaleString("en-IN")}</Typography>
              <Typography sx={{ fontSize:13,color:C.text2 }}>₹{Number(c.maxSlab||0).toLocaleString("en-IN")}</Typography>
              <Tooltip title="Edit">
                <IconButton size="small" onClick={()=>{ setEditRow({...c}); setEditOpen(true); }}>
                  <Edit fontSize="small" sx={{ color:C.text3 }}/>
                </IconButton>
              </Tooltip>
            </Box>
          ))}
          <Box sx={{ px:2.5,py:1.5,borderTop:`1px solid ${C.border}`,display:"flex",justifyContent:"space-between",alignItems:"center" }}>
            <Typography sx={{ fontSize:12,color:C.text3 }}>{configs.length} service(s) configured</Typography>
            <Button startIcon={<Add/>} size="small" variant="contained"
              sx={{ background:A,borderRadius:"8px",textTransform:"none",fontWeight:700,"&:hover":{background:"#b91c1c"} }}
              onClick={()=>{ setEditRow({serviceType:SERVICES[0],sdPct:0,distPct:0,agentPct:0,tdsPct:10,minSlab:0,maxSlab:0,flatFee:false}); setEditOpen(true); }}>
              Add Service
            </Button>
          </Box>
        </Paper>
      ) : (
        /* ── Slabs ── */
        <Paper elevation={0} sx={{ borderRadius:"16px",border:`1px solid ${C.border}`,overflow:"hidden" }}>
          <Box sx={{ display:"grid",gridTemplateColumns:"1.2fr 0.9fr 0.9fr 0.8fr 0.8fr 0.8fr 0.5fr",
            gap:1,px:2.5,py:1.5,background:"#f8faff",borderBottom:`1px solid ${C.border}` }}>
            {["Service","Min Amount","Max Amount","Agent Rate","Dist Rate","SD Rate",""].map(h=>(
              <ColHeader key={h}>{h}</ColHeader>
            ))}
          </Box>
          {slabs.length===0 ? (
            <Box sx={{ p:5,textAlign:"center" }}>
              <Typography sx={{ color:C.text3 }}>No slabs defined yet.</Typography>
            </Box>
          ) : slabs.map(s=>(
            <Box key={s.id} sx={{ display:"grid",gridTemplateColumns:"1.2fr 0.9fr 0.9fr 0.8fr 0.8fr 0.8fr 0.5fr",
              gap:1,px:2.5,py:1.5,borderBottom:`1px solid ${C.border}`,"&:hover":{background:"#fafbff"},alignItems:"center" }}>
              <Chip label={s.serviceType} size="small" sx={{ background:"#e8efff",color:"#1a56db",fontWeight:600,fontSize:11,maxWidth:"fit-content" }}/>
              <Typography sx={{ fontSize:13,color:C.text2 }}>₹{Number(s.minAmt).toLocaleString("en-IN")}</Typography>
              <Typography sx={{ fontSize:13,color:C.text2 }}>₹{Number(s.maxAmt).toLocaleString("en-IN")}</Typography>
              <Typography sx={{ fontSize:13,color:"#059669",fontWeight:700 }}>{pct(s.agentRate)}</Typography>
              <Typography sx={{ fontSize:13,color:"#1a56db",fontWeight:700 }}>{pct(s.distRate)}</Typography>
              <Typography sx={{ fontSize:13,color:"#7c3aed",fontWeight:700 }}>{pct(s.sdRate)}</Typography>
              <Box sx={{ display:"flex",gap:0.5 }}>
                <Tooltip title="Edit"><IconButton size="small" onClick={()=>{ setSlabEdit({...s}); setSlabOpen(true); }}><Edit fontSize="small" sx={{ color:C.text3 }}/></IconButton></Tooltip>
                <Tooltip title="Delete"><IconButton size="small" onClick={()=>handleDeleteSlab(s.id)}><Delete fontSize="small" sx={{ color:A }}/></IconButton></Tooltip>
              </Box>
            </Box>
          ))}
          <Box sx={{ px:2.5,py:1.5,borderTop:`1px solid ${C.border}`,display:"flex",justifyContent:"space-between",alignItems:"center" }}>
            <Typography sx={{ fontSize:12,color:C.text3 }}>{slabs.length} slab(s) defined</Typography>
            <Button startIcon={<Add/>} size="small" variant="contained"
              sx={{ background:A,borderRadius:"8px",textTransform:"none",fontWeight:700,"&:hover":{background:"#b91c1c"} }}
              onClick={()=>setAddSlabOpen(true)}>
              Add Slab
            </Button>
          </Box>
        </Paper>
      )}

      {/* Edit Commission Config Dialog */}
      <Dialog open={editOpen} onClose={()=>setEditOpen(false)} maxWidth="sm" fullWidth PaperProps={{ sx:{ borderRadius:"16px" } }}>
        <DialogTitle sx={{ fontWeight:800,color:C.text1 }}>{editRow?.id ? "Edit" : "Add"} Commission Config</DialogTitle>
        <DialogContent dividers>
          {editRow && (
            <Grid container spacing={2} sx={{ pt:1 }}>
              <Grid item xs={12}>
                <Select fullWidth size="small" value={editRow.serviceType||""} onChange={e=>setEditRow({...editRow,serviceType:e.target.value})} sx={{ borderRadius:"10px" }}>
                  {SERVICES.map(s=><MenuItem key={s} value={s}>{s}</MenuItem>)}
                </Select>
              </Grid>
              {[
                { key:"sdPct",   label:"Super Dist %" },
                { key:"distPct", label:"Distributor %" },
                { key:"agentPct",label:"Agent %" },
                { key:"tdsPct",  label:"TDS %" },
                { key:"minSlab", label:"Min Slab (₹)" },
                { key:"maxSlab", label:"Max Slab (₹)" },
              ].map(f=>(
                <Grid item xs={12} sm={6} key={f.key}>
                  <TextField label={f.label} type="number" size="small" fullWidth value={editRow[f.key]||""}
                    onChange={e=>setEditRow({...editRow,[f.key]:e.target.value})}
                    sx={{ "& .MuiOutlinedInput-root":{ borderRadius:"10px" } }}/>
                </Grid>
              ))}
            </Grid>
          )}
        </DialogContent>
        <DialogActions sx={{ p:2.5,gap:1 }}>
          <Button onClick={()=>setEditOpen(false)} sx={{ textTransform:"none",borderRadius:"10px" }}>Cancel</Button>
          <Button onClick={handleSaveConfig} variant="contained" disabled={saving} startIcon={<Save/>}
            sx={{ background:A,borderRadius:"10px",textTransform:"none",fontWeight:700,"&:hover":{background:"#b91c1c"} }}>
            {saving ? <CircularProgress size={18} sx={{ color:"#fff" }}/> : "Save"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Edit Slab Dialog */}
      <Dialog open={slabOpen} onClose={()=>setSlabOpen(false)} maxWidth="sm" fullWidth PaperProps={{ sx:{ borderRadius:"16px" } }}>
        <DialogTitle sx={{ fontWeight:800,color:C.text1 }}>Edit Slab</DialogTitle>
        <DialogContent dividers>
          {slabEdit && (
            <Grid container spacing={2} sx={{ pt:1 }}>
              {[
                { key:"minAmt",   label:"Min Amount (₹)" },
                { key:"maxAmt",   label:"Max Amount (₹)" },
                { key:"agentRate",label:"Agent Rate %" },
                { key:"distRate", label:"Dist Rate %" },
                { key:"sdRate",   label:"SD Rate %" },
              ].map(f=>(
                <Grid item xs={12} sm={6} key={f.key}>
                  <TextField label={f.label} type="number" size="small" fullWidth value={slabEdit[f.key]||""}
                    onChange={e=>setSlabEdit({...slabEdit,[f.key]:e.target.value})}
                    sx={{ "& .MuiOutlinedInput-root":{ borderRadius:"10px" } }}/>
                </Grid>
              ))}
            </Grid>
          )}
        </DialogContent>
        <DialogActions sx={{ p:2.5,gap:1 }}>
          <Button onClick={()=>setSlabOpen(false)} sx={{ textTransform:"none",borderRadius:"10px" }}>Cancel</Button>
          <Button onClick={handleSaveSlab} variant="contained" disabled={saving}
            sx={{ background:A,borderRadius:"10px",textTransform:"none",fontWeight:700,"&:hover":{background:"#b91c1c"} }}>
            {saving ? <CircularProgress size={18} sx={{ color:"#fff" }}/> : "Save"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Add Slab Dialog */}
      <Dialog open={addSlabOpen} onClose={()=>setAddSlabOpen(false)} maxWidth="sm" fullWidth PaperProps={{ sx:{ borderRadius:"16px" } }}>
        <DialogTitle sx={{ fontWeight:800,color:C.text1 }}>Add New Slab</DialogTitle>
        <DialogContent dividers>
          <Grid container spacing={2} sx={{ pt:1 }}>
            <Grid item xs={12}>
              <Select fullWidth size="small" value={newSlab.serviceType} onChange={e=>setNewSlab({...newSlab,serviceType:e.target.value})} sx={{ borderRadius:"10px" }}>
                {SERVICES.map(s=><MenuItem key={s} value={s}>{s}</MenuItem>)}
              </Select>
            </Grid>
            {[
              { key:"minAmt",   label:"Min Amount (₹)" },
              { key:"maxAmt",   label:"Max Amount (₹)" },
              { key:"agentRate",label:"Agent Rate %" },
              { key:"distRate", label:"Dist Rate %" },
              { key:"sdRate",   label:"SD Rate %" },
            ].map(f=>(
              <Grid item xs={12} sm={6} key={f.key}>
                <TextField label={f.label} type="number" size="small" fullWidth value={newSlab[f.key]}
                  onChange={e=>setNewSlab({...newSlab,[f.key]:e.target.value})}
                  sx={{ "& .MuiOutlinedInput-root":{ borderRadius:"10px" } }}/>
              </Grid>
            ))}
          </Grid>
        </DialogContent>
        <DialogActions sx={{ p:2.5,gap:1 }}>
          <Button onClick={()=>setAddSlabOpen(false)} sx={{ textTransform:"none",borderRadius:"10px" }}>Cancel</Button>
          <Button onClick={handleAddSlab} variant="contained" disabled={saving}
            sx={{ background:A,borderRadius:"10px",textTransform:"none",fontWeight:700,"&:hover":{background:"#b91c1c"} }}>
            {saving ? <CircularProgress size={18} sx={{ color:"#fff" }}/> : "Create Slab"}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar open={toast.open} autoHideDuration={3500} onClose={()=>setToast({...toast,open:false})} anchorOrigin={{ vertical:"bottom",horizontal:"right" }}>
        <Alert severity={toast.sev} sx={{ borderRadius:"10px" }}>{toast.msg}</Alert>
      </Snackbar>
    </Box>
  );
}
