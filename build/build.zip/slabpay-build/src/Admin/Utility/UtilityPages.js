import { useState } from "react";
import {
  Box, Typography, Paper, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, Chip, TextField,
  MenuItem, Button, InputAdornment, Grid, Tabs, Tab,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import DownloadIcon from "@mui/icons-material/Download";
import PhoneAndroidIcon from "@mui/icons-material/PhoneAndroid";
import ReceiptIcon from "@mui/icons-material/Receipt";
import CreditCardIcon from "@mui/icons-material/CreditCard";
import PaymentsIcon from "@mui/icons-material/Payments";

const C = { border: "#e5eaf5", text1: "#0f1623", text3: "#7a8aab" };

const rechargeData = [
  { id: "RCH001", user: "SNEHA REDDY", mobile: "9876543210", operator: "Jio", circle: "Telangana", amount: 399, date: "2025-04-01 10:00", status: "Success" },
  { id: "RCH002", user: "KAVITA NAIR", mobile: "8765432109", operator: "Airtel", circle: "Kerala", amount: 599, date: "2025-04-01 11:30", status: "Success" },
  { id: "RCH003", user: "SURESH BABU", mobile: "7654321098", operator: "Vi", circle: "Karnataka", amount: 249, date: "2025-04-02 09:00", status: "Failed" },
  { id: "RCH004", user: "PRIYA SHARMA", mobile: "6543210987", operator: "BSNL", circle: "Maharashtra", amount: 197, date: "2025-04-03 14:00", status: "Pending" },
];

const billData = [
  { id: "BILL001", user: "RAVI KUMAR", consumer: "1122334455", biller: "BESCOM", category: "Electricity", amount: 2400, date: "2025-04-01 09:30", status: "Success" },
  { id: "BILL002", user: "MANOJ PATEL", consumer: "9988776655", biller: "MSEDCL", category: "Electricity", amount: 5100, date: "2025-04-02 10:00", status: "Success" },
  { id: "BILL003", user: "KAVITA NAIR", consumer: "4455667788", biller: "Jio Fiber", category: "Broadband", amount: 999, date: "2025-04-03 13:00", status: "Pending" },
];

const panData = [
  { id: "PAN001", user: "SNEHA REDDY", applicant: "RAMU KRISHNA", dob: "1990-05-15", type: "New PAN", amount: 107, date: "2025-04-01 11:00", status: "Processing" },
  { id: "PAN002", user: "KAVITA NAIR", applicant: "SITA DEVI", dob: "1985-08-20", type: "Correction", amount: 107, date: "2025-04-02 09:00", status: "Submitted" },
  { id: "PAN003", user: "SURESH BABU", applicant: "ANAND RAO", dob: "1978-12-10", type: "New PAN", amount: 107, date: "2025-04-03 14:00", status: "Approved" },
];

const bbpsData = [
  { id: "BBPS001", user: "RAVI KUMAR", biller: "HDFC Credit Card", category: "Credit Card", amount: 15000, txnRef: "BBPS4251001", date: "2025-04-01 10:00", status: "Success" },
  { id: "BBPS002", user: "SNEHA REDDY", biller: "LIC Premium", category: "Insurance", amount: 8500, txnRef: "BBPS4251002", date: "2025-04-02 11:00", status: "Success" },
  { id: "BBPS003", user: "MANOJ PATEL", biller: "SBI Loan EMI", category: "Loan", amount: 12000, txnRef: "BBPS4251003", date: "2025-04-03 09:00", status: "Pending" },
];

const statusConfig = {
  Success:    { color: "#059669", bg: "#ecfdf5" },
  Pending:    { color: "#d97706", bg: "#fffbeb" },
  Failed:     { color: "#dc2626", bg: "#fef2f2" },
  Processing: { color: "#1a56db", bg: "#e8efff" },
  Submitted:  { color: "#7c3aed", bg: "#f5f3ff" },
  Approved:   { color: "#059669", bg: "#ecfdf5" },
};

function RechargeTab() {
  const [search, setSearch] = useState("");
  const filtered = rechargeData.filter(r => r.user.toLowerCase().includes(search.toLowerCase()) || r.mobile.includes(search));
  return (
    <Box>
      <Box sx={{ mb: 2, display: "flex", gap: 2 }}>
        <TextField size="small" placeholder="Search by user or mobile..." value={search}
          onChange={e => setSearch(e.target.value)}
          InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 18, color: C.text3 }} /></InputAdornment> }}
          sx={{ minWidth: 280, "& .MuiOutlinedInput-root": { borderRadius: "10px" } }} />
        <Box sx={{ flex: 1 }} />
        <Button startIcon={<DownloadIcon />} variant="outlined" size="small" sx={{ borderRadius: "10px", borderColor: C.border, color: C.text1, textTransform: "none" }}>Export</Button>
      </Box>
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow sx={{ "& th": { fontWeight: 700, fontSize: 12, color: C.text3, background: "#f8faff", py: 1.5 } }}>
              <TableCell>ID</TableCell><TableCell>User</TableCell><TableCell>Mobile</TableCell><TableCell>Operator</TableCell>
              <TableCell>Circle</TableCell><TableCell align="right">Amount</TableCell><TableCell>Date</TableCell><TableCell>Status</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filtered.map(row => {
              const sc = statusConfig[row.status];
              return (
                <TableRow key={row.id} sx={{ "&:hover": { background: "#f8faff" }, "& td": { fontSize: 13, py: 1.5 } }}>
                  <TableCell sx={{ fontWeight: 600, color: "#dc2626" }}>{row.id}</TableCell>
                  <TableCell sx={{ fontWeight: 600 }}>{row.user}</TableCell>
                  <TableCell sx={{ fontFamily: "monospace" }}>{row.mobile}</TableCell>
                  <TableCell>{row.operator}</TableCell>
                  <TableCell sx={{ color: C.text3 }}>{row.circle}</TableCell>
                  <TableCell align="right" sx={{ fontWeight: 700 }}>₹{row.amount}</TableCell>
                  <TableCell sx={{ color: C.text3, fontSize: 12 }}>{row.date}</TableCell>
                  <TableCell><Chip label={row.status} size="small" sx={{ background: sc.bg, color: sc.color, fontWeight: 600, fontSize: 11 }} /></TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
}

function BillTab() {
  return (
    <TableContainer>
      <Table>
        <TableHead>
          <TableRow sx={{ "& th": { fontWeight: 700, fontSize: 12, color: C.text3, background: "#f8faff", py: 1.5 } }}>
            <TableCell>ID</TableCell><TableCell>User</TableCell><TableCell>Consumer No.</TableCell><TableCell>Biller</TableCell>
            <TableCell>Category</TableCell><TableCell align="right">Amount</TableCell><TableCell>Date</TableCell><TableCell>Status</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {billData.map(row => {
            const sc = statusConfig[row.status];
            return (
              <TableRow key={row.id} sx={{ "&:hover": { background: "#f8faff" }, "& td": { fontSize: 13, py: 1.5 } }}>
                <TableCell sx={{ fontWeight: 600, color: "#dc2626" }}>{row.id}</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>{row.user}</TableCell>
                <TableCell sx={{ fontFamily: "monospace" }}>{row.consumer}</TableCell>
                <TableCell>{row.biller}</TableCell>
                <TableCell>{row.category}</TableCell>
                <TableCell align="right" sx={{ fontWeight: 700 }}>₹{row.amount.toLocaleString()}</TableCell>
                <TableCell sx={{ color: C.text3, fontSize: 12 }}>{row.date}</TableCell>
                <TableCell><Chip label={row.status} size="small" sx={{ background: sc.bg, color: sc.color, fontWeight: 600, fontSize: 11 }} /></TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </TableContainer>
  );
}

function PANTab() {
  return (
    <TableContainer>
      <Table>
        <TableHead>
          <TableRow sx={{ "& th": { fontWeight: 700, fontSize: 12, color: C.text3, background: "#f8faff", py: 1.5 } }}>
            <TableCell>ID</TableCell><TableCell>Agent</TableCell><TableCell>Applicant</TableCell>
            <TableCell>DOB</TableCell><TableCell>Type</TableCell><TableCell align="right">Fee</TableCell>
            <TableCell>Date</TableCell><TableCell>Status</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {panData.map(row => {
            const sc = statusConfig[row.status];
            return (
              <TableRow key={row.id} sx={{ "&:hover": { background: "#f8faff" }, "& td": { fontSize: 13, py: 1.5 } }}>
                <TableCell sx={{ fontWeight: 600, color: "#dc2626" }}>{row.id}</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>{row.user}</TableCell>
                <TableCell>{row.applicant}</TableCell>
                <TableCell sx={{ fontFamily: "monospace" }}>{row.dob}</TableCell>
                <TableCell>{row.type}</TableCell>
                <TableCell align="right" sx={{ fontWeight: 700 }}>₹{row.amount}</TableCell>
                <TableCell sx={{ color: C.text3, fontSize: 12 }}>{row.date}</TableCell>
                <TableCell><Chip label={row.status} size="small" sx={{ background: sc.bg, color: sc.color, fontWeight: 600, fontSize: 11 }} /></TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </TableContainer>
  );
}

function BBPSTab() {
  return (
    <TableContainer>
      <Table>
        <TableHead>
          <TableRow sx={{ "& th": { fontWeight: 700, fontSize: 12, color: C.text3, background: "#f8faff", py: 1.5 } }}>
            <TableCell>ID</TableCell><TableCell>User</TableCell><TableCell>Biller</TableCell>
            <TableCell>Category</TableCell><TableCell>Txn Ref</TableCell>
            <TableCell align="right">Amount</TableCell><TableCell>Date</TableCell><TableCell>Status</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {bbpsData.map(row => {
            const sc = statusConfig[row.status];
            return (
              <TableRow key={row.id} sx={{ "&:hover": { background: "#f8faff" }, "& td": { fontSize: 13, py: 1.5 } }}>
                <TableCell sx={{ fontWeight: 600, color: "#dc2626" }}>{row.id}</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>{row.user}</TableCell>
                <TableCell>{row.biller}</TableCell>
                <TableCell>{row.category}</TableCell>
                <TableCell sx={{ fontFamily: "monospace", fontSize: 12 }}>{row.txnRef}</TableCell>
                <TableCell align="right" sx={{ fontWeight: 700 }}>₹{row.amount.toLocaleString()}</TableCell>
                <TableCell sx={{ color: C.text3, fontSize: 12 }}>{row.date}</TableCell>
                <TableCell><Chip label={row.status} size="small" sx={{ background: sc.bg, color: sc.color, fontWeight: 600, fontSize: 11 }} /></TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </TableContainer>
  );
}

export function RechargeUtility() {
  return (
    <Box>
      <Box sx={{ mb: 3 }}>
        <Typography sx={{ fontSize: 22, fontWeight: 800, color: C.text1 }}>Recharge</Typography>
        <Typography sx={{ fontSize: 13, color: C.text3 }}>Mobile and DTH recharge transactions</Typography>
      </Box>
      <Paper elevation={0} sx={{ borderRadius: "16px", border: `1px solid ${C.border}`, p: 2.5 }}>
        <RechargeTab />
      </Paper>
    </Box>
  );
}

export function BillPaymentUtility() {
  return (
    <Box>
      <Box sx={{ mb: 3 }}>
        <Typography sx={{ fontSize: 22, fontWeight: 800, color: C.text1 }}>Bill Payment</Typography>
        <Typography sx={{ fontSize: 13, color: C.text3 }}>Utility and service bill payment records</Typography>
      </Box>
      <Paper elevation={0} sx={{ borderRadius: "16px", border: `1px solid ${C.border}`, p: 2.5 }}>
        <BillTab />
      </Paper>
    </Box>
  );
}

export function PANService() {
  return (
    <Box>
      <Box sx={{ mb: 3 }}>
        <Typography sx={{ fontSize: 22, fontWeight: 800, color: C.text1 }}>PAN Service</Typography>
        <Typography sx={{ fontSize: 13, color: C.text3 }}>PAN card application and correction requests</Typography>
      </Box>
      <Paper elevation={0} sx={{ borderRadius: "16px", border: `1px solid ${C.border}`, p: 2.5 }}>
        <PANTab />
      </Paper>
    </Box>
  );
}

export function BBPSUtility() {
  return (
    <Box>
      <Box sx={{ mb: 3 }}>
        <Typography sx={{ fontSize: 22, fontWeight: 800, color: C.text1 }}>BBPS Transactions</Typography>
        <Typography sx={{ fontSize: 13, color: C.text3 }}>Bharat Bill Payment System transaction records</Typography>
      </Box>
      <Paper elevation={0} sx={{ borderRadius: "16px", border: `1px solid ${C.border}`, p: 2.5 }}>
        <BBPSTab />
      </Paper>
    </Box>
  );
}
