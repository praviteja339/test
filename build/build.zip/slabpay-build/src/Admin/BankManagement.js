import { useState, useEffect, useCallback } from "react";
import {
  Box, Typography, Paper, Chip, Button, TextField, Dialog, DialogTitle,
  DialogContent, DialogActions, Grid, Switch, CircularProgress, Alert, Snackbar, IconButton, Tooltip,
} from "@mui/material";
import { Add, Edit, Delete, Refresh, AccountBalance } from "@mui/icons-material";
import { getBanks, createBank, updateBank, deleteBank, toggleBankTransfer } from "../services/adminApi";

const A = "#dc2626";
const C = { border:"#e5eaf5", text1:"#0f1623", text2:"#3a4563", text3:"#7a8aab" };

const emptyBank = { name:"", position:"", isFundTransfer:true };

export default function BankManagement() {
  const [banks,    setBanks]    = useState([]);
  const [loading,  setLoading]  = useState(true);
  const [toast,    setToast]    = useState({ open:false, msg:"", sev:"success" });
  const [editOpen, setEditOpen] = useState(false);
  const [addOpen,  setAddOpen]  = useState(false);
  const [current,  setCurrent]  = useState(null);
  const [form,     setForm]     = useState(emptyBank);
  const [saving,   setSaving]   = useState(false);

  const showToast = (msg, sev="success") => setToast({ open:true, msg, sev });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getBanks();
      setBanks(Array.isArray(res.data.data) ? res.data.data : []);
    } catch { showToast("Failed to load banks.", "error"); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleCreate = async () => {
    setSaving(true);
    try {
      await createBank({ ...form, position: form.position ? Number(form.position) : null,
        createdBy: Number(localStorage.getItem("userId")||1) });
      showToast("Bank created."); setAddOpen(false); setForm(emptyBank); load();
    } catch { showToast("Failed to create bank.", "error"); }
    finally { setSaving(false); }
  };

  const handleUpdate = async () => {
    setSaving(true);
    try {
      await updateBank(current.bankId, { ...form, position: form.position ? Number(form.position) : null });
      showToast("Bank updated."); setEditOpen(false); load();
    } catch { showToast("Failed to update bank.", "error"); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this bank?")) return;
    try { await deleteBank(id); showToast("Bank deleted."); load(); }
    catch { showToast("Failed to delete bank.", "error"); }
  };

  const handleToggle = async (bank) => {
    try {
      await toggleBankTransfer(bank.bankId, !bank.isFundTransfer);
      showToast(`Fund transfer ${!bank.isFundTransfer ? "enabled" : "disabled"}.`);
      load();
    } catch { showToast("Failed to update status.", "error"); }
  };

  const openEdit = (bank) => { setCurrent(bank); setForm({ name:bank.name, position:bank.position||"", isFundTransfer:bank.isFundTransfer }); setEditOpen(true); };

  return (
    <Box>
      <Box sx={{ mb:3,display:"flex",alignItems:"flex-start",justifyContent:"space-between",flexWrap:"wrap",gap:2 }}>
        <Box>
          <Typography sx={{ fontSize:22,fontWeight:800,color:C.text1 }}>Bank Management</Typography>
          <Typography sx={{ fontSize:13,color:C.text3 }}>{banks.length} banks registered · controls transfer dropdowns</Typography>
        </Box>
        <Box sx={{ display:"flex",gap:1 }}>
          <Tooltip title="Refresh"><IconButton onClick={load} sx={{ border:`1px solid ${C.border}`,borderRadius:"10px" }}><Refresh fontSize="small"/></IconButton></Tooltip>
          <Button startIcon={<Add/>} variant="contained" onClick={()=>{ setForm(emptyBank); setAddOpen(true); }}
            sx={{ background:A,borderRadius:"10px",textTransform:"none",fontWeight:700,"&:hover":{background:"#b91c1c"} }}>
            Add Bank
          </Button>
        </Box>
      </Box>

      {loading ? (
        <Box sx={{ display:"flex",justifyContent:"center",mt:8 }}><CircularProgress sx={{ color:A }}/></Box>
      ) : (
        <Grid container spacing={2}>
          {banks.length===0 ? (
            <Grid item xs={12}>
              <Paper elevation={0} sx={{ p:6,textAlign:"center",borderRadius:"16px",border:`1px solid ${C.border}` }}>
                <AccountBalance sx={{ fontSize:48,color:"#e5eaf5",mb:2 }}/>
                <Typography sx={{ color:C.text3 }}>No banks registered. Add the first one.</Typography>
              </Paper>
            </Grid>
          ) : banks.map(b=>(
            <Grid item xs={12} sm={6} md={4} key={b.bankId}>
              <Paper elevation={0} sx={{ p:2.5,borderRadius:"16px",border:`1px solid ${C.border}`,"&:hover":{ boxShadow:"0 4px 16px rgba(0,0,0,0.06)" },transition:"box-shadow 0.2s" }}>
                <Box sx={{ display:"flex",alignItems:"flex-start",justifyContent:"space-between",mb:1.5 }}>
                  <Box sx={{ display:"flex",alignItems:"center",gap:1.5 }}>
                    <Box sx={{ width:40,height:40,borderRadius:"10px",background:"#e8efff",display:"flex",alignItems:"center",justifyContent:"center",color:"#1a56db" }}>
                      <AccountBalance fontSize="small"/>
                    </Box>
                    <Box>
                      <Typography sx={{ fontSize:14,fontWeight:700,color:C.text1 }}>{b.name}</Typography>
                      <Typography sx={{ fontSize:11,color:C.text3 }}>Position: {b.position ?? "—"}</Typography>
                    </Box>
                  </Box>
                  <Chip label={b.isFundTransfer ? "Active" : "Inactive"} size="small"
                    sx={{ background:b.isFundTransfer?"#ecfdf5":"#f3f4f6", color:b.isFundTransfer?"#059669":"#6b7280", fontWeight:600,fontSize:11 }}/>
                </Box>
                <Box sx={{ display:"flex",alignItems:"center",justifyContent:"space-between",mt:1 }}>
                  <Box sx={{ display:"flex",alignItems:"center",gap:0.5 }}>
                    <Typography sx={{ fontSize:12,color:C.text3 }}>Fund Transfer</Typography>
                    <Switch checked={!!b.isFundTransfer} onChange={()=>handleToggle(b)} size="small"
                      sx={{ "& .MuiSwitch-switchBase.Mui-checked":{ color:A },"& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track":{ background:A } }}/>
                  </Box>
                  <Box sx={{ display:"flex",gap:0.5 }}>
                    <Tooltip title="Edit"><IconButton size="small" onClick={()=>openEdit(b)}><Edit fontSize="small" sx={{ color:C.text3 }}/></IconButton></Tooltip>
                    <Tooltip title="Delete"><IconButton size="small" onClick={()=>handleDelete(b.bankId)}><Delete fontSize="small" sx={{ color:A }}/></IconButton></Tooltip>
                  </Box>
                </Box>
              </Paper>
            </Grid>
          ))}
        </Grid>
      )}

      {/* Add Dialog */}
      <Dialog open={addOpen} onClose={()=>setAddOpen(false)} maxWidth="sm" fullWidth PaperProps={{ sx:{ borderRadius:"16px" } }}>
        <DialogTitle sx={{ fontWeight:800,color:C.text1 }}>Add New Bank</DialogTitle>
        <DialogContent dividers>
          <Grid container spacing={2} sx={{ pt:1 }}>
            <Grid item xs={12}><TextField label="Bank Name" value={form.name} fullWidth size="small" onChange={e=>setForm({...form,name:e.target.value})} sx={{ "& .MuiOutlinedInput-root":{ borderRadius:"10px" } }}/></Grid>
            <Grid item xs={12} sm={6}><TextField label="Display Position" type="number" value={form.position} fullWidth size="small" onChange={e=>setForm({...form,position:e.target.value})} sx={{ "& .MuiOutlinedInput-root":{ borderRadius:"10px" } }}/></Grid>
            <Grid item xs={12} sm={6} sx={{ display:"flex",alignItems:"center",gap:1 }}>
              <Typography sx={{ fontSize:13,color:C.text2 }}>Fund Transfer Enabled</Typography>
              <Switch checked={form.isFundTransfer} onChange={e=>setForm({...form,isFundTransfer:e.target.checked})} sx={{ "& .MuiSwitch-switchBase.Mui-checked":{ color:A },"& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track":{ background:A } }}/>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ p:2.5,gap:1 }}>
          <Button onClick={()=>setAddOpen(false)} sx={{ textTransform:"none",borderRadius:"10px" }}>Cancel</Button>
          <Button onClick={handleCreate} variant="contained" disabled={saving||!form.name}
            sx={{ background:A,borderRadius:"10px",textTransform:"none",fontWeight:700,"&:hover":{background:"#b91c1c"} }}>
            {saving ? <CircularProgress size={18} sx={{ color:"#fff" }}/> : "Create"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={editOpen} onClose={()=>setEditOpen(false)} maxWidth="sm" fullWidth PaperProps={{ sx:{ borderRadius:"16px" } }}>
        <DialogTitle sx={{ fontWeight:800,color:C.text1 }}>Edit Bank</DialogTitle>
        <DialogContent dividers>
          <Grid container spacing={2} sx={{ pt:1 }}>
            <Grid item xs={12}><TextField label="Bank Name" value={form.name} fullWidth size="small" onChange={e=>setForm({...form,name:e.target.value})} sx={{ "& .MuiOutlinedInput-root":{ borderRadius:"10px" } }}/></Grid>
            <Grid item xs={12} sm={6}><TextField label="Display Position" type="number" value={form.position} fullWidth size="small" onChange={e=>setForm({...form,position:e.target.value})} sx={{ "& .MuiOutlinedInput-root":{ borderRadius:"10px" } }}/></Grid>
            <Grid item xs={12} sm={6} sx={{ display:"flex",alignItems:"center",gap:1 }}>
              <Typography sx={{ fontSize:13,color:C.text2 }}>Fund Transfer Enabled</Typography>
              <Switch checked={form.isFundTransfer} onChange={e=>setForm({...form,isFundTransfer:e.target.checked})} sx={{ "& .MuiSwitch-switchBase.Mui-checked":{ color:A },"& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track":{ background:A } }}/>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ p:2.5,gap:1 }}>
          <Button onClick={()=>setEditOpen(false)} sx={{ textTransform:"none",borderRadius:"10px" }}>Cancel</Button>
          <Button onClick={handleUpdate} variant="contained" disabled={saving||!form.name}
            sx={{ background:A,borderRadius:"10px",textTransform:"none",fontWeight:700,"&:hover":{background:"#b91c1c"} }}>
            {saving ? <CircularProgress size={18} sx={{ color:"#fff" }}/> : "Save"}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar open={toast.open} autoHideDuration={3500} onClose={()=>setToast({...toast,open:false})} anchorOrigin={{ vertical:"bottom",horizontal:"right" }}>
        <Alert severity={toast.sev} sx={{ borderRadius:"10px" }}>{toast.msg}</Alert>
      </Snackbar>
    </Box>
  );
}
