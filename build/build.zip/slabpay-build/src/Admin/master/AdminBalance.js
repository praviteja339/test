import { useState, useEffect, useCallback } from "react";
import {
  Avatar, Box, Typography, Paper, TextField, Button, Grid, Stack,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  IconButton, InputAdornment, Card, CardContent, CircularProgress,
  Alert, Snackbar, Chip,
} from "@mui/material";
import {
  AccountBalanceWalletRounded, SaveRounded, HistoryRounded,
  RefreshRounded, TrendingUpRounded, UpdateRounded,
} from "@mui/icons-material";
import { getAdminBalance, updateBalance, getAdminLedger } from "../../services/adminApi";

const THEME = {
  primary: "#dc2626",
  secondary: "#0f172a",
  border: "#e2e8f0",
  textMuted: "#64748b",
};

const toWords = (n) => {
  if (!n || isNaN(n)) return "";
  const num = Number(n);
  if (num >= 10000000) return `${(num/10000000).toFixed(2)} Crore`;
  if (num >= 100000)  return `${(num/100000).toFixed(2)} Lakh`;
  if (num >= 1000)    return `${(num/1000).toFixed(2)} Thousand`;
  return String(num);
};

const fmt = (n) => n == null ? "₹0.00" : "₹" + Number(n).toLocaleString("en-IN", { minimumFractionDigits: 2 });

export default function AdminBalanceMaster() {
  const adminId = localStorage.getItem("userId") || "1";
  const [currentBalance, setCurrentBalance] = useState(null);
  const [ledger,   setLedger]   = useState([]);
  const [loading,  setLoading]  = useState(true);
  const [saving,   setSaving]   = useState(false);
  const [amount,   setAmount]   = useState("");
  const [toast,    setToast]    = useState({ open: false, msg: "", sev: "success" });

  const showToast = (msg, sev = "success") => setToast({ open: true, msg, sev });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [uRes, lRes] = await Promise.all([
        getAdminBalance(adminId),
        getAdminLedger(adminId),
      ]);
      setCurrentBalance(uRes.data?.data?.balance ?? 0);
      const entries = Array.isArray(lRes.data?.data) ? lRes.data.data :
                      Array.isArray(lRes.data?.data?.entries) ? lRes.data.data.entries : [];
      setLedger(entries.slice(0, 20));
    } catch {
      showToast("Failed to load admin balance data.", "error");
    } finally { setLoading(false); }
  }, [adminId]);

  useEffect(() => { load(); }, [load]);

  const handleSave = async () => {
    if (!amount || isNaN(amount) || Number(amount) <= 0) {
      showToast("Enter a valid amount.", "error"); return;
    }
    setSaving(true);
    try {
      await updateBalance(adminId, Number(amount), "credit");
      showToast("Balance updated successfully.");
      setAmount("");
      load();
    } catch {
      showToast("Failed to update balance.", "error");
    } finally { setSaving(false); }
  };

  return (
    <Box>
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 4 }}>
        <Box>
          <Typography variant="h5" sx={{ fontWeight: 700, color: THEME.secondary, letterSpacing: "-0.02em" }}>
            Balance Master
          </Typography>
          <Typography sx={{ fontSize: 13, color: THEME.textMuted, mt: 0.3 }}>
            Manage and track the system-wide Admin wallet
          </Typography>
        </Box>
        <IconButton onClick={load} disabled={loading}
          sx={{ bgcolor: THEME.primary, color: "#fff", "&:hover": { bgcolor: "#b91c1c" } }}>
          <RefreshRounded />
        </IconButton>
      </Stack>

      {/* Current balance banner */}
      <Paper elevation={0} sx={{ p: 3, mb: 3, borderRadius: "16px", background: "linear-gradient(135deg,#dc2626,#b91c1c)", color: "#fff" }}>
        <Typography sx={{ fontSize: 12, fontWeight: 700, letterSpacing: "0.08em", opacity: 0.8, textTransform: "uppercase", mb: 0.5 }}>
          Current Admin Balance
        </Typography>
        {loading ? <CircularProgress size={24} sx={{ color: "#fff" }} /> :
          <Typography sx={{ fontSize: 32, fontWeight: 900 }}>{fmt(currentBalance)}</Typography>}
        <Typography sx={{ fontSize: 12, opacity: 0.75, mt: 0.5 }}>{toWords(currentBalance)}</Typography>
      </Paper>

      <Grid container spacing={3}>
        {/* Input form */}
        <Grid item xs={12} lg={4}>
          <Card elevation={0} sx={{ borderRadius: "16px", border: `1px solid ${THEME.border}` }}>
            <CardContent sx={{ p: 3 }}>
              <Stack spacing={3}>
                <Stack direction="row" spacing={1.5} alignItems="center">
                  <Avatar sx={{ bgcolor: "#fef2f2", color: THEME.primary }}>
                    <AccountBalanceWalletRounded />
                  </Avatar>
                  <Typography variant="h6" sx={{ fontWeight: 700, fontSize: 15 }}>Credit Admin Wallet</Typography>
                </Stack>

                <TextField
                  fullWidth label="Amount to Credit (₹)" type="number"
                  placeholder="Enter amount" value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  InputProps={{
                    startAdornment: <InputAdornment position="start">₹</InputAdornment>,
                    sx: { borderRadius: "12px" },
                  }}
                />

                {amount && !isNaN(amount) && Number(amount) > 0 && (
                  <Box sx={{ p: 1.5, background: "#f8faff", borderRadius: "10px", border: "1px solid #e5eaf5" }}>
                    <Typography sx={{ fontSize: 12, color: THEME.textMuted }}>In Words</Typography>
                    <Typography sx={{ fontSize: 13, fontWeight: 600, color: THEME.secondary }}>{toWords(amount)} Rupees</Typography>
                    <Typography sx={{ fontSize: 12, color: "#059669", mt: 0.5 }}>
                      New Balance: {fmt((Number(currentBalance)||0) + Number(amount))}
                    </Typography>
                  </Box>
                )}

                <Button fullWidth variant="contained" startIcon={<SaveRounded />}
                  onClick={handleSave} disabled={saving || !amount}
                  sx={{ bgcolor: THEME.primary, borderRadius: "12px", py: 1.5, fontWeight: 700,
                    textTransform: "none", "&:hover": { bgcolor: "#b91c1c" } }}>
                  {saving ? <CircularProgress size={20} sx={{ color: "#fff" }} /> : "Credit Balance"}
                </Button>
              </Stack>
            </CardContent>
          </Card>
        </Grid>

        {/* Ledger history */}
        <Grid item xs={12} lg={8}>
          <TableContainer component={Paper} elevation={0}
            sx={{ borderRadius: "16px", border: `1px solid ${THEME.border}`, overflow: "hidden" }}>
            <Box sx={{ px: 3, py: 2.5, borderBottom: `1px solid ${THEME.border}`, display: "flex", alignItems: "center", gap: 1 }}>
              <HistoryRounded sx={{ color: THEME.textMuted }} />
              <Typography sx={{ fontWeight: 700 }}>Wallet Ledger History</Typography>
              <Chip label="Last 20 entries" size="small" sx={{ ml: "auto", background: "#f3f4f6", color: THEME.textMuted, fontSize: 11 }} />
            </Box>
            {loading ? (
              <Box sx={{ p: 6, textAlign: "center" }}><CircularProgress sx={{ color: THEME.primary }} /></Box>
            ) : (
              <Table>
                <TableHead sx={{ bgcolor: "#f8fafc" }}>
                  <TableRow>
                    {["ID", "Type", "Description", "Date", "Amount", "Balance"].map(h => (
                      <TableCell key={h} sx={{ fontWeight: 700, color: THEME.textMuted, fontSize: 12 }}>{h}</TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {ledger.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} align="center" sx={{ py: 6, color: THEME.textMuted }}>
                        No ledger entries yet.
                      </TableCell>
                    </TableRow>
                  ) : ledger.map((row, i) => (
                    <TableRow key={row.id || i} hover>
                      <TableCell sx={{ fontWeight: 600, color: THEME.textMuted, fontSize: 12 }}>#{row.id}</TableCell>
                      <TableCell>
                        <Chip label={row.eType || row.entryType || "—"} size="small"
                          sx={{ background: row.eType === "Cr" ? "#ecfdf5" : "#fef2f2",
                            color: row.eType === "Cr" ? "#059669" : "#dc2626", fontWeight: 700, fontSize: 11 }} />
                      </TableCell>
                      <TableCell sx={{ fontSize: 13, color: THEME.secondary }}>{row.description || row.narration || "Balance update"}</TableCell>
                      <TableCell>
                        <Stack direction="row" spacing={1} alignItems="center">
                          <UpdateRounded sx={{ fontSize: 15, color: THEME.primary }} />
                          <Typography sx={{ fontSize: 13 }}>
                            {row.createdDate ? new Date(row.createdDate).toLocaleDateString("en-IN") : "—"}
                          </Typography>
                        </Stack>
                      </TableCell>
                      <TableCell>
                        <Typography sx={{ fontWeight: 800, fontSize: 13,
                          color: row.eType === "Cr" ? "#059669" : "#dc2626" }}>
                          {fmt(row.amount)}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Typography sx={{ fontWeight: 700, fontSize: 13, color: THEME.secondary }}>
                          {fmt(row.closingBalance || row.balance)}
                        </Typography>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </TableContainer>

          <Paper elevation={0} sx={{ mt: 3, p: 2, borderRadius: "12px", bgcolor: "#eff6ff", border: "1px solid #dbeafe" }}>
            <Stack direction="row" spacing={2} alignItems="center">
              <TrendingUpRounded sx={{ color: "#1e40af" }} />
              <Typography sx={{ color: "#1e40af", fontSize: 13, fontWeight: 500 }}>
                System-wide balance is shared across all distributor tiers. Ensure all manual entries match bank statements.
              </Typography>
            </Stack>
          </Paper>
        </Grid>
      </Grid>

      <Snackbar open={toast.open} autoHideDuration={3500} onClose={() => setToast({ ...toast, open: false })}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}>
        <Alert severity={toast.sev} sx={{ borderRadius: "10px" }}>{toast.msg}</Alert>
      </Snackbar>
    </Box>
  );
}
