import React, { useState, useMemo, useEffect, useCallback } from "react";
import {
  Box, Typography, Grid, Paper, TextField, Select, MenuItem,
  FormControl, IconButton, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, Button, Stack, Avatar,
  Chip, InputAdornment, Dialog, DialogTitle, DialogContent,
  DialogActions, CircularProgress, Alert, Snackbar, Divider
} from "@mui/material";
import {
  EditTwoTone, LockTwoTone, AddRounded, SearchRounded,
  FilterListRounded, PhoneIphoneRounded, BusinessRounded,
  LocationOnRounded, LockOpenTwoTone, CloseRounded
} from "@mui/icons-material";

const COLORS = {
  bg: "#f8fafc",
  primary: "#1a56db",
  secondary: "#0f172a",
  accent: "#2bb3c0",
  border: "#e2e8f0",
  textMuted: "#64748b",
  success: "#10b981",
  danger: "#ef4444"
};

const BASE_URL = "https://slabpay.azurewebsites.net/api/v1";

const EMPTY_FORM = {
  userName: "",
  registeredMobileNo: "",
  password: "",
  company: "",
  area: "",
  city: "",
  pincode: "",
  gstStateCode: "",
  emailId: "",
  distributorId: "",
  superDistId: "",
  roleId: 4,
  utype: "R",
  mpin: ""
};

// ✅ Read token from localStorage (key: "token")
function getAuthHeaders() {
  const token = localStorage.getItem("token");
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {})
  };
}

// Shared field styles
const fieldSx = {
  "& .MuiOutlinedInput-root": {
    borderRadius: "10px",
    "& fieldset": { borderColor: "#e2e8f0" },
    "&:hover fieldset": { borderColor: "#1a56db" },
    "&.Mui-focused fieldset": { borderColor: "#1a56db" }
  }
};

export default function RetailerTable() {
  const [records, setRecords] = useState(10);
  const [search, setSearch] = useState("");
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [fetchError, setFetchError] = useState(null);

  // Modal state
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState(null);

  // Snackbar
  const [snack, setSnack] = useState({ open: false, message: "", severity: "success" });

  // ─── Fetch Retailers ────────────────────────────────────────────────────────
  const fetchRetailers = useCallback(async () => {
    setLoading(true);
    setFetchError(null);
    try {
      const res = await fetch(`${BASE_URL}/users/type/R`, {
        headers: getAuthHeaders()
      });
      const json = await res.json();
      if (json.success && Array.isArray(json.data)) {
        setRows(json.data);
      } else {
        setFetchError(json.message || "Failed to load retailers.");
      }
    } catch (err) {
      setFetchError("Network error: " + err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchRetailers();
  }, [fetchRetailers]);

  // ─── Filtered + Paginated ───────────────────────────────────────────────────
  const filteredRows = useMemo(() => {
    const term = search.toLowerCase();
    return rows
      .filter((row) =>
        (row.userName || "").toLowerCase().includes(term) ||
        (row.company || "").toLowerCase().includes(term) ||
        (row.registeredMobileNo || "").includes(term) ||
        String(row.id).includes(term)
      )
      .slice(0, records);
  }, [search, records, rows]);

  // ─── Form Handlers ──────────────────────────────────────────────────────────
  const handleOpenModal = () => {
    setForm(EMPTY_FORM);
    setFormError(null);
    setModalOpen(true);
  };

  const handleCloseModal = () => {
    if (!submitting) setModalOpen(false);
  };

  const handleFormChange = (field) => (e) => {
    setForm((prev) => ({ ...prev, [field]: e.target.value }));
  };

  const handleSubmit = async () => {
    // Basic validation
    const required = ["userName", "registeredMobileNo", "password", "company", "area", "city", "pincode", "emailId", "mpin"];
    const missing = required.find((f) => !form[f]);
    if (missing) {
      setFormError(`Please fill in required field: ${missing}`);
      return;
    }

    setSubmitting(true);
    setFormError(null);

    const payload = {
      ...form,
      distributorId: form.distributorId ? Number(form.distributorId) : undefined,
      superDistId: form.superDistId ? Number(form.superDistId) : undefined,
      roleId: Number(form.roleId)
    };

    try {
      const res = await fetch(`${BASE_URL}/users`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify(payload)
      });
      const json = await res.json();
      if (json.success) {
        setModalOpen(false);
        setSnack({ open: true, message: "Retailer created successfully!", severity: "success" });
        fetchRetailers(); // refresh table
      } else {
        setFormError(json.message || "Failed to create retailer.");
      }
    } catch (err) {
      setFormError("Network error: " + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  // ─── UI ─────────────────────────────────────────────────────────────────────
  return (
    <Box sx={{ bgcolor: COLORS.bg, minHeight: "100vh" }}>

      {/* HEADER */}
      <Stack
        direction={{ xs: "column", sm: "row" }}
        justifyContent="space-between"
        alignItems={{ sm: "center" }}
        sx={{ mb: 4 }}
        spacing={2}
      >
        <Box>
          <Typography variant="h5" sx={{ fontWeight: 700, color: COLORS.secondary }}>Retailers</Typography>
          <Typography variant="body2" sx={{ color: COLORS.textMuted, mt: 0.5 }}>
            {rows.length} total retailers
          </Typography>
        </Box>
        <Button
          variant="contained"
          startIcon={<AddRounded />}
          onClick={handleOpenModal}
          sx={{ bgcolor: COLORS.primary, borderRadius: "12px", textTransform: "none", px: 3, fontWeight: 700 }}
        >
          Add Retailer
        </Button>
      </Stack>

      {/* FETCH ERROR */}
      {fetchError && (
        <Alert severity="error" sx={{ mb: 2, borderRadius: "12px" }}>{fetchError}</Alert>
      )}

      {/* FILTER & SEARCH CARD */}
      <Paper elevation={0} sx={{ p: 2.5, mb: 3, borderRadius: "16px", border: `1px solid ${COLORS.border}` }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              size="small"
              placeholder="Search name, company, or ID..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchRounded sx={{ color: COLORS.textMuted }} />
                  </InputAdornment>
                ),
                sx: { borderRadius: "10px", bgcolor: "#f1f5f9", "& fieldset": { border: "none" } }
              }}
            />
          </Grid>
          <Grid item xs={6} md={2}>
            <FormControl fullWidth size="small">
              <Select
                value={records}
                onChange={(e) => setRecords(e.target.value)}
                sx={{ borderRadius: "10px", bgcolor: "#f1f5f9", "& .MuiOutlinedInput-notchedOutline": { border: "none" } }}
              >
                <MenuItem value={5}>5 Records</MenuItem>
                <MenuItem value={10}>10 Records</MenuItem>
                <MenuItem value={20}>20 Records</MenuItem>
                <MenuItem value={50}>50 Records</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={6} md={2}>
            <Button
              fullWidth
              variant="outlined"
              startIcon={<FilterListRounded />}
              sx={{ borderRadius: "10px", textTransform: "none", borderColor: COLORS.border, color: COLORS.secondary, height: "40px" }}
            >
              Filters
            </Button>
          </Grid>
        </Grid>
      </Paper>

      {/* TABLE */}
      <TableContainer component={Paper} elevation={0} sx={{ borderRadius: "16px", border: `1px solid ${COLORS.border}`, overflow: "hidden" }}>
        <Table>
          <TableHead sx={{ bgcolor: "#f8fafc" }}>
            <TableRow>
              {["RETAILER", "CONTACT INFO", "LOCATION", "STATUS", "BALANCE", "ACTIONS"].map((head, index) => (
                <TableCell
                  key={head}
                  align={index > 3 ? "center" : "left"}
                  sx={{ py: 2, fontWeight: 700, color: COLORS.textMuted, fontSize: 11 }}
                >
                  {head}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>

          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={6} align="center" sx={{ py: 8 }}>
                  <CircularProgress size={32} sx={{ color: COLORS.primary }} />
                  <Typography sx={{ mt: 1, color: COLORS.textMuted, fontSize: 13 }}>Loading retailers...</Typography>
                </TableCell>
              </TableRow>
            ) : filteredRows.length > 0 ? (
              filteredRows.map((row) => (
                <TableRow key={row.id} hover>
                  <TableCell>
                    <Stack direction="row" spacing={2} alignItems="center">
                      <Avatar sx={{ bgcolor: `${COLORS.accent}15`, color: COLORS.accent, fontWeight: 700, borderRadius: "10px" }}>
                        {(row.userName || "?").charAt(0).toUpperCase()}
                      </Avatar>
                      <Box>
                        <Typography sx={{ fontWeight: 700, color: COLORS.secondary, fontSize: 14 }}>{row.userName}</Typography>
                        <Typography sx={{ fontSize: 12, color: COLORS.textMuted }}>ID: {row.id} · {row.utype}</Typography>
                      </Box>
                    </Stack>
                  </TableCell>

                  <TableCell>
                    <Stack spacing={0.5}>
                      <Stack direction="row" spacing={1} alignItems="center">
                        <BusinessRounded sx={{ fontSize: 16, color: COLORS.textMuted }} />
                        <Typography sx={{ fontSize: 13 }}>{row.company || "—"}</Typography>
                      </Stack>
                      <Stack direction="row" spacing={1} alignItems="center">
                        <PhoneIphoneRounded sx={{ fontSize: 16, color: COLORS.textMuted }} />
                        <Typography sx={{ fontSize: 13, color: COLORS.textMuted }}>{row.registeredMobileNo}</Typography>
                      </Stack>
                    </Stack>
                  </TableCell>

                  <TableCell>
                    <Stack direction="row" spacing={0.5} alignItems="center">
                      <LocationOnRounded sx={{ fontSize: 16, color: COLORS.danger }} />
                      <Typography sx={{ fontSize: 13 }}>
                        {[row.area, row.city].filter(Boolean).join(", ") || "—"}
                      </Typography>
                    </Stack>
                  </TableCell>

                  <TableCell>
                    <Chip
                      label={row.isLocked ? "Locked" : "Active"}
                      size="small"
                      sx={{
                        fontWeight: 700,
                        bgcolor: row.isLocked ? `${COLORS.danger}10` : `${COLORS.success}10`,
                        color: row.isLocked ? COLORS.danger : COLORS.success
                      }}
                    />
                  </TableCell>

                  <TableCell align="center">
                    <Typography sx={{ fontWeight: 800 }}>₹ {(row.balance ?? 0).toFixed(2)}</Typography>
                  </TableCell>

                  <TableCell align="center">
                    <Stack direction="row" spacing={1} justifyContent="center">
                      <IconButton size="small" sx={{ color: COLORS.primary, bgcolor: `${COLORS.primary}10` }}>
                        <EditTwoTone fontSize="small" />
                      </IconButton>
                      <IconButton
                        size="small"
                        sx={{
                          color: row.isLocked ? COLORS.success : COLORS.danger,
                          bgcolor: row.isLocked ? `${COLORS.success}10` : `${COLORS.danger}10`
                        }}
                      >
                        {row.isLocked ? <LockOpenTwoTone fontSize="small" /> : <LockTwoTone fontSize="small" />}
                      </IconButton>
                    </Stack>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={6} align="center" sx={{ py: 10 }}>
                  <Typography color="textSecondary">
                    No retailers found{search ? ` matching "${search}"` : ""}.
                  </Typography>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      <Typography sx={{ mt: 2, textAlign: "center", fontSize: 12, color: COLORS.textMuted }}>
        Showing <b>{filteredRows.length}</b> of <b>{rows.length}</b> total records
      </Typography>

      {/* ─── ADD RETAILER MODAL ─────────────────────────────────────────────────── */}
      <Dialog
        open={modalOpen}
        onClose={handleCloseModal}
        maxWidth="sm"
        fullWidth
        PaperProps={{ sx: { borderRadius: "20px", p: 1 } }}
      >
        <DialogTitle sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", pb: 1 }}>
          <Typography variant="h6" sx={{ fontWeight: 700, color: COLORS.secondary }}>
            Add New Retailer
          </Typography>
          <IconButton onClick={handleCloseModal} disabled={submitting} size="small">
            <CloseRounded />
          </IconButton>
        </DialogTitle>

        <Divider />

        <DialogContent sx={{ pt: 2.5 }}>
          {formError && (
            <Alert severity="error" sx={{ mb: 2, borderRadius: "10px" }}>{formError}</Alert>
          )}

          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField label="Username *" fullWidth size="small" value={form.userName} onChange={handleFormChange("userName")} sx={fieldSx} />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField label="Mobile No *" fullWidth size="small" value={form.registeredMobileNo} onChange={handleFormChange("registeredMobileNo")} sx={fieldSx} />
            </Grid>

            <Grid item xs={12} sm={6}>
              <TextField label="Password *" type="password" fullWidth size="small" value={form.password} onChange={handleFormChange("password")} sx={fieldSx} />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField label="MPIN *" type="password" fullWidth size="small" value={form.mpin} onChange={handleFormChange("mpin")} sx={fieldSx} />
            </Grid>

            <Grid item xs={12}>
              <TextField label="Company *" fullWidth size="small" value={form.company} onChange={handleFormChange("company")} sx={fieldSx} />
            </Grid>

            <Grid item xs={12} sm={6}>
              <TextField label="Email *" fullWidth size="small" value={form.emailId} onChange={handleFormChange("emailId")} sx={fieldSx} />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField label="GST State Code" fullWidth size="small" value={form.gstStateCode} onChange={handleFormChange("gstStateCode")} sx={fieldSx} />
            </Grid>

            <Grid item xs={12} sm={6}>
              <TextField label="Area *" fullWidth size="small" value={form.area} onChange={handleFormChange("area")} sx={fieldSx} />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField label="City *" fullWidth size="small" value={form.city} onChange={handleFormChange("city")} sx={fieldSx} />
            </Grid>

            <Grid item xs={12} sm={4}>
              <TextField label="Pincode *" fullWidth size="small" value={form.pincode} onChange={handleFormChange("pincode")} sx={fieldSx} />
            </Grid>
            <Grid item xs={12} sm={4}>
              <TextField label="Distributor ID" fullWidth size="small" type="number" value={form.distributorId} onChange={handleFormChange("distributorId")} sx={fieldSx} />
            </Grid>
            <Grid item xs={12} sm={4}>
              <TextField label="SuperDist ID" fullWidth size="small" type="number" value={form.superDistId} onChange={handleFormChange("superDistId")} sx={fieldSx} />
            </Grid>
          </Grid>
        </DialogContent>

        <DialogActions sx={{ px: 3, pb: 2.5, gap: 1 }}>
          <Button
            onClick={handleCloseModal}
            disabled={submitting}
            variant="outlined"
            sx={{ borderRadius: "10px", textTransform: "none", borderColor: COLORS.border, color: COLORS.secondary }}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={submitting}
            variant="contained"
            startIcon={submitting ? <CircularProgress size={16} color="inherit" /> : <AddRounded />}
            sx={{ bgcolor: COLORS.primary, borderRadius: "10px", textTransform: "none", fontWeight: 700, px: 3 }}
          >
            {submitting ? "Creating..." : "Create Retailer"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* SNACKBAR */}
      <Snackbar
        open={snack.open}
        autoHideDuration={4000}
        onClose={() => setSnack((s) => ({ ...s, open: false }))}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          severity={snack.severity}
          onClose={() => setSnack((s) => ({ ...s, open: false }))}
          sx={{ borderRadius: "12px", fontWeight: 600 }}
        >
          {snack.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}