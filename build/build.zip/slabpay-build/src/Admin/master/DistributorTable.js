import React, { useState, useEffect, useCallback } from "react";
import {
  Box, Typography, Grid, Paper, TextField, Select, MenuItem,
  FormControl, IconButton, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, Button, Stack, Avatar,
  Chip, InputAdornment, Dialog, DialogContent, DialogActions,
  Alert, CircularProgress, Snackbar, Divider, InputLabel,
  OutlinedInput, Skeleton
} from "@mui/material";
import {
  EditTwoTone, LockTwoTone, AddRounded, SearchRounded,
  FilterListRounded, PhoneIphoneRounded, BusinessRounded,
  LocationOnRounded, LockOpenTwoTone, CloseRounded,
  PersonAddAlt1Rounded, CheckCircleRounded, RefreshRounded,
  EmailRounded, AccountBalanceWalletRounded
} from "@mui/icons-material";

const COLORS = {
  bg: "#f8fafc",
  primary: "#1a56db",
  secondary: "#0f172a",
  accent: "#7c3aed",          // purple — differentiates Distributors from Super Distributors
  border: "#e2e8f0",
  textMuted: "#64748b",
  success: "#10b981",
  danger: "#ef4444"
};

const INITIAL_FORM = {
  userName: "", registeredMobileNo: "", password: "", company: "",
  area: "", city: "", pincode: "", gstStateCode: "", emailId: "",
  roleId: "3",   // Distributor role
  mpin: "",
};

// ── Add Distributor Modal ─────────────────────────────────────────────────────
function AddDistributorModal({ open, onClose, onSuccess }) {
  const [form, setForm]       = useState(INITIAL_FORM);
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState(null);
  const [response, setResponse] = useState(null);

  const handleChange = (e) => setForm((p) => ({ ...p, [e.target.name]: e.target.value }));

  const handleSubmit = async () => {
    setError(null); setResponse(null); setLoading(true);
    try {
      const token  = localStorage.getItem("token")  || "";
      const userId = localStorage.getItem("userId") || "1";

      const res = await fetch(
        `https://slabpay.azurewebsites.net/__api__/users/distributor?creatorId=${userId}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ ...form, roleId: Number(form.roleId) }),
        }
      );
      const data = await res.json();
      setResponse(data);
      if (data.success) onSuccess(data);
    } catch (err) {
      setError(err.message || "Network error – please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    if (loading) return;
    setForm(INITIAL_FORM); setError(null); setResponse(null); onClose();
  };

  const isSuccess = response?.success === true;

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth
      PaperProps={{ sx: { borderRadius: "20px", overflow: "hidden" } }}>

      {/* Header */}
      <Box sx={{
        background: `linear-gradient(135deg, ${COLORS.accent} 0%, #4c1d95 100%)`,
        px: 3, py: 2.5, display: "flex", alignItems: "center", justifyContent: "space-between"
      }}>
        <Stack direction="row" spacing={1.5} alignItems="center">
          <Box sx={{ bgcolor: "rgba(255,255,255,0.15)", borderRadius: "10px", p: 0.8, display: "flex" }}>
            <PersonAddAlt1Rounded sx={{ color: "#fff", fontSize: 22 }} />
          </Box>
          <Box>
            <Typography variant="h6" sx={{ color: "#fff", fontWeight: 700, lineHeight: 1.2 }}>
              Add Distributor
            </Typography>
            <Typography sx={{ color: "rgba(255,255,255,0.65)", fontSize: 12 }}>
              Fill in all details to create a new distributor account
            </Typography>
          </Box>
        </Stack>
        <IconButton onClick={handleClose}
          sx={{ color: "#fff", bgcolor: "rgba(255,255,255,0.1)", "&:hover": { bgcolor: "rgba(255,255,255,0.2)" } }}>
          <CloseRounded fontSize="small" />
        </IconButton>
      </Box>

      <DialogContent sx={{ px: 3, py: 3 }}>
        {/* Response banner */}
        {response && (
          <Alert
            severity={isSuccess ? "success" : "error"}
            icon={isSuccess ? <CheckCircleRounded /> : undefined}
            sx={{ mb: 2.5, borderRadius: "12px", fontWeight: 600 }}>
            {response.message || (isSuccess ? "Created successfully!" : "Something went wrong.")}
            {isSuccess && response.data?.id && (
              <Typography sx={{ fontSize: 12, mt: 0.5, opacity: 0.8 }}>
                User ID: {response.data.id} · Username: {response.data.userName}
              </Typography>
            )}
          </Alert>
        )}
        {error && (
          <Alert severity="error" sx={{ mb: 2.5, borderRadius: "12px" }}>{error}</Alert>
        )}

        {!isSuccess && (
          <Grid container spacing={2}>
            {/* Account */}
            <Grid item xs={12}>
              <Typography sx={{ fontSize: 11, fontWeight: 700, color: COLORS.textMuted, textTransform: "uppercase", letterSpacing: 1 }}>
                Account Details
              </Typography>
              <Divider sx={{ mt: 0.5 }} />
            </Grid>

            {[
              ["userName",            "Username *",   "text"],
              ["registeredMobileNo",  "Mobile No *",  "text"],
              ["password",            "Password *",   "password"],
              ["mpin",                "MPIN *",       "text"],
            ].map(([name, label, type]) => (
              <Grid item xs={12} sm={6} key={name}>
                <TextField fullWidth size="small" label={label} name={name}
                  type={type} value={form[name]} onChange={handleChange}
                  InputProps={{ sx: { borderRadius: "10px" } }} />
              </Grid>
            ))}

            <Grid item xs={12}>
              <TextField fullWidth size="small" label="Email ID" name="emailId"
                value={form.emailId} onChange={handleChange}
                InputProps={{ sx: { borderRadius: "10px" } }} />
            </Grid>

            {/* Business */}
            <Grid item xs={12} sx={{ mt: 0.5 }}>
              <Typography sx={{ fontSize: 11, fontWeight: 700, color: COLORS.textMuted, textTransform: "uppercase", letterSpacing: 1 }}>
                Business Info
              </Typography>
              <Divider sx={{ mt: 0.5 }} />
            </Grid>

            <Grid item xs={12}>
              <TextField fullWidth size="small" label="Company *" name="company"
                value={form.company} onChange={handleChange}
                InputProps={{ sx: { borderRadius: "10px" } }} />
            </Grid>

            {[
              ["area",         "Area *"],
              ["city",         "City *"],
              ["pincode",      "Pincode"],
              ["gstStateCode", "GST State Code"],
            ].map(([name, label]) => (
              <Grid item xs={12} sm={6} key={name}>
                <TextField fullWidth size="small" label={label} name={name}
                  value={form[name]} onChange={handleChange}
                  InputProps={{ sx: { borderRadius: "10px" } }} />
              </Grid>
            ))}

            <Grid item xs={12} sm={6}>
              <FormControl fullWidth size="small">
                <InputLabel>Role ID</InputLabel>
                <Select name="roleId" value={form.roleId} onChange={handleChange}
                  input={<OutlinedInput label="Role ID" sx={{ borderRadius: "10px" }} />}>
                  <MenuItem value="3">3 – Distributor</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          </Grid>
        )}
      </DialogContent>

      <DialogActions sx={{ px: 3, pb: 3, pt: 0, gap: 1 }}>
        <Button onClick={handleClose} variant="outlined"
          sx={{ borderRadius: "10px", textTransform: "none", borderColor: COLORS.border, color: COLORS.secondary, px: 3 }}>
          {isSuccess ? "Close" : "Cancel"}
        </Button>
        {!isSuccess && (
          <Button onClick={handleSubmit} variant="contained" disabled={loading}
            startIcon={loading ? <CircularProgress size={16} color="inherit" /> : <AddRounded />}
            sx={{
              borderRadius: "10px", textTransform: "none", px: 4, fontWeight: 700,
              background: `linear-gradient(135deg, ${COLORS.accent} 0%, #4c1d95 100%)`,
              boxShadow: `0 4px 14px ${COLORS.accent}40`,
              "&:hover": { boxShadow: `0 6px 20px ${COLORS.accent}55` }
            }}>
            {loading ? "Creating..." : "Create Distributor"}
          </Button>
        )}
      </DialogActions>
    </Dialog>
  );
}

// ── Skeleton Row ──────────────────────────────────────────────────────────────
function SkeletonRow() {
  return (
    <TableRow>
      {[180, 160, 110, 90, 90, 80].map((w, i) => (
        <TableCell key={i} align={i > 3 ? "center" : "left"}>
          <Skeleton variant="rounded" width={w} height={18} sx={{ borderRadius: "6px" }} />
        </TableCell>
      ))}
    </TableRow>
  );
}

// ── Main Table ────────────────────────────────────────────────────────────────
export default function DistributorTable() {
  const [rows, setRows]             = useState([]);
  const [loading, setLoading]       = useState(true);
  const [fetchError, setFetchError] = useState(null);
  const [search, setSearch]         = useState("");
  const [records, setRecords]       = useState(10);
  const [modalOpen, setModalOpen]   = useState(false);
  const [snackbar, setSnackbar]     = useState({ open: false, message: "" });

  // ── Fetch all distributors (type=D) ────────────────────────────────────────
  const fetchDistributors = useCallback(async () => {
    setLoading(true); setFetchError(null);
    try {
      const token = localStorage.getItem("token") || "";
      const res = await fetch("https://slabpay.azurewebsites.net/api/v1/users/type/D", {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      const data = await res.json();
      if (data.success) setRows(data.data || []);
      else setFetchError(data.message || "Failed to load distributors.");
    } catch (err) {
      setFetchError(err.message || "Network error.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchDistributors(); }, [fetchDistributors]);

  // ── Filter + paginate ───────────────────────────────────────────────────────
  const filtered = rows
    .filter((row) => {
      const t = search.toLowerCase();
      return (
        row.userName?.toLowerCase().includes(t) ||
        row.company?.toLowerCase().includes(t) ||
        row.emailId?.toLowerCase().includes(t) ||
        row.registeredMobileNo?.includes(t) ||
        String(row.id).includes(t)
      );
    })
    .slice(0, records);

  const handleSuccess = (data) => {
    setSnackbar({ open: true, message: data.message || "Distributor created successfully!" });
    fetchDistributors();   // refresh table
  };

  const memberNo = (row) => `D-SLABPAY-${row.id}`;

  return (
    <Box sx={{ bgcolor: COLORS.bg, minHeight: "100vh" }}>

      {/* HEADER */}
      <Stack
        direction={{ xs: "column", sm: "row" }}
        justifyContent="space-between"
        alignItems={{ sm: "center" }}
        sx={{ mb: 4 }} spacing={2}>
        <Box>
          <Typography variant="h5" sx={{ fontWeight: 700, color: COLORS.secondary }}>Distributors</Typography>
          <Typography sx={{ fontSize: 13, color: COLORS.textMuted, mt: 0.3 }}>
            {loading ? "Loading..." : `${rows.length} total records`}
          </Typography>
        </Box>
        <Stack direction="row" spacing={1.5}>
          <IconButton onClick={fetchDistributors} disabled={loading}
            sx={{ border: `1px solid ${COLORS.border}`, borderRadius: "12px", color: COLORS.textMuted }}>
            <RefreshRounded fontSize="small" />
          </IconButton>
          <Button variant="contained" startIcon={<AddRounded />} onClick={() => setModalOpen(true)}
            sx={{
              background: `linear-gradient(135deg, ${COLORS.accent} 0%, #4c1d95 100%)`,
              borderRadius: "12px", textTransform: "none", px: 3, fontWeight: 700,
              boxShadow: `0 4px 14px ${COLORS.accent}40`,
              "&:hover": { boxShadow: `0 6px 20px ${COLORS.accent}55` }
            }}>
            Add Distributor
          </Button>
        </Stack>
      </Stack>

      {/* FETCH ERROR */}
      {fetchError && (
        <Alert severity="error" sx={{ mb: 3, borderRadius: "12px" }}
          action={<Button color="inherit" size="small" onClick={fetchDistributors}>Retry</Button>}>
          {fetchError}
        </Alert>
      )}

      {/* FILTER BAR */}
      <Paper elevation={0} sx={{ p: 2.5, mb: 3, borderRadius: "16px", border: `1px solid ${COLORS.border}` }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} md={4}>
            <TextField fullWidth size="small" placeholder="Search name, email, company, ID..."
              value={search} onChange={(e) => setSearch(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchRounded sx={{ color: COLORS.textMuted }} />
                  </InputAdornment>
                ),
                sx: { borderRadius: "10px", bgcolor: "#f1f5f9", "& fieldset": { border: "none" } }
              }} />
          </Grid>
          <Grid item xs={6} md={2}>
            <FormControl fullWidth size="small">
              <Select value={records} onChange={(e) => setRecords(e.target.value)}
                sx={{ borderRadius: "10px", bgcolor: "#f1f5f9", "& .MuiOutlinedInput-notchedOutline": { border: "none" } }}>
                {[5, 10, 20, 50].map((n) => (
                  <MenuItem key={n} value={n}>{n} Records</MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={6} md={2}>
            <Button fullWidth variant="outlined" startIcon={<FilterListRounded />}
              sx={{ borderRadius: "10px", textTransform: "none", borderColor: COLORS.border, color: COLORS.secondary, height: "40px" }}>
              Filters
            </Button>
          </Grid>
        </Grid>
      </Paper>

      {/* TABLE */}
      <TableContainer component={Paper} elevation={0}
        sx={{ borderRadius: "16px", border: `1px solid ${COLORS.border}`, overflow: "hidden" }}>
        <Table>
          <TableHead sx={{ bgcolor: "#f8fafc" }}>
            <TableRow>
              {["DISTRIBUTOR", "CONTACT INFO", "LOCATION", "STATUS", "BALANCE", "ACTIONS"].map((head, i) => (
                <TableCell key={head} align={i > 3 ? "center" : "left"}
                  sx={{ py: 2, fontWeight: 700, color: COLORS.textMuted, fontSize: 11 }}>
                  {head}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>

          <TableBody>
            {loading ? (
              Array.from({ length: 5 }).map((_, i) => <SkeletonRow key={i} />)
            ) : filtered.length > 0 ? (
              filtered.map((row) => (
                <TableRow key={row.id} hover>

                  {/* DISTRIBUTOR */}
                  <TableCell>
                    <Stack direction="row" spacing={2} alignItems="center">
                      <Avatar sx={{
                        bgcolor: `${COLORS.accent}15`, color: COLORS.accent,
                        fontWeight: 700, borderRadius: "10px"
                      }}>
                        {(row.userName || "?").charAt(0).toUpperCase()}
                      </Avatar>
                      <Box>
                        <Typography sx={{ fontWeight: 700, color: COLORS.secondary, fontSize: 14 }}>
                          {row.userName}
                        </Typography>
                        <Typography sx={{ fontSize: 12, color: COLORS.textMuted }}>
                          {memberNo(row)}
                        </Typography>
                      </Box>
                    </Stack>
                  </TableCell>

                  {/* CONTACT INFO */}
                  <TableCell>
                    <Stack spacing={0.4}>
                      <Stack direction="row" spacing={1} alignItems="center">
                        <BusinessRounded sx={{ fontSize: 15, color: COLORS.textMuted }} />
                        <Typography sx={{ fontSize: 13 }}>{row.company || "—"}</Typography>
                      </Stack>
                      <Stack direction="row" spacing={1} alignItems="center">
                        <PhoneIphoneRounded sx={{ fontSize: 15, color: COLORS.textMuted }} />
                        <Typography sx={{ fontSize: 13, color: COLORS.textMuted }}>
                          {row.registeredMobileNo}
                        </Typography>
                      </Stack>
                      <Stack direction="row" spacing={1} alignItems="center">
                        <EmailRounded sx={{ fontSize: 15, color: COLORS.textMuted }} />
                        <Typography sx={{ fontSize: 12, color: COLORS.textMuted }}>
                          {row.emailId || "—"}
                        </Typography>
                      </Stack>
                    </Stack>
                  </TableCell>

                  {/* LOCATION */}
                  <TableCell>
                    <Stack spacing={0.2}>
                      <Stack direction="row" spacing={0.5} alignItems="center">
                        <LocationOnRounded sx={{ fontSize: 16, color: COLORS.danger }} />
                        <Typography sx={{ fontSize: 13 }}>{row.area || "—"}</Typography>
                      </Stack>
                      <Typography sx={{ fontSize: 12, color: COLORS.textMuted, pl: 2.5 }}>
                        {[row.city, row.pincode].filter(Boolean).join(", ") || "—"}
                      </Typography>
                    </Stack>
                  </TableCell>

                  {/* STATUS */}
                  <TableCell>
                    <Stack spacing={0.8}>
                      <Chip
                        label={row.isLocked ? "Locked" : "Active"}
                        size="small"
                        sx={{
                          fontWeight: 700, width: "fit-content",
                          bgcolor: row.isLocked ? `${COLORS.danger}10` : `#10b98110`,
                          color: row.isLocked ? COLORS.danger : COLORS.success
                        }} />
                      <Chip
                        label={row.isKYC ? "KYC ✓" : "KYC Pending"}
                        size="small"
                        sx={{
                          fontWeight: 600, width: "fit-content", fontSize: 11,
                          bgcolor: row.isKYC ? `${COLORS.accent}15` : "#f1f5f9",
                          color: row.isKYC ? COLORS.accent : COLORS.textMuted
                        }} />
                    </Stack>
                  </TableCell>

                  {/* BALANCE */}
                  <TableCell align="center">
                    <Stack alignItems="center" spacing={0.2}>
                      <AccountBalanceWalletRounded sx={{ fontSize: 15, color: COLORS.textMuted }} />
                      <Typography sx={{ fontWeight: 800, fontSize: 14 }}>
                        ₹ {Number(row.balance ?? 0).toLocaleString("en-IN", { minimumFractionDigits: 2 })}
                      </Typography>
                    </Stack>
                  </TableCell>

                  {/* ACTIONS */}
                  <TableCell align="center">
                    <Stack direction="row" spacing={1} justifyContent="center">
                      <IconButton size="small"
                        sx={{ color: COLORS.primary, bgcolor: `${COLORS.primary}10` }}>
                        <EditTwoTone fontSize="small" />
                      </IconButton>
                      <IconButton size="small"
                        sx={{
                          color: row.isLocked ? COLORS.success : COLORS.danger,
                          bgcolor: row.isLocked ? `${COLORS.success}10` : `${COLORS.danger}10`
                        }}>
                        {row.isLocked ? <LockOpenTwoTone fontSize="small" /> : <LockTwoTone fontSize="small" />}
                      </IconButton>
                    </Stack>
                  </TableCell>

                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={6} align="center" sx={{ py: 10 }}>
                  <Typography color="textSecondary">
                    {search
                      ? `No distributors found matching "${search}"`
                      : "No distributors found."}
                  </Typography>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      <Typography sx={{ mt: 2, textAlign: "center", fontSize: 12, color: COLORS.textMuted }}>
        Showing <b>{filtered.length}</b> of <b>{rows.length}</b> total records
      </Typography>

      {/* ADD MODAL */}
      <AddDistributorModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        onSuccess={handleSuccess}
      />

      {/* SUCCESS SNACKBAR */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={5000}
        onClose={() => setSnackbar({ open: false, message: "" })}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}>
        <Alert
          severity="success"
          icon={<CheckCircleRounded />}
          onClose={() => setSnackbar({ open: false, message: "" })}
          sx={{ borderRadius: "12px", fontWeight: 600, boxShadow: "0 8px 24px rgba(0,0,0,0.15)" }}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}