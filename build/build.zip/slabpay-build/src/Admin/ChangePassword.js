import { useState } from "react";
import { Box, Typography, TextField, Button, InputAdornment, Paper, Alert } from "@mui/material";
import LockIcon from "@mui/icons-material/Lock";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";

const A = "#dc2626";
const C = { border: "#e5eaf5", text1: "#0f1623", text2: "#3a4563", text3: "#7a8aab" };

const inputStyle = {
  "& .MuiOutlinedInput-root": {
    borderRadius: "10px",
    "& fieldset": { borderColor: C.border },
    "&:hover fieldset": { borderColor: A },
    "&.Mui-focused fieldset": { borderColor: A, borderWidth: 2 },
  },
  "& .MuiInputLabel-root.Mui-focused": { color: A },
};

export default function AdminChangePassword() {
  const [form, setForm] = useState({ current: "", newPw: "", confirm: "" });
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = () => {
    if (!form.current || !form.newPw || !form.confirm) {
      setError("All fields are required.");
      return;
    }
    if (form.newPw.length < 8) {
      setError("New password must be at least 8 characters.");
      return;
    }
    if (form.newPw !== form.confirm) {
      setError("New password and confirm password do not match.");
      return;
    }
    setError("");
    setSuccess(true);
    setForm({ current: "", newPw: "", confirm: "" });
    setTimeout(() => setSuccess(false), 4000);
  };

  return (
    <Box>
      <Box sx={{ mb: 3 }}>
        <Typography sx={{ fontSize: 22, fontWeight: 800, color: C.text1 }}>Change Password</Typography>
        <Typography sx={{ fontSize: 13, color: C.text3 }}>Update your admin account password</Typography>
      </Box>

      <Paper elevation={0} sx={{ maxWidth: 520, borderRadius: "16px", border: `1px solid ${C.border}`, p: 4 }}>
        <Box sx={{ width: 52, height: 52, borderRadius: "14px", background: "#fef2f2", display: "flex", alignItems: "center", justifyContent: "center", mb: 3 }}>
          <LockIcon sx={{ color: A, fontSize: 26 }} />
        </Box>

        <Typography sx={{ fontSize: 14, color: C.text2, lineHeight: 1.7, mb: 3 }}>
          Your password must be at least 8 characters and include a mix of uppercase, lowercase, numbers, and symbols.
        </Typography>

        {error && <Alert severity="error" sx={{ mb: 2, borderRadius: "10px" }}>{error}</Alert>}
        {success && (
          <Alert severity="success" icon={<CheckCircleIcon />} sx={{ mb: 2, borderRadius: "10px" }}>
            Password changed successfully!
          </Alert>
        )}

        <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
          {[
            { key: "current", label: "Current Password" },
            { key: "newPw", label: "New Password" },
            { key: "confirm", label: "Confirm New Password" },
          ].map(({ key, label }) => (
            <TextField
              key={key} label={label} type="password" fullWidth
              value={form[key]} onChange={e => setForm({ ...form, [key]: e.target.value })}
              sx={inputStyle}
              InputProps={{
                startAdornment: <InputAdornment position="start"><LockIcon sx={{ color: C.text3, fontSize: 18 }} /></InputAdornment>,
              }}
            />
          ))}
        </Box>

        <Box sx={{ mt: 3, display: "flex", gap: 2 }}>
          <Button variant="contained" onClick={handleSubmit}
            sx={{ background: A, borderRadius: "10px", textTransform: "none", fontWeight: 700, px: 4, height: 44, "&:hover": { background: "#b91c1c" } }}>
            Change Password
          </Button>
          <Button variant="outlined" onClick={() => { setForm({ current: "", newPw: "", confirm: "" }); setError(""); }}
            sx={{ borderRadius: "10px", textTransform: "none", borderColor: C.border, color: C.text2 }}>
            Clear
          </Button>
        </Box>
      </Paper>
    </Box>
  );
}
