import { useState, useRef, useEffect } from "react";
import { useNavigate, useLocation, Routes, Route } from "react-router-dom";
import {
  Box, Typography, Drawer, AppBar, Toolbar,
  IconButton, Badge, Tooltip, Paper, Divider, MenuItem, useMediaQuery, useTheme,
} from "@mui/material";
import {
  ExpandLess, ExpandMore,
  Dashboard, SupervisorAccount, Percent, AccountBalance,
  Assignment, Lock, Notifications, KeyboardArrowDown,
  ManageAccounts, Settings, Person, ExitToApp, Menu as MenuIcon, ChevronLeft,
} from "@mui/icons-material";
import { Avatar } from "@mui/material";

import AdminDashboard        from "./DashboardPage";
import EnquiryManagement     from "./EnquiryManagement";
import UserManagement        from "./UserManagement";
import RoleManagement        from "./RoleManagement";
import CommissionManagement  from "./CommissionManagement";
import BankManagement        from "./BankManagement";
import Pendingtopup          from "./Transaction/Pendingtopup";
import SuperDistributorTable from "./master/SuperDistributorTable";
import DistributorTable      from "./master/DistributorTable";
import RetailerTable         from "./master/RetailerTable";
import ManageBalance         from "./Transaction/ManageBalance";
import IServeUPayoutTransactions from "./Transaction/IservupayoutTransactions";
import AdminBalanceMaster    from "./master/AdminBalance";
import AllTopUpList          from "./Transaction/AllTopUpList";
import IMPSTransaction       from "./Transaction/IMPSTransaction";
import VerificationList      from "./Transaction/VerificationList";
import TransactionReport     from "./Report/TransactionReport";
import SettlementReport      from "./Report/SettlementReport";
import AdminCommissionReport from "./Report/CommissionReport";
import WalletReport          from "./Report/WalletReport";
import { RechargeUtility, BillPaymentUtility, PANService, BBPSUtility } from "./Utility/UtilityPages";
import AdminChangePassword   from "./ChangePassword";
import SystemSettings        from "./SystemSettings";
import ProfilePage           from "../components/ProfilePage";

const SIDEBAR_W = 258;
const SIDEBAR_COLLAPSED_W = 68;
const A = "#dc2626";

const navGroups = [
  {
    label: "MAIN",
    items: [
      { icon: <Dashboard fontSize="small" />,  label: "Dashboard",       path: "/admin/dashboard"  },
      { icon: <Assignment fontSize="small" />, label: "Enquiry Details", path: "/admin/enquiries"  },
    ],
  },
  {
    label: "TRANSACTION",
    items: [
      {
        icon: <ManageAccounts fontSize="small" />,
        label: "Master",
        children: [
          { label: "Super Distributor", path: "master/superdist-table" },
          { label: "Distributor",       path: "master/dist-table"      },
          { label: "Retailer",          path: "master/retailer-table"  },
          { label: "Admin Balance",     path: "master/admin-balance"   },
        ],
      },
      {
        icon: <SupervisorAccount fontSize="small" />,
        label: "Transaction",
        children: [
          { label: "Pending Top Up Request", path: "/admin/txn/pending-topup"  },
          { label: "Manage Balance",         path: "/admin/txn/manage-balance" },
          { label: "All Top Up List",        path: "/admin/txn/all-topup"      },
          { label: "IMPS Transaction",       path: "/admin/txn/imps"           },
          { label: "Verification List",      path: "/admin/txn/verification"   },
        ],
      },
      {
        icon: <Percent fontSize="small" />,
        label: "Report",
        children: [
          { label: "Transaction Report", path: "/admin/report/txn"       },
          { label: "Settlement Report",  path: "/admin/report/settlement" },
          { label: "Commission Report",  path: "/admin/report/commission" },
          { label: "Wallet Report",      path: "/admin/report/wallet"     },
        ],
      },
      {
        icon: <AccountBalance fontSize="small" />,
        label: "Utility",
        children: [
          { label: "Recharge",     path: "/admin/utility/recharge" },
          { label: "Bill Payment", path: "/admin/utility/bills"    },
          { label: "PAN Service",  path: "/admin/utility/pan"      },
          { label: "BBPS",         path: "/admin/utility/bbps"     },
        ],
      },
    ],
  },
  {
    label: "MANAGEMENT",
    items: [
      { icon: <ManageAccounts fontSize="small" />,    label: "User Management",  path: "/admin/users"       },
      { icon: <SupervisorAccount fontSize="small" />, label: "Role Management",  path: "/admin/roles"       },
      { icon: <Percent fontSize="small" />,           label: "Commission Mgmt",  path: "/admin/commissions" },
      { icon: <AccountBalance fontSize="small" />,    label: "Bank Management",  path: "/admin/banks"       },
    ],
  },
  {
    label: "SETTINGS",
    items: [
      { icon: <Lock fontSize="small" />,     label: "Change Password", path: "/admin/password" },
      { icon: <Settings fontSize="small" />, label: "System Settings", path: "/admin/settings" },
    ],
  },
];

function ProfileDropdown({ navigate }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const name  = localStorage.getItem("userName")  || sessionStorage.getItem("userName")  || "Admin";
  const email = localStorage.getItem("email")     || sessionStorage.getItem("email")     || "";
  const role  = localStorage.getItem("roleName")  || sessionStorage.getItem("roleName")  || "Admin";
  const initials = name.slice(0, 2).toUpperCase();

  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const handleLogout = () => { localStorage.clear(); sessionStorage.clear(); navigate("/admin/login"); };

  return (
    <Box ref={ref} sx={{ position: "relative" }}>
      <Box onClick={() => setOpen(o => !o)} sx={{ display: "flex", alignItems: "center", gap: 1, background: "#f8faff", border: "1px solid #e5eaf5", borderRadius: "10px", px: 1.5, py: 0.8, cursor: "pointer", "&:hover": { background: "#eef2fb" } }}>
        <Box sx={{ width: 28, height: 28, borderRadius: "8px", background: `linear-gradient(135deg, ${A}, #f87171)`, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 700, fontSize: 11 }}>{initials}</Box>
        <Box sx={{ display: { xs: "none", sm: "block" } }}>
          <Typography sx={{ fontSize: 12, fontWeight: 700, color: "#0f1623", lineHeight: 1.2 }}>{name}</Typography>
          <Typography sx={{ fontSize: 10, color: "#7a8aab" }}>{role}</Typography>
        </Box>
        <KeyboardArrowDown sx={{ color: "#b0bcd4", fontSize: 16, transition: "transform 0.2s", transform: open ? "rotate(180deg)" : "none", display: { xs: "none", sm: "block" } }} />
      </Box>
      {open && (
        <Paper elevation={4} sx={{ position: "absolute", right: 0, top: "calc(100% + 8px)", width: 220, borderRadius: "14px", zIndex: 9999, border: "1px solid #e5eaf5", overflow: "hidden" }}>
          <Box sx={{ px: 2, py: 2, background: "#f8faff" }}>
            <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
              <Avatar sx={{ width: 38, height: 38, background: `linear-gradient(135deg, ${A}, #f87171)`, fontSize: 14, fontWeight: 800 }}>{initials}</Avatar>
              <Box>
                <Typography sx={{ fontSize: 13, fontWeight: 700, color: "#0f1623" }}>{name}</Typography>
                <Typography sx={{ fontSize: 11, color: "#7a8aab", wordBreak: "break-all" }}>{email}</Typography>
              </Box>
            </Box>
          </Box>
          <Divider />
          <Box sx={{ py: 0.5 }}>
            <MenuItem onClick={() => { setOpen(false); navigate("/admin/profile"); }} sx={{ gap: 1.5, px: 2, py: 1.2, fontSize: 13, color: "#0f1623", "&:hover": { background: "#f8faff" } }}>
              <Person fontSize="small" sx={{ color: "#7a8aab" }} /> My Profile
            </MenuItem>
            <MenuItem onClick={() => { setOpen(false); navigate("/admin/settings"); }} sx={{ gap: 1.5, px: 2, py: 1.2, fontSize: 13, color: "#0f1623", "&:hover": { background: "#f8faff" } }}>
              <Settings fontSize="small" sx={{ color: "#7a8aab" }} /> Settings
            </MenuItem>
            <Divider />
            <MenuItem onClick={handleLogout} sx={{ gap: 1.5, px: 2, py: 1.2, fontSize: 13, color: A, fontWeight: 600, "&:hover": { background: "#fef2f2" } }}>
              <ExitToApp fontSize="small" /> Logout
            </MenuItem>
          </Box>
        </Paper>
      )}
    </Box>
  );
}

export default function AdminLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"));

  const [openMenus, setOpenMenus] = useState({});
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileOpen, setMobileOpen] = useState(false);

  // Auth guard – redirect to admin login if token missing
  useEffect(() => {
    if (!localStorage.getItem("token")) {
      navigate("/admin/login", { replace: true });
    }
  }, [navigate]);

  useEffect(() => { if (isMobile) setSidebarOpen(false); else setSidebarOpen(true); }, [isMobile]);
  useEffect(() => { setMobileOpen(false); }, [location.pathname]);

  const toggleMenu = (label) => setOpenMenus(prev => ({ ...prev, [label]: !prev[label] }));

  const allFlat = navGroups.flatMap(g =>
    g.items.flatMap(item => item.children
      ? item.children.map(c => ({ label: c.label, path: c.path }))
      : [{ label: item.label, path: item.path }]
    )
  );
  const currentLabel = allFlat.find(i => location.pathname.startsWith(i.path))?.label || "Admin Panel";
  const collapsed = !isMobile && !sidebarOpen;
  const drawerWidth = collapsed ? SIDEBAR_COLLAPSED_W : SIDEBAR_W;

  const SidebarContent = ({ inDrawer = false }) => (
    <>
      <Box sx={{ px: collapsed ? 1 : 2.5, py: 2.5, borderBottom: "1px solid #1e2a3a", display: "flex", alignItems: "center", justifyContent: collapsed ? "center" : "flex-start", gap: 1.5, minHeight: 64 }}>
        <Box sx={{ width: 36, height: 36, borderRadius: "10px", background: A, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 800, fontSize: 13, flexShrink: 0 }}>SP</Box>
        {!collapsed && (
          <Box>
            <Typography sx={{ color: "#fff", fontWeight: 800, fontSize: 16, lineHeight: 1.1 }}>SLAB<span style={{ color: A }}>PAY</span></Typography>
            <Typography sx={{ fontSize: 9, color: "#6b7280", letterSpacing: "0.5px" }}>ADMIN PORTAL</Typography>
          </Box>
        )}
      </Box>

      <Box sx={{ flex: 1, overflowY: "auto", p: collapsed ? 1 : 1.5, "&::-webkit-scrollbar": { width: 4 }, "&::-webkit-scrollbar-thumb": { background: "#1e2a3a", borderRadius: 2 } }}>
        {navGroups.map(group => (
          <Box key={group.label} sx={{ mb: 2 }}>
            {!collapsed && <Typography sx={{ fontSize: 10, color: "#374151", fontWeight: 700, letterSpacing: "1.2px", px: 1, py: 0.8 }}>{group.label}</Typography>}
            {collapsed && <Box sx={{ my: 0.5, mx: 1, height: "1px", background: "#1e2a3a" }} />}
            {group.items.map(item => {
              const hasChildren = !!item.children;
              const open = openMenus[item.label];
              if (hasChildren) {
                const anyActive = item.children.some(c => location.pathname.startsWith(c.path));
                return (
                  <Box key={item.label}>
                    <Tooltip title={collapsed ? item.label : ""} placement="right">
                      <Box onClick={() => { if (!collapsed) toggleMenu(item.label); else navigate(item.children[0].path); }} sx={{ display: "flex", alignItems: "center", gap: collapsed ? 0 : 1.5, p: 1, borderRadius: "8px", cursor: "pointer", justifyContent: collapsed ? "center" : "flex-start", color: anyActive ? "#f87171" : "#9ca3af", background: anyActive ? "#1e2a3a" : "transparent", "&:hover": { background: "#1e2a3a", color: "#f87171" }, transition: "all 0.15s" }}>
                        {item.icon}
                        {!collapsed && <Typography sx={{ flex: 1, fontSize: 13, fontWeight: 500 }}>{item.label}</Typography>}
                        {!collapsed && (open ? <ExpandLess sx={{ fontSize: 16 }} /> : <ExpandMore sx={{ fontSize: 16 }} />)}
                      </Box>
                    </Tooltip>
                    {open && !collapsed && (
                      <Box sx={{ pl: 3.5, mt: 0.5 }}>
                        {item.children.map(sub => {
                          const active = location.pathname.startsWith(sub.path);
                          return (
                            <Box key={sub.path} onClick={() => navigate(sub.path)} sx={{ py: 0.8, px: 1.5, cursor: "pointer", borderRadius: "8px", fontSize: 12, color: active ? "#f87171" : "#6b7280", background: active ? "#1e2a3a" : "transparent", "&:hover": { background: "#1e2a3a", color: "#f87171" }, transition: "all 0.15s", mb: 0.3, borderLeft: `2px solid ${active ? A : "#1e2a3a"}` }}>
                              {sub.label}
                            </Box>
                          );
                        })}
                      </Box>
                    )}
                  </Box>
                );
              }
              const active = location.pathname.startsWith(item.path);
              return (
                <Tooltip key={item.path} title={collapsed ? item.label : ""} placement="right">
                  <Box onClick={() => navigate(item.path)} sx={{ display: "flex", alignItems: "center", gap: collapsed ? 0 : 1.5, p: 1, borderRadius: "8px", cursor: "pointer", justifyContent: collapsed ? "center" : "flex-start", color: active ? "#f87171" : "#9ca3af", background: active ? "#1e2a3a" : "transparent", "&:hover": { background: "#1e2a3a", color: "#f87171" }, transition: "all 0.15s", mb: 0.3 }}>
                    {item.icon}
                    {!collapsed && <Typography sx={{ fontSize: 13, fontWeight: 500 }}>{item.label}</Typography>}
                  </Box>
                </Tooltip>
              );
            })}
          </Box>
        ))}
      </Box>

      {!collapsed && (
        <Box sx={{ p: 1.5, borderTop: "1px solid #1e2a3a" }}>
          <Box onClick={() => navigate("/admin/profile")} sx={{ display: "flex", alignItems: "center", gap: 1.5, background: "#1e2a3a", borderRadius: "10px", p: 1.5, cursor: "pointer", "&:hover": { background: "#263445" } }}>
            <Box sx={{ width: 34, height: 34, borderRadius: "9px", background: `linear-gradient(135deg, ${A}, #f87171)`, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 700, fontSize: 13, flexShrink: 0 }}>
              {(localStorage.getItem("userName") || sessionStorage.getItem("userName") || "A").slice(0, 2).toUpperCase()}
            </Box>
            <Box sx={{ flex: 1, minWidth: 0 }}>
              <Typography sx={{ fontSize: 13, fontWeight: 700, color: "#fff", lineHeight: 1.2 }}>{localStorage.getItem("userName") || sessionStorage.getItem("userName") || "Admin"}</Typography>
              <Typography sx={{ fontSize: 10, color: "#6b7280" }}>{localStorage.getItem("roleName") || sessionStorage.getItem("roleName") || "Admin"}</Typography>
            </Box>
            <KeyboardArrowDown sx={{ color: "#6b7280", fontSize: 16 }} />
          </Box>
        </Box>
      )}
    </>
  );

  return (
    <Box sx={{ display: "flex", height: "100vh", background: "#f8faff" }}>
      {!isMobile && (
        <Box sx={{ width: drawerWidth, flexShrink: 0, transition: "width 0.25s ease", background: "#0f1623", display: "flex", flexDirection: "column", overflow: "hidden", height: "100vh" }}>
          <SidebarContent />
        </Box>
      )}
      {isMobile && (
        <Drawer variant="temporary" open={mobileOpen} onClose={() => setMobileOpen(false)} ModalProps={{ keepMounted: true }} sx={{ "& .MuiDrawer-paper": { width: SIDEBAR_W, background: "#0f1623", display: "flex", flexDirection: "column", overflow: "hidden" } }}>
          <SidebarContent inDrawer />
        </Drawer>
      )}

      <Box sx={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", minWidth: 0 }}>
        <AppBar position="static" elevation={0} sx={{ background: "#fff", borderBottom: "1px solid #e5eaf5", color: "#0f1623", height: 64, flexShrink: 0 }}>
          <Toolbar sx={{ height: 64, px: { xs: 2, sm: 3 }, gap: 1.5 }}>
            <IconButton onClick={() => isMobile ? setMobileOpen(o => !o) : setSidebarOpen(o => !o)} sx={{ color: "#3a4563", background: "#f8faff", border: "1px solid #e5eaf5", borderRadius: "10px", width: 38, height: 38 }}>
              {(!isMobile && sidebarOpen) ? <ChevronLeft fontSize="small" /> : <MenuIcon fontSize="small" />}
            </IconButton>
            <Box sx={{ flex: 1 }}>
              <Typography sx={{ fontSize: { xs: 14, sm: 17 }, fontWeight: 700, color: "#0f1623" }}>{currentLabel}</Typography>
              <Typography sx={{ fontSize: 12, color: "#7a8aab", mt: 0.2, display: { xs: "none", sm: "block" } }}>SlabPay Admin Portal</Typography>
            </Box>
            <Tooltip title="Notifications">
              <IconButton sx={{ color: "#3a4563", background: "#f8faff", border: "1px solid #e5eaf5", borderRadius: "10px", width: 38, height: 38 }}>
                <Badge badgeContent={4} color="error" sx={{ "& .MuiBadge-badge": { fontSize: 9 } }}><Notifications fontSize="small" /></Badge>
              </IconButton>
            </Tooltip>
            <ProfileDropdown navigate={navigate} />
          </Toolbar>
        </AppBar>

        <Box sx={{ flex: 1, overflowY: "auto", p: { xs: 1.5, sm: 3 } }}>
          <Routes>
            <Route path="dashboard"              element={<AdminDashboard />} />
            <Route path="enquiries"              element={<EnquiryManagement />} />
            <Route path="users"                  element={<UserManagement />} />
            <Route path="roles"                  element={<RoleManagement />} />
            <Route path="commissions"            element={<CommissionManagement />} />
            <Route path="banks"                  element={<BankManagement />} />
            <Route path="master/superdist-table" element={<SuperDistributorTable />} />
            <Route path="master/dist-table"      element={<DistributorTable />} />
            <Route path="master/retailer-table"  element={<RetailerTable />} />
            <Route path="master/admin-balance"   element={<AdminBalanceMaster />} />
            <Route path="txn/pending-topup"      element={<Pendingtopup />} />
            <Route path="txn/manage-balance"     element={<ManageBalance />} />
            <Route path="txn/iservu-payout"      element={<IServeUPayoutTransactions />} />
            <Route path="txn/all-topup"          element={<AllTopUpList />} />
            <Route path="txn/imps"               element={<IMPSTransaction />} />
            <Route path="txn/verification"       element={<VerificationList />} />
            <Route path="report/txn"             element={<TransactionReport />} />
            <Route path="report/settlement"      element={<SettlementReport />} />
            <Route path="report/commission"      element={<AdminCommissionReport />} />
            <Route path="report/wallet"          element={<WalletReport />} />
            <Route path="utility/recharge"       element={<RechargeUtility />} />
            <Route path="utility/bills"          element={<BillPaymentUtility />} />
            <Route path="utility/pan"            element={<PANService />} />
            <Route path="utility/bbps"           element={<BBPSUtility />} />
            <Route path="password"               element={<AdminChangePassword />} />
            <Route path="settings"               element={<SystemSettings />} />
            <Route path="profile"                element={<ProfilePage accentColor={A} gradientFrom={A} gradientTo="#f87171" portalLabel="Admin Portal" />} />
            <Route path="*"                      element={<AdminDashboard />} />
          </Routes>
        </Box>
      </Box>
    </Box>
  );
}
