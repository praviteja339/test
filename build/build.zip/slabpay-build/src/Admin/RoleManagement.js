import { useState, useEffect, useCallback } from "react";
import {
  Box, Typography, Paper, Chip, Button, Dialog, DialogTitle, DialogContent,
  DialogActions, Grid, TextField, Checkbox, FormControlLabel, CircularProgress,
  Alert, Snackbar, IconButton, Tooltip, Divider,
} from "@mui/material";
import { Add, Edit, Refresh, Shield } from "@mui/icons-material";
import { getRoles, createRole, updatePermissions, getAllMenus } from "../services/adminApi";

const A = "#dc2626";
const C = { border:"#e5eaf5", text1:"#0f1623", text2:"#3a4563", text3:"#7a8aab" };
const PALETTE = ["#3b82f6","#8b5cf6","#f59e0b","#10b981","#ef4444","#06b6d4","#f97316"];

export default function RoleManagement() {
  const [roles,      setRoles]     = useState([]);
  const [menus,      setMenus]     = useState([]);
  const [loading,    setLoading]   = useState(true);
  const [toast,      setToast]     = useState({ open:false, msg:"", sev:"success" });
  const [editOpen,   setEditOpen]  = useState(false);
  const [addOpen,    setAddOpen]   = useState(false);
  const [current,    setCurrent]   = useState(null);
  const [selectedIds,setSelectedIds]=useState([]);
  const [newName,    setNewName]   = useState("");
  const [saving,     setSaving]    = useState(false);

  const showToast = (msg, sev="success") => setToast({ open:true, msg, sev });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [rRes, mRes] = await Promise.all([getRoles(), getAllMenus()]);
      setRoles(Array.isArray(rRes.data.data) ? rRes.data.data : []);
      setMenus(Array.isArray(mRes.data.data) ? mRes.data.data : []);
    } catch { showToast("Failed to load roles.", "error"); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const openEdit = (role) => {
    setCurrent(role);
    setSelectedIds((role.permissions||[]).map(p=>p.id));
    setEditOpen(true);
  };

  const handleSavePerms = async () => {
    setSaving(true);
    try {
      await updatePermissions(current.id, { menuIds: selectedIds, updatedBy: Number(localStorage.getItem("userId")||1) });
      showToast("Permissions updated."); setEditOpen(false); load();
    } catch { showToast("Failed to update permissions.", "error"); }
    finally { setSaving(false); }
  };

  const handleCreateRole = async () => {
    if (!newName.trim()) return;
    setSaving(true);
    try {
      await createRole({ name:newName.trim(), menuIds: selectedIds, createdBy: Number(localStorage.getItem("userId")||1) });
      showToast("Role created."); setAddOpen(false); setNewName(""); setSelectedIds([]); load();
    } catch { showToast("Failed to create role.", "error"); }
    finally { setSaving(false); }
  };

  const toggleMenu = (id) =>
    setSelectedIds(prev => prev.includes(id) ? prev.filter(x=>x!==id) : [...prev, id]);

  // Group menus by parentId for display
  const topMenus  = menus.filter(m=>!m.parentId);
  const childMenus= (parentId) => menus.filter(m=>m.parentId===parentId);

  const PermissionPicker = () => (
    <Box>
      {menus.length===0 ? (
        <Typography sx={{ color:C.text3,fontSize:13 }}>No menus found in the system.</Typography>
      ) : topMenus.length===0 ? (
        // flat list if no parents
        <Grid container spacing={1}>
          {menus.map(m=>(
            <Grid item xs={12} sm={6} key={m.id}>
              <FormControlLabel label={<Typography sx={{ fontSize:13 }}>{m.name}</Typography>}
                control={<Checkbox checked={selectedIds.includes(m.id)} onChange={()=>toggleMenu(m.id)}
                  sx={{ "&.Mui-checked":{ color:A },"&:hover":{ color:A } }}/>}/>
            </Grid>
          ))}
        </Grid>
      ) : topMenus.map(parent=>(
        <Box key={parent.id} sx={{ mb:2 }}>
          <FormControlLabel label={<Typography sx={{ fontSize:13,fontWeight:700,color:C.text1 }}>{parent.name}</Typography>}
            control={<Checkbox checked={selectedIds.includes(parent.id)} onChange={()=>toggleMenu(parent.id)}
              sx={{ "&.Mui-checked":{ color:A } }}/>}/>
          {childMenus(parent.id).length>0 && (
            <Box sx={{ ml:4 }}>
              <Grid container>
                {childMenus(parent.id).map(child=>(
                  <Grid item xs={12} sm={6} key={child.id}>
                    <FormControlLabel label={<Typography sx={{ fontSize:12,color:C.text2 }}>{child.name}</Typography>}
                      control={<Checkbox checked={selectedIds.includes(child.id)} onChange={()=>toggleMenu(child.id)} size="small"
                        sx={{ "&.Mui-checked":{ color:A } }}/>}/>
                  </Grid>
                ))}
              </Grid>
            </Box>
          )}
          <Divider sx={{ mt:1,borderColor:"#f0f0f0" }}/>
        </Box>
      ))}
    </Box>
  );

  return (
    <Box>
      <Box sx={{ mb:3,display:"flex",alignItems:"flex-start",justifyContent:"space-between",flexWrap:"wrap",gap:2 }}>
        <Box>
          <Typography sx={{ fontSize:22,fontWeight:800,color:C.text1 }}>Role Management</Typography>
          <Typography sx={{ fontSize:13,color:C.text3 }}>{roles.length} roles · assign menu permissions per role</Typography>
        </Box>
        <Box sx={{ display:"flex",gap:1 }}>
          <Tooltip title="Refresh"><IconButton onClick={load} sx={{ border:`1px solid ${C.border}`,borderRadius:"10px" }}><Refresh fontSize="small"/></IconButton></Tooltip>
          <Button startIcon={<Add/>} variant="contained" onClick={()=>{ setNewName(""); setSelectedIds([]); setAddOpen(true); }}
            sx={{ background:A,borderRadius:"10px",textTransform:"none",fontWeight:700,"&:hover":{background:"#b91c1c"} }}>
            New Role
          </Button>
        </Box>
      </Box>

      {loading ? (
        <Box sx={{ display:"flex",justifyContent:"center",mt:8 }}><CircularProgress sx={{ color:A }}/></Box>
      ) : (
        <Grid container spacing={2}>
          {roles.length===0 ? (
            <Grid item xs={12}>
              <Paper elevation={0} sx={{ p:6,textAlign:"center",borderRadius:"16px",border:`1px solid ${C.border}` }}>
                <Shield sx={{ fontSize:48,color:"#e5eaf5",mb:2 }}/>
                <Typography sx={{ color:C.text3 }}>No roles yet. Create the first role above.</Typography>
              </Paper>
            </Grid>
          ) : roles.map((r,i)=>(
            <Grid item xs={12} sm={6} md={4} key={r.id}>
              <Paper elevation={0} sx={{ p:2.5,borderRadius:"16px",border:`1px solid ${C.border}`,
                "&:hover":{ boxShadow:"0 4px 16px rgba(0,0,0,0.07)" },transition:"box-shadow 0.2s" }}>
                <Box sx={{ display:"flex",alignItems:"flex-start",justifyContent:"space-between",mb:1.5 }}>
                  <Box sx={{ display:"flex",alignItems:"center",gap:1.2 }}>
                    <Box sx={{ width:40,height:40,borderRadius:"10px",background:`${PALETTE[i%PALETTE.length]}18`,
                      display:"flex",alignItems:"center",justifyContent:"center",color:PALETTE[i%PALETTE.length] }}>
                      <Shield fontSize="small"/>
                    </Box>
                    <Box>
                      <Typography sx={{ fontSize:15,fontWeight:800,color:C.text1 }}>{r.name}</Typography>
                      <Typography sx={{ fontSize:11,color:C.text3 }}>
                        {r.createdDate ? new Date(r.createdDate).toLocaleDateString("en-IN") : "—"}
                      </Typography>
                    </Box>
                  </Box>
                  <Tooltip title="Edit Permissions">
                    <IconButton size="small" onClick={()=>openEdit(r)}>
                      <Edit fontSize="small" sx={{ color:C.text3 }}/>
                    </IconButton>
                  </Tooltip>
                </Box>
                <Divider sx={{ mb:1.5,borderColor:"#f0f0f0" }}/>
                <Typography sx={{ fontSize:11,fontWeight:700,color:C.text3,textTransform:"uppercase",letterSpacing:"0.05em",mb:1 }}>
                  Permissions ({(r.permissions||[]).length})
                </Typography>
                <Box sx={{ display:"flex",flexWrap:"wrap",gap:0.6 }}>
                  {(r.permissions||[]).length===0 ? (
                    <Typography sx={{ fontSize:12,color:C.text3,fontStyle:"italic" }}>No permissions assigned</Typography>
                  ) : (r.permissions||[]).slice(0,6).map(p=>(
                    <Chip key={p.id} label={p.name} size="small"
                      sx={{ fontSize:10,height:20,background:"#f3f4f6",color:C.text2,fontWeight:600 }}/>
                  ))}
                  {(r.permissions||[]).length>6 && (
                    <Chip label={`+${(r.permissions||[]).length-6} more`} size="small"
                      sx={{ fontSize:10,height:20,background:"#e8efff",color:"#1a56db",fontWeight:700 }}/>
                  )}
                </Box>
              </Paper>
            </Grid>
          ))}
        </Grid>
      )}

      {/* Edit Permissions Dialog */}
      <Dialog open={editOpen} onClose={()=>setEditOpen(false)} maxWidth="md" fullWidth PaperProps={{ sx:{ borderRadius:"16px" } }}>
        <DialogTitle sx={{ fontWeight:800,color:C.text1 }}>
          Edit Permissions — <span style={{ color:A }}>{current?.name}</span>
        </DialogTitle>
        <DialogContent dividers sx={{ maxHeight:440 }}>
          <PermissionPicker/>
        </DialogContent>
        <DialogActions sx={{ p:2.5,gap:1,justifyContent:"space-between" }}>
          <Typography sx={{ fontSize:12,color:C.text3 }}>{selectedIds.length} permission(s) selected</Typography>
          <Box sx={{ display:"flex",gap:1 }}>
            <Button onClick={()=>setEditOpen(false)} sx={{ textTransform:"none",borderRadius:"10px" }}>Cancel</Button>
            <Button onClick={handleSavePerms} variant="contained" disabled={saving}
              sx={{ background:A,borderRadius:"10px",textTransform:"none",fontWeight:700,"&:hover":{background:"#b91c1c"} }}>
              {saving ? <CircularProgress size={18} sx={{ color:"#fff" }}/> : "Save Permissions"}
            </Button>
          </Box>
        </DialogActions>
      </Dialog>

      {/* Add Role Dialog */}
      <Dialog open={addOpen} onClose={()=>setAddOpen(false)} maxWidth="md" fullWidth PaperProps={{ sx:{ borderRadius:"16px" } }}>
        <DialogTitle sx={{ fontWeight:800,color:C.text1 }}>Create New Role</DialogTitle>
        <DialogContent dividers>
          <TextField label="Role Name" value={newName} fullWidth size="small" sx={{ mb:3,"& .MuiOutlinedInput-root":{ borderRadius:"10px" } }}
            onChange={e=>setNewName(e.target.value)} placeholder="e.g. Senior Agent, Sub-Admin…"/>
          <Typography sx={{ fontSize:12,fontWeight:700,color:C.text3,textTransform:"uppercase",letterSpacing:"0.05em",mb:1.5 }}>
            Assign Permissions (optional)
          </Typography>
          <PermissionPicker/>
        </DialogContent>
        <DialogActions sx={{ p:2.5,gap:1,justifyContent:"space-between" }}>
          <Typography sx={{ fontSize:12,color:C.text3 }}>{selectedIds.length} permission(s) selected</Typography>
          <Box sx={{ display:"flex",gap:1 }}>
            <Button onClick={()=>setAddOpen(false)} sx={{ textTransform:"none",borderRadius:"10px" }}>Cancel</Button>
            <Button onClick={handleCreateRole} variant="contained" disabled={saving||!newName.trim()}
              sx={{ background:A,borderRadius:"10px",textTransform:"none",fontWeight:700,"&:hover":{background:"#b91c1c"} }}>
              {saving ? <CircularProgress size={18} sx={{ color:"#fff" }}/> : "Create Role"}
            </Button>
          </Box>
        </DialogActions>
      </Dialog>

      <Snackbar open={toast.open} autoHideDuration={3500} onClose={()=>setToast({...toast,open:false})} anchorOrigin={{ vertical:"bottom",horizontal:"right" }}>
        <Alert severity={toast.sev} sx={{ borderRadius:"10px" }}>{toast.msg}</Alert>
      </Snackbar>
    </Box>
  );
}
