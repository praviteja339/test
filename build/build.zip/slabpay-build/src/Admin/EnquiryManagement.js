import { useState } from "react";
import {
  Box, Typography, Paper, Chip, Avatar, Button, TextField, Dialog,
  DialogTitle, DialogContent, DialogActions, Select, MenuItem,
  FormControl, InputLabel, InputAdornment, Tabs, Tab, Grid, Divider,
} from "@mui/material";
import {
  Search, CheckCircle, Cancel, Visibility, FilterList,
  Person, Phone, Email, LocationOn, Assignment, CalendarToday,
} from "@mui/icons-material";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { TablePagination } from "@mui/material";
const A = "#dc2626";
const C = { bg: "#f8faff", card: "#ffffff", border: "#e5eaf5", text1: "#0f1623", text2: "#3a4563", text3: "#7a8aab" };

const ENQUIRIES = [
  { id: "ENQ001", name: "Ravi Kumar",      phone: "9876543210", email: "ravi@mail.com",   role: "Distributor",     city: "Hyderabad",  state: "Telangana",    date: "30 Mar 2026", status: "pending",  aadhar: "XXXX-XXXX-1234", pan: "ABCDE1234F", business: "RK Enterprises",    msg: "Looking to expand network in Hyderabad region." },
  { id: "ENQ002", name: "Sneha Reddy",     phone: "9123456780", email: "sneha@mail.com",  role: "Agent",           city: "Warangal",   state: "Telangana",    date: "29 Mar 2026", status: "approved", aadhar: "XXXX-XXXX-5678", pan: "FGHIJ5678K", business: "Sneha Services",     msg: "Interested in money transfer services." },
  { id: "ENQ003", name: "Manoj Patel",     phone: "9988776655", email: "manoj@mail.com",  role: "Super Dist.",     city: "Mumbai",     state: "Maharashtra", date: "29 Mar 2026", status: "rejected", aadhar: "XXXX-XXXX-9012", pan: "KLMNO9012P", business: "Patel Finance",      msg: "Want to become super distributor in Mumbai." },
  { id: "ENQ004", name: "Priya Sharma",    phone: "8877665544", email: "priya@mail.com",  role: "Agent",           city: "Pune",       state: "Maharashtra", date: "28 Mar 2026", status: "pending",  aadhar: "XXXX-XXXX-3456", pan: "QRSTU3456V", business: "Sharma Retail",      msg: "Retail shop owner, want to offer banking." },
  { id: "ENQ005", name: "Abdul Rahman",    phone: "7766554433", email: "abdul@mail.com",  role: "Distributor",     city: "Chennai",    state: "Tamil Nadu",   date: "28 Mar 2026", status: "approved", aadhar: "XXXX-XXXX-7890", pan: "VWXYZ7890A", business: "Rahman Distributors", msg: "Experienced in AEPS and money transfer." },
  { id: "ENQ006", name: "Kavita Nair",     phone: "6655443322", email: "kavita@mail.com", role: "Agent",           city: "Kochi",      state: "Kerala",       date: "27 Mar 2026", status: "pending",  aadhar: "XXXX-XXXX-2345", pan: "BCDEF2345G", business: "Nair Grocery",       msg: "Small grocery owner seeking to add services." },
  { id: "ENQ007", name: "Suresh Babu",     phone: "5544332211", email: "suresh@mail.com", role: "Distributor",     city: "Bangalore",  state: "Karnataka",  date: "27 Mar 2026", status: "pending",  aadhar: "XXXX-XXXX-6789", pan: "HIJKL6789M", business: "Suresh Networks",    msg: "IT background, want to expand fintech." },
  { id: "ENQ008", name: "Lakshmi Devi",    phone: "4433221100", email: "laksh@mail.com",  role: "Agent",           city: "Vizag",      state: "Andhra",      date: "26 Mar 2026", status: "rejected", aadhar: "XXXX-XXXX-0123", pan: "NOPQR0123S", business: "Lakshmi Stores",     msg: "Want to provide micro ATM services." },
];

const statusConfig = {
  pending:  { label: "Pending",  bg: "#fffbeb", color: "#d97706", dot: "#f59e0b" },
  approved: { label: "Approved", bg: "#ecfdf5", color: "#059669", dot: "#10b981" },
  rejected: { label: "Rejected", bg: "#fef2f2", color: "#dc2626", dot: "#ef4444" },
};

export default function EnquiryManagement() {
  const [enquiries, setEnquiries] = useState(ENQUIRIES);
  const [tab, setTab] = useState(0);
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("All");
  const [selected, setSelected] = useState(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [rejectOpen, setRejectOpen] = useState(false);
  const [rejectReason, setRejectReason] = useState("");
  const [rejectTarget, setRejectTarget] = useState(null);
const [page, setPage] = useState(0);
const [rowsPerPage, setRowsPerPage] = useState(5);
  const tabs = ["All", "Pending", "Approved", "Rejected"];
  const roles = ["All", "Super Dist.", "Distributor", "Agent"];


  const filtered = enquiries.filter(e => {
    const matchTab = tab === 0 || e.status === tabs[tab].toLowerCase();
    const matchSearch = e.name.toLowerCase().includes(search.toLowerCase()) ||
      e.id.toLowerCase().includes(search.toLowerCase()) ||
      e.email.toLowerCase().includes(search.toLowerCase());
    const matchRole = roleFilter === "All" || e.role === roleFilter;
    return matchTab && matchSearch && matchRole;
  });

  const counts = { all: enquiries.length, pending: enquiries.filter(e => e.status === "pending").length, approved: enquiries.filter(e => e.status === "approved").length, rejected: enquiries.filter(e => e.status === "rejected").length };

  const handleApprove = (id) => {
    setEnquiries(prev => prev.map(e => e.id === id ? { ...e, status: "approved" } : e));
    setDetailOpen(false);
  };

  const handleReject = () => {
    if (!rejectReason.trim()) return;
    setEnquiries(prev => prev.map(e => e.id === rejectTarget ? { ...e, status: "rejected", rejectReason } : e));
    setRejectOpen(false);
    setRejectReason("");
    setDetailOpen(false);
  };
const paginatedData = filtered.slice(
  page * rowsPerPage,
  page * rowsPerPage + rowsPerPage
);
  const openDetail = (e) => { setSelected(e); setDetailOpen(true); };
  const openReject = (id) => { setRejectTarget(id); setRejectOpen(true); };
const exportCSV = () => {
  const ws = XLSX.utils.json_to_sheet(filtered);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Enquiries");
  const buf = XLSX.write(wb, { bookType: "csv", type: "array" });
  saveAs(new Blob([buf]), "enquiries.csv");
};

const exportExcel = () => {
  const ws = XLSX.utils.json_to_sheet(filtered);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Enquiries");
  const buf = XLSX.write(wb, { bookType: "xlsx", type: "array" });
  saveAs(new Blob([buf]), "enquiries.xlsx");
};

const exportPDF = () => {
  const doc = new jsPDF();
  autoTable(doc, {
    head: [["ID", "Name", "Role", "City", "Date", "Status"]],
    body: filtered.map(e => [
      e.id,
      e.name,
      e.role,
      e.city,
      e.date,
      e.status,
    ]),
  });
  doc.save("enquiries.pdf");
};
  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 3, display: "flex", alignItems: "flex-start", justifyContent: "space-between", flexWrap: "wrap", gap: 2 }}>
        <Box>
          <Typography sx={{ fontSize: 22, fontWeight: 800, color: C.text1 }}>Enquiry Management</Typography>
          <Typography sx={{ fontSize: 13, color: C.text3, mt: 0.3 }}>Review, approve or reject membership enquiries</Typography>
        </Box>
        <Box sx={{ display: "flex", gap: 1.5 }}>
          {[{ label: "Pending", count: counts.pending, color: "#d97706", bg: "#fffbeb" }, { label: "Approved", count: counts.approved, color: "#059669", bg: "#ecfdf5" }, { label: "Rejected", count: counts.rejected, color: A, bg: "#fef2f2" }].map(s => (
            <Paper key={s.label} elevation={0} sx={{ px: 2, py: 1, borderRadius: "10px", border: `1px solid ${C.border}`, background: s.bg, textAlign: "center" }}>
              <Typography sx={{ fontSize: 20, fontWeight: 800, color: s.color }}>{s.count}</Typography>
              <Typography sx={{ fontSize: 11, color: s.color, fontWeight: 600 }}>{s.label}</Typography>
            </Paper>
          ))}
        </Box>
      </Box>

      {/* Tabs + Filters */}
      <Paper elevation={0} sx={{ borderRadius: "16px", border: `1px solid ${C.border}`, background: C.card, overflow: "hidden", mb: 0 }}>
        <Box sx={{ px: 3, pt: 2, borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 2 }}>
          <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ "& .MuiTab-root": { fontSize: 13, fontWeight: 600, minWidth: 90, textTransform: "none", color: C.text3 }, "& .Mui-selected": { color: A, fontWeight: 700 }, "& .MuiTabs-indicator": { background: A } }}>
            {tabs.map((t, i) => <Tab key={t} label={`${t} ${i === 0 ? `(${counts.all})` : i === 1 ? `(${counts.pending})` : i === 2 ? `(${counts.approved})` : `(${counts.rejected})`}`} />)}
          </Tabs>
       <Box sx={{ display: "flex", gap: 1.5, pb: 1, alignItems: "center" }}>

  {/* 🔍 SEARCH */}
  <TextField
    size="small"
    placeholder="Search name, ID, email…"
    value={search}
    onChange={e => setSearch(e.target.value)}
    InputProps={{
      startAdornment: (
        <InputAdornment position="start">
          <Search sx={{ fontSize: 16, color: C.text3 }} />
        </InputAdornment>
      )
    }}
    sx={{
      width: 220,
      "& .MuiOutlinedInput-root": {
        borderRadius: "10px",
        fontSize: 13,
        background: C.bg,
        "& fieldset": { borderColor: C.border }
      }
    }}
  />

  {/* 🎯 ROLE FILTER */}
  <FormControl size="small" sx={{ minWidth: 140 }}>
    <Select
      value={roleFilter}
      onChange={e => setRoleFilter(e.target.value)}
      displayEmpty
      sx={{
        borderRadius: "10px",
        fontSize: 13,
        background: C.bg,
        "& fieldset": { borderColor: C.border }
      }}
    >
      {roles.map(r => (
        <MenuItem key={r} value={r} sx={{ fontSize: 13 }}>
          {r === "All" ? "All Roles" : r}
        </MenuItem>
      ))}
    </Select>
  </FormControl>

  {/* 📥 EXPORT DROPDOWN */}
  <FormControl size="small" sx={{ minWidth: 120 }}>
    <Select
      displayEmpty
      defaultValue=""
      renderValue={() => "Export"}
      sx={{
        borderRadius: "10px",
        fontSize: 13,
        background: "#eef2ff",
        fontWeight: 600,
        "& fieldset": { borderColor: "#c7d2fe" }
      }}
    >
      <MenuItem onClick={exportCSV}>Export CSV</MenuItem>
      <MenuItem onClick={exportExcel}>Export Excel</MenuItem>
      <MenuItem onClick={exportPDF}>Export PDF</MenuItem>
    </Select>
  </FormControl>

</Box>
        </Box>

        {/* Table Header */}
        <Box sx={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr 1fr 1fr auto", px: 3, py: 1.5, background: "#f8faff", borderBottom: `1px solid ${C.border}` }}>
          {["Applicant", "Role", "City / State",  "Date", "Status", "Actions"].map(h => (
            <Typography key={h} sx={{ fontSize: 11, fontWeight: 700, color: C.text3, letterSpacing: "0.5px", textTransform: "uppercase" }}>{h}</Typography>
          ))}
        </Box>

        {/* Rows */}
        {filtered.length === 0 ? (
          <Box sx={{ py: 8, textAlign: "center" }}>
            <Typography sx={{ fontSize: 15, color: C.text3 }}>No enquiries found</Typography>
          </Box>
        ) : paginatedData.map((e, i) => {
          const sc = statusConfig[e.status];
          return (
            <Box key={e.id} sx={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr 1fr 1fr auto", px: 3, py: 2, borderBottom: i < filtered.length - 1 ? `1px solid ${C.border}` : "none", alignItems: "center", gap: 1, "&:hover": { background: "#fafbff" }, transition: "background 0.15s" }}>
              <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                <Avatar sx={{ width: 34, height: 34, fontSize: 13, fontWeight: 700, background: "linear-gradient(135deg,#1a56db,#3b7af7)", flexShrink: 0 }}>{e.name[0]}</Avatar>
                <Box>
                  <Typography sx={{ fontSize: 13, fontWeight: 700, color: C.text1 }}>{e.name}</Typography>
                  <Typography sx={{ fontSize: 11, color: C.text3 }}>{e.id}</Typography>
                </Box>
              </Box>
              <Chip label={e.role} size="small" sx={{ height: 22, fontSize: 11, fontWeight: 600, background: "#e8efff", color: "#1a56db", width: "fit-content" }} />
              <Box>
                <Typography sx={{ fontSize: 13, color: C.text2 }}>{e.city}</Typography>
                <Typography sx={{ fontSize: 11, color: C.text3 }}>{e.state}</Typography>
              </Box>
              <Typography sx={{ fontSize: 12, color: C.text3 }}>{e.date}</Typography>
              <Box>
                <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                  <Box sx={{ width: 7, height: 7, borderRadius: "50%", background: sc.dot }} />
                  <Typography sx={{ fontSize: 12, fontWeight: 700, color: sc.color }}>{sc.label}</Typography>
                </Box>
                {e.rejectReason && <Typography sx={{ fontSize: 10, color: C.text3, mt: 0.3, maxWidth: 100, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }} title={e.rejectReason}>↳ {e.rejectReason}</Typography>}
              </Box>
              <Box sx={{ display: "flex", gap: 0.8 }}>
             
                {e.status === "pending" && (
    <>
      <Button
        size="small"
        variant="contained"
        onClick={() => handleApprove(e.id)}
        sx={{
          minWidth: 0,
          px: 1.2,
          py: 0.5,
          borderRadius: "8px",
          background: "#059669",
          "&:hover": { background: "#047857" }
        }}
      >
        <CheckCircle sx={{ fontSize: 16 }} />
      </Button>

      <Button
        size="small"
        variant="contained"
        onClick={() => openReject(e.id)}
        sx={{
          minWidth: 0,
          px: 1.2,
          py: 0.5,
          borderRadius: "8px",
          background: "#dc2626",
          "&:hover": { background: "#b91c1c" }
        }}
      >
        <Cancel sx={{ fontSize: 16 }} />
      </Button>
    </>
  )}

  {/* ✅ APPROVED → Green Tick Only */}
  {e.status === "approved" && (
    <Box
      sx={{
        width: 34,
        height: 34,
        borderRadius: "10px",
        background: "#ecfdf5",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: "#059669",
      }}
    >
      <CheckCircle sx={{ fontSize: 20 }} />
    </Box>
  )}

  {/* ❌ REJECTED → Red Cross Only */}
  {e.status === "rejected" && (
    <Box
      sx={{
        width: 34,
        height: 34,
        borderRadius: "10px",
        background: "#fef2f2",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: "#dc2626",
      }}
    >
      <Cancel sx={{ fontSize: 20 }} />
    </Box>
  )}

              </Box>
            </Box>
          );
        })}
      </Paper>

      {/* Detail Dialog */}
      <Dialog open={detailOpen} onClose={() => setDetailOpen(false)} maxWidth="sm" fullWidth PaperProps={{ sx: { borderRadius: "20px" } }}>
        {selected && <>
          <DialogTitle sx={{ pb: 0, pt: 3, px: 3 }}>
            <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
              <Avatar sx={{ width: 48, height: 48, background: "linear-gradient(135deg,#1a56db,#3b7af7)", fontSize: 18, fontWeight: 800 }}>{selected.name[0]}</Avatar>
              <Box>
                <Typography sx={{ fontSize: 18, fontWeight: 800, color: C.text1 }}>{selected.name}</Typography>
                <Box sx={{ display: "flex", gap: 1, mt: 0.3 }}>
                  <Chip label={selected.role} size="small" sx={{ height: 20, fontSize: 11, fontWeight: 600, background: "#e8efff", color: "#1a56db" }} />
                  <Chip label={statusConfig[selected.status].label} size="small" sx={{ height: 20, fontSize: 11, fontWeight: 600, background: statusConfig[selected.status].bg, color: statusConfig[selected.status].color }} />
                </Box>
              </Box>
            </Box>
          </DialogTitle>
          <DialogContent sx={{ px: 3, pt: 2.5 }}>
            <Grid container spacing={2}>
              {[
                { icon: <Assignment sx={{ fontSize: 15 }} />,    label: "Enquiry ID",  value: selected.id },
                { icon: <CalendarToday sx={{ fontSize: 15 }} />, label: "Date",        value: selected.date },
                { icon: <Phone sx={{ fontSize: 15 }} />,         label: "Phone",       value: selected.phone },
                { icon: <Email sx={{ fontSize: 15 }} />,         label: "Email",       value: selected.email },
                { icon: <LocationOn sx={{ fontSize: 15 }} />,    label: "Location",    value: `${selected.city}, ${selected.state}` },
                { icon: <Person sx={{ fontSize: 15 }} />,        label: "Business",    value: selected.business },
              ].map(f => (
                <Grid item xs={6} key={f.label}>
                  <Box sx={{ display: "flex", gap: 1, alignItems: "flex-start" }}>
                    <Box sx={{ color: C.text3, mt: 0.2, flexShrink: 0 }}>{f.icon}</Box>
                    <Box>
                      <Typography sx={{ fontSize: 11, color: C.text3, fontWeight: 600 }}>{f.label}</Typography>
                      <Typography sx={{ fontSize: 13, color: C.text1, fontWeight: 600 }}>{f.value}</Typography>
                    </Box>
                  </Box>
                </Grid>
              ))}
            </Grid>
            <Divider sx={{ my: 2 }} />
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <Typography sx={{ fontSize: 11, color: C.text3, fontWeight: 600 }}>Aadhar</Typography>
                <Typography sx={{ fontSize: 13, color: C.text1, fontWeight: 600 }}>{selected.aadhar}</Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography sx={{ fontSize: 11, color: C.text3, fontWeight: 600 }}>PAN</Typography>
                <Typography sx={{ fontSize: 13, color: C.text1, fontWeight: 600 }}>{selected.pan}</Typography>
              </Grid>
              <Grid item xs={12}>
                <Typography sx={{ fontSize: 16, color: C.text1, fontWeight: 800 }}>₹{selected.amount.toLocaleString()}</Typography>
              </Grid>
            </Grid>
            <Divider sx={{ my: 2 }} />
            <Typography sx={{ fontSize: 11, color: C.text3, fontWeight: 600, mb: 0.5 }}>Message / Note</Typography>
            <Box sx={{ p: 2, borderRadius: "10px", background: C.bg, border: `1px solid ${C.border}` }}>
              <Typography sx={{ fontSize: 13, color: C.text2, lineHeight: 1.6 }}>{selected.msg}</Typography>
            </Box>
            {selected.rejectReason && (
              <Box sx={{ mt: 2, p: 2, borderRadius: "10px", background: "#fef2f2", border: "1px solid #fecaca" }}>
                <Typography sx={{ fontSize: 11, fontWeight: 700, color: A, mb: 0.5 }}>Rejection Reason</Typography>
                <Typography sx={{ fontSize: 13, color: "#7f1d1d" }}>{selected.rejectReason}</Typography>
              </Box>
            )}
          </DialogContent>
          <DialogActions sx={{ px: 3, pb: 3, gap: 1 }}>
            <Button onClick={() => setDetailOpen(false)} variant="outlined" sx={{ borderRadius: "10px", borderColor: C.border, color: C.text2, textTransform: "none", fontWeight: 600 }}>Close</Button>
            {selected.status === "pending" && <>
              <Button onClick={() => openReject(selected.id)} variant="contained" sx={{ borderRadius: "10px", background: A, textTransform: "none", fontWeight: 700, "&:hover": { background: "#b91c1c" } }}>Reject with Reason</Button>
              <Button onClick={() => handleApprove(selected.id)} variant="contained" sx={{ borderRadius: "10px", background: "#059669", textTransform: "none", fontWeight: 700, "&:hover": { background: "#047857" } }}>Approve Enquiry</Button>
            </>}
          </DialogActions>
        </>}
      </Dialog>

      {/* Reject Reason Dialog */}
      <Dialog open={rejectOpen} onClose={() => setRejectOpen(false)} maxWidth="xs" fullWidth PaperProps={{ sx: { borderRadius: "20px" } }}>
        <DialogTitle sx={{ fontWeight: 800, color: C.text1, pt: 3 }}>Reject Enquiry</DialogTitle>
        <DialogContent>
          <Typography sx={{ fontSize: 13, color: C.text3, mb: 2 }}>Please provide a clear reason for rejection. This will be visible to the applicant.</Typography>
          <TextField
            fullWidth multiline rows={4} label="Rejection Reason" placeholder="e.g. Incomplete KYC documents, duplicate application…"
            value={rejectReason} onChange={e => setRejectReason(e.target.value)}
            sx={{ "& .MuiOutlinedInput-root": { borderRadius: "12px", fontSize: 13, "& fieldset": { borderColor: C.border } } }}
          />
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 3, gap: 1 }}>
          <Button onClick={() => { setRejectOpen(false); setRejectReason(""); }} variant="outlined" sx={{ borderRadius: "10px", borderColor: C.border, color: C.text2, textTransform: "none", fontWeight: 600 }}>Cancel</Button>
          <Button onClick={handleReject} variant="contained" disabled={!rejectReason.trim()} sx={{ borderRadius: "10px", background: A, textTransform: "none", fontWeight: 700, "&:hover": { background: "#b91c1c" } }}>Confirm Rejection</Button>
        </DialogActions>
      </Dialog>
      <TablePagination
  component="div"
  count={filtered.length}
  page={page}
  onPageChange={(e, newPage) => setPage(newPage)}
  rowsPerPage={rowsPerPage}
  onRowsPerPageChange={(e) => {
    setRowsPerPage(parseInt(e.target.value, 10));
    setPage(0);
  }}
/>
    </Box>
  );
}
