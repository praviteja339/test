import { useState, useEffect, useCallback } from "react";
import {
  Box, Typography, Paper, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Chip, TextField, MenuItem, Button,
  InputAdornment, Grid, CircularProgress, Alert, Snackbar,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import DownloadIcon from "@mui/icons-material/Download";
import RefreshIcon from "@mui/icons-material/Refresh";
import AccountBalanceIcon from "@mui/icons-material/AccountBalance";
import { getAllTopUps } from "../../services/adminApi";

const C = { border: "#e5eaf5", text1: "#0f1623", text2: "#3a4563", text3: "#7a8aab" };
const A = "#dc2626";
const fmt  = (n) => n == null ? "₹0.00" : "₹" + Number(n).toLocaleString("en-IN", { minimumFractionDigits: 2 });
const today = () => new Date().toISOString().split("T")[0];
const monthStart = () => { const d = new Date(); d.setDate(1); return d.toISOString().split("T")[0]; };

const statusConfig = {
  APPROVED: { color: "#059669", bg: "#ecfdf5", label: "Settled"  },
  PENDING:  { color: "#d97706", bg: "#fffbeb", label: "Pending"  },
  REJECTED: { color: "#dc2626", bg: "#fef2f2", label: "Rejected" },
};

const downloadCSV = (rows) => {
  const cols = ["ID","Requester","Payment Mode","UTR","Amount","Status","Date"];
  const lines = [cols.join(","), ...rows.map(r =>
    [r.id, r.requesterUsername||"—", r.paymentMode||"—", r.utrNumber||"—", r.amount||0, r.status, r.requestDate||"—"].join(","))];
  const blob = new Blob([lines.join("\n")], { type: "text/csv" });
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "settlement_report.csv"; a.click();
};

export default function SettlementReport() {
  const [data,         setData]         = useState([]);
  const [loading,      setLoading]      = useState(true);
  const [toast,        setToast]        = useState({ open: false, msg: "", sev: "success" });
  const [search,       setSearch]       = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [fromDate,     setFromDate]     = useState(monthStart());
  const [toDate,       setToDate]       = useState(today());

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getAllTopUps();
      let rows = Array.isArray(res.data?.data) ? res.data.data : [];
      // Filter by date range client-side (topup endpoint doesn't support date-range yet)
      rows = rows.filter(r => {
        if (!r.requestDate) return true;
        const d = r.requestDate.split("T")[0];
        return d >= fromDate && d <= toDate;
      });
      setData(rows);
    } catch {
      setToast({ open: true, msg: "Failed to load settlement data.", sev: "error" });
    } finally { setLoading(false); }
  }, [fromDate, toDate]);

  useEffect(() => { load(); }, [load]);

  const filtered = data.filter(r => {
    const q = search.toLowerCase();
    return (
      (!search || (r.requesterUsername||"").toLowerCase().includes(q) || (r.utrNumber||"").includes(search)) &&
      (statusFilter === "All" || r.status === statusFilter)
    );
  });

  const totalSettled  = filtered.filter(r=>r.status==="APPROVED").reduce((s,r)=>s+Number(r.amount||0),0);
  const totalPending  = filtered.filter(r=>r.status==="PENDING").reduce((s,r)=>s+Number(r.amount||0),0);
  const totalRejected = filtered.filter(r=>r.status==="REJECTED").reduce((s,r)=>s+Number(r.amount||0),0);

  const summaryCards = [
    { label: "Settled",    value: fmt(totalSettled),  color: "#059669", bg: "#ecfdf5", icon: <AccountBalanceIcon /> },
    { label: "Pending",    value: fmt(totalPending),  color: "#d97706", bg: "#fffbeb", icon: <AccountBalanceIcon /> },
    { label: "Rejected",   value: fmt(totalRejected), color: "#dc2626", bg: "#fef2f2", icon: <AccountBalanceIcon /> },
    { label: "Total Records", value: filtered.length, color: "#1a56db", bg: "#e8efff", icon: <AccountBalanceIcon /> },
  ];

  return (
    <Box>
      <Box sx={{ mb: 3, display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 2 }}>
        <Box>
          <Typography sx={{ fontSize: 22, fontWeight: 800, color: C.text1 }}>Settlement Report</Typography>
          <Typography sx={{ fontSize: 13, color: C.text3 }}>Top-up settlements across all users in the selected period</Typography>
        </Box>
        <Button startIcon={<DownloadIcon />} variant="outlined" onClick={() => downloadCSV(filtered)}
          sx={{ borderRadius: "10px", textTransform: "none", borderColor: C.border, color: C.text2 }}>Export CSV</Button>
      </Box>

      <Grid container spacing={2} sx={{ mb: 3 }}>
        {summaryCards.map(c => (
          <Grid item xs={12} sm={6} md={3} key={c.label}>
            <Paper elevation={0} sx={{ p: 2.5, borderRadius: "14px", border: `1px solid ${C.border}`, display: "flex", alignItems: "center", gap: 2 }}>
              <Box sx={{ width: 44, height: 44, borderRadius: "12px", background: c.bg, display: "flex", alignItems: "center", justifyContent: "center", color: c.color }}>{c.icon}</Box>
              <Box>
                <Typography sx={{ fontSize: 11, fontWeight: 700, color: C.text3, textTransform: "uppercase", letterSpacing: "0.05em" }}>{c.label}</Typography>
                <Typography sx={{ fontSize: 18, fontWeight: 800, color: C.text1 }}>{c.value}</Typography>
              </Box>
            </Paper>
          </Grid>
        ))}
      </Grid>

      <Paper elevation={0} sx={{ p: 2, mb: 2.5, borderRadius: "14px", border: `1px solid ${C.border}`, display: "flex", gap: 2, flexWrap: "wrap", alignItems: "center" }}>
        <TextField size="small" placeholder="Search name or UTR…" value={search} onChange={e => setSearch(e.target.value)}
          InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }}
          sx={{ flex: 1, minWidth: 200, "& .MuiOutlinedInput-root": { borderRadius: "10px" } }} />
        <TextField select size="small" value={statusFilter} onChange={e => setStatusFilter(e.target.value)} sx={{ minWidth: 140, "& .MuiOutlinedInput-root": { borderRadius: "10px" } }}>
          {["All","APPROVED","PENDING","REJECTED"].map(s => <MenuItem key={s} value={s}>{s === "APPROVED" ? "Settled" : s}</MenuItem>)}
        </TextField>
        <TextField size="small" type="date" label="From" value={fromDate} onChange={e => setFromDate(e.target.value)} InputLabelProps={{ shrink: true }} sx={{ "& .MuiOutlinedInput-root": { borderRadius: "10px" } }} />
        <TextField size="small" type="date" label="To"   value={toDate}   onChange={e => setToDate(e.target.value)}   InputLabelProps={{ shrink: true }} sx={{ "& .MuiOutlinedInput-root": { borderRadius: "10px" } }} />
        <Button variant="contained" onClick={load} startIcon={<RefreshIcon />}
          sx={{ background: A, borderRadius: "10px", textTransform: "none", fontWeight: 700, "&:hover": { background: "#b91c1c" } }}>Load</Button>
      </Paper>

      <Paper elevation={0} sx={{ borderRadius: "16px", border: `1px solid ${C.border}`, overflow: "hidden" }}>
        <TableContainer>
          <Table>
            <TableHead sx={{ background: "#f8faff" }}>
              <TableRow>
                {["ID","Requester","Payment Mode","UTR Ref","Amount","Status","Date"].map(h => (
                  <TableCell key={h} sx={{ fontWeight: 700, color: C.text3, fontSize: 11, textTransform: "uppercase", letterSpacing: "0.05em" }}>{h}</TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow><TableCell colSpan={7} align="center" sx={{ py: 6 }}><CircularProgress sx={{ color: A }} /></TableCell></TableRow>
              ) : filtered.length === 0 ? (
                <TableRow><TableCell colSpan={7} align="center" sx={{ py: 6, color: C.text3 }}>No settlement records found.</TableCell></TableRow>
              ) : filtered.map((r, i) => {
                const sc = statusConfig[r.status] || { label: r.status, bg: "#f3f4f6", color: "#374151" };
                return (
                  <TableRow key={r.id || i} hover>
                    <TableCell sx={{ fontSize: 12, color: C.text3, fontFamily: "monospace" }}>#{r.id}</TableCell>
                    <TableCell>
                      <Typography sx={{ fontSize: 13, fontWeight: 700, color: C.text1 }}>{r.requesterUsername || "—"}</Typography>
                      <Typography sx={{ fontSize: 11, color: C.text3 }}>{r.requesterType || "—"}</Typography>
                    </TableCell>
                    <TableCell sx={{ fontSize: 13, color: C.text2 }}>{r.paymentMode || "—"}</TableCell>
                    <TableCell sx={{ fontSize: 12, color: C.text3, fontFamily: "monospace" }}>{r.utrNumber || "—"}</TableCell>
                    <TableCell sx={{ fontWeight: 800, fontSize: 13, color: C.text1 }}>{fmt(r.amount)}</TableCell>
                    <TableCell><Chip label={sc.label} size="small" sx={{ background: sc.bg, color: sc.color, fontWeight: 700, fontSize: 11 }} /></TableCell>
                    <TableCell sx={{ fontSize: 12, color: C.text3 }}>{r.requestDate ? new Date(r.requestDate).toLocaleDateString("en-IN") : "—"}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
        <Box sx={{ px: 3, py: 1.5, borderTop: `1px solid ${C.border}`, display: "flex", justifyContent: "space-between" }}>
          <Typography sx={{ fontSize: 12, color: C.text3 }}>Showing {filtered.length} of {data.length}</Typography>
          <Typography sx={{ fontSize: 12, color: C.text3 }}>Settled: <strong style={{ color: "#059669" }}>{fmt(totalSettled)}</strong></Typography>
        </Box>
      </Paper>

      <Snackbar open={toast.open} autoHideDuration={3500} onClose={() => setToast({ ...toast, open: false })} anchorOrigin={{ vertical: "bottom", horizontal: "right" }}>
        <Alert severity={toast.sev} sx={{ borderRadius: "10px" }}>{toast.msg}</Alert>
      </Snackbar>
    </Box>
  );
}
