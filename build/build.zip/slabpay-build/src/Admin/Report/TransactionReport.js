import { useState, useEffect, useCallback } from "react";
import {
  Box, Typography, Paper, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, Chip, TextField,
  MenuItem, Button, InputAdornment, Grid, CircularProgress, Alert, Snackbar,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import DownloadIcon from "@mui/icons-material/Download";
import RefreshIcon from "@mui/icons-material/Refresh";
import ReceiptLongIcon from "@mui/icons-material/ReceiptLong";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import TrendingDownIcon from "@mui/icons-material/TrendingDown";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";
import { getTransactionsByDateRange } from "../../services/adminApi";

const C = { border: "#e5eaf5", text1: "#0f1623", text2: "#3a4563", text3: "#7a8aab" };
const A = "#dc2626";

const statusConfig = {
  SUCCESS:   { color: "#059669", bg: "#ecfdf5", label: "Success"  },
  COMPLETED: { color: "#059669", bg: "#ecfdf5", label: "Completed"},
  PENDING:   { color: "#d97706", bg: "#fffbeb", label: "Pending"  },
  FAILED:    { color: "#dc2626", bg: "#fef2f2", label: "Failed"   },
  REVERSED:  { color: "#6b7280", bg: "#f3f4f6", label: "Reversed" },
};

const scFor = (s) => statusConfig[(s||"").toUpperCase()] || { color: "#374151", bg: "#f3f4f6", label: s };

const fmt  = (n) => n == null ? "₹0.00" : "₹" + Number(n).toLocaleString("en-IN", { minimumFractionDigits: 2 });
const today = () => new Date().toISOString().split("T")[0];
const monthStart = () => { const d = new Date(); d.setDate(1); return d.toISOString().split("T")[0]; };

const downloadCSV = (rows) => {
  const cols = ["ID","Type","User","Amount","Fee","Status","Date"];
  const lines = [cols.join(","), ...rows.map(r =>
    [r.id||r.transactionId, r.serviceType||r.transactionType||"—", r.userName||"—",
     r.amount, r.charges||0, r.status, r.createdDate||"—"].join(","))];
  const blob = new Blob([lines.join("\n")], { type: "text/csv" });
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob);
  a.download = "transactions.csv"; a.click();
};

export default function TransactionReport() {
  const [data,         setData]         = useState([]);
  const [loading,      setLoading]      = useState(true);
  const [toast,        setToast]        = useState({ open: false, msg: "", sev: "success" });
  const [search,       setSearch]       = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [typeFilter,   setTypeFilter]   = useState("All");
  const [fromDate,     setFromDate]     = useState(monthStart());
  const [toDate,       setToDate]       = useState(today());

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getTransactionsByDateRange({ from: fromDate, to: toDate });
      setData(Array.isArray(res.data?.data) ? res.data.data : []);
    } catch {
      setToast({ open: true, msg: "Failed to load transactions.", sev: "error" });
    } finally { setLoading(false); }
  }, [fromDate, toDate]);

  useEffect(() => { load(); }, [load]);

  const types = ["All", ...new Set(data.map(r => r.serviceType || r.transactionType).filter(Boolean))];

  const filtered = data.filter(r => {
    const q = search.toLowerCase();
    const sc = (r.status || "").toUpperCase();
    const tp = r.serviceType || r.transactionType || "";
    return (
      (!search || (r.userName||"").toLowerCase().includes(q) || String(r.id||r.transactionId||"").includes(search)) &&
      (statusFilter === "All" || sc === statusFilter) &&
      (typeFilter === "All" || tp === typeFilter)
    );
  });

  const summaryCards = [
    { label: "Total Transactions",   value: filtered.length,                                                                  icon: <ReceiptLongIcon />,      color: "#1a56db", bg: "#e8efff" },
    { label: "Success",              value: filtered.filter(r=>(r.status||"").toUpperCase()==="SUCCESS"||"COMPLETED").length, icon: <TrendingUpIcon />,       color: "#059669", bg: "#ecfdf5" },
    { label: "Failed",               value: filtered.filter(r=>(r.status||"").toUpperCase()==="FAILED").length,              icon: <TrendingDownIcon />,      color: "#dc2626", bg: "#fef2f2" },
    { label: "Total Volume",         value: fmt(filtered.reduce((s,r)=>s+Number(r.amount||0),0)),                             icon: <AccountBalanceWalletIcon/>,color: "#7c3aed",bg: "#f5f3ff" },
  ];

  return (
    <Box>
      <Box sx={{ mb: 3, display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 2 }}>
        <Box>
          <Typography sx={{ fontSize: 22, fontWeight: 800, color: C.text1 }}>Transaction Report</Typography>
          <Typography sx={{ fontSize: 13, color: C.text3 }}>Complete transaction activity across all users</Typography>
        </Box>
        <Button startIcon={<DownloadIcon />} variant="outlined" onClick={() => downloadCSV(filtered)}
          sx={{ borderRadius: "10px", textTransform: "none", borderColor: C.border, color: C.text2 }}>
          Export CSV
        </Button>
      </Box>

      {/* Summary cards */}
      <Grid container spacing={2} sx={{ mb: 3 }}>
        {summaryCards.map(c => (
          <Grid item xs={12} sm={6} md={3} key={c.label}>
            <Paper elevation={0} sx={{ p: 2.5, borderRadius: "14px", border: `1px solid ${C.border}`, display: "flex", alignItems: "center", gap: 2 }}>
              <Box sx={{ width: 44, height: 44, borderRadius: "12px", background: c.bg, display: "flex", alignItems: "center", justifyContent: "center", color: c.color }}>{c.icon}</Box>
              <Box>
                <Typography sx={{ fontSize: 11, fontWeight: 700, color: C.text3, textTransform: "uppercase", letterSpacing: "0.05em" }}>{c.label}</Typography>
                <Typography sx={{ fontSize: 18, fontWeight: 800, color: C.text1 }}>{c.value}</Typography>
              </Box>
            </Paper>
          </Grid>
        ))}
      </Grid>

      {/* Filters */}
      <Paper elevation={0} sx={{ p: 2, mb: 2.5, borderRadius: "14px", border: `1px solid ${C.border}`, display: "flex", gap: 2, flexWrap: "wrap", alignItems: "center" }}>
        <TextField size="small" placeholder="Search user / ID…" value={search} onChange={e => setSearch(e.target.value)}
          InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }}
          sx={{ flex: 1, minWidth: 180, "& .MuiOutlinedInput-root": { borderRadius: "10px" } }} />
        <TextField select size="small" value={statusFilter} onChange={e => setStatusFilter(e.target.value)} sx={{ minWidth: 140, "& .MuiOutlinedInput-root": { borderRadius: "10px" } }}>
          {["All", "SUCCESS", "PENDING", "FAILED"].map(s => <MenuItem key={s} value={s}>{s}</MenuItem>)}
        </TextField>
        <TextField select size="small" value={typeFilter} onChange={e => setTypeFilter(e.target.value)} sx={{ minWidth: 160, "& .MuiOutlinedInput-root": { borderRadius: "10px" } }}>
          {types.map(t => <MenuItem key={t} value={t}>{t}</MenuItem>)}
        </TextField>
        <TextField size="small" type="date" label="From" value={fromDate} onChange={e => setFromDate(e.target.value)}
          InputLabelProps={{ shrink: true }} sx={{ "& .MuiOutlinedInput-root": { borderRadius: "10px" } }} />
        <TextField size="small" type="date" label="To" value={toDate} onChange={e => setToDate(e.target.value)}
          InputLabelProps={{ shrink: true }} sx={{ "& .MuiOutlinedInput-root": { borderRadius: "10px" } }} />
        <Button variant="contained" onClick={load} startIcon={<RefreshIcon />}
          sx={{ background: A, borderRadius: "10px", textTransform: "none", fontWeight: 700, "&:hover": { background: "#b91c1c" } }}>
          Load
        </Button>
      </Paper>

      {/* Table */}
      <Paper elevation={0} sx={{ borderRadius: "16px", border: `1px solid ${C.border}`, overflow: "hidden" }}>
        <TableContainer>
          <Table>
            <TableHead sx={{ background: "#f8faff" }}>
              <TableRow>
                {["ID", "Type", "User", "Amount", "Fee / Charges", "Status", "Date"].map(h => (
                  <TableCell key={h} sx={{ fontWeight: 700, color: C.text3, fontSize: 11, textTransform: "uppercase", letterSpacing: "0.05em" }}>{h}</TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow><TableCell colSpan={7} align="center" sx={{ py: 6 }}><CircularProgress sx={{ color: A }} /></TableCell></TableRow>
              ) : filtered.length === 0 ? (
                <TableRow><TableCell colSpan={7} align="center" sx={{ py: 6, color: C.text3 }}>No transactions in this period.</TableCell></TableRow>
              ) : filtered.map((r, i) => {
                const sc = scFor(r.status);
                return (
                  <TableRow key={r.id || i} hover>
                    <TableCell sx={{ fontSize: 12, color: C.text3, fontFamily: "monospace" }}>#{r.id || r.transactionId}</TableCell>
                    <TableCell><Chip label={r.serviceType || r.transactionType || "—"} size="small" sx={{ background: "#e8efff", color: "#1a56db", fontWeight: 600, fontSize: 11 }} /></TableCell>
                    <TableCell sx={{ fontSize: 13, color: C.text1, fontWeight: 600 }}>{r.userName || r.senderName || "—"}</TableCell>
                    <TableCell sx={{ fontWeight: 800, color: C.text1, fontSize: 13 }}>{fmt(r.amount)}</TableCell>
                    <TableCell sx={{ fontSize: 13, color: C.text3 }}>{fmt(r.charges || r.fee)}</TableCell>
                    <TableCell><Chip label={sc.label} size="small" sx={{ background: sc.bg, color: sc.color, fontWeight: 600, fontSize: 11 }} /></TableCell>
                    <TableCell sx={{ fontSize: 12, color: C.text3 }}>{r.createdDate ? new Date(r.createdDate).toLocaleDateString("en-IN") : "—"}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
        <Box sx={{ px: 3, py: 1.5, borderTop: `1px solid ${C.border}`, display: "flex", justifyContent: "space-between" }}>
          <Typography sx={{ fontSize: 12, color: C.text3 }}>Showing {filtered.length} of {data.length}</Typography>
          <Typography sx={{ fontSize: 12, color: C.text3 }}>Volume: <strong>{fmt(filtered.reduce((s,r)=>s+Number(r.amount||0),0))}</strong></Typography>
        </Box>
      </Paper>

      <Snackbar open={toast.open} autoHideDuration={3500} onClose={() => setToast({ ...toast, open: false })} anchorOrigin={{ vertical: "bottom", horizontal: "right" }}>
        <Alert severity={toast.sev} sx={{ borderRadius: "10px" }}>{toast.msg}</Alert>
      </Snackbar>
    </Box>
  );
}
