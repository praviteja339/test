import { useState, useEffect, useCallback } from "react";
import {
  Box, Typography, Paper, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Chip, TextField, MenuItem, Button,
  InputAdornment, Grid, CircularProgress, Alert, Snackbar,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import DownloadIcon from "@mui/icons-material/Download";
import RefreshIcon from "@mui/icons-material/Refresh";
import PercentIcon from "@mui/icons-material/Percent";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";
import { getCommissionDetails } from "../../services/adminApi";

const C = { border: "#e5eaf5", text1: "#0f1623", text2: "#3a4563", text3: "#7a8aab" };
const A = "#dc2626";
const fmt  = (n) => n == null ? "₹0.00" : "₹" + Number(n).toLocaleString("en-IN", { minimumFractionDigits: 2 });
const today = () => new Date().toISOString().split("T")[0];
const monthStart = () => { const d = new Date(); d.setDate(1); return d.toISOString().split("T")[0]; };

const roleColor = {
  Retailer:     { bg: "#ecfdf5", color: "#059669" },
  Distributor:  { bg: "#e8efff", color: "#1a56db" },
  SuperDist:    { bg: "#ede9fe", color: "#7c3aed" },
  Agent:        { bg: "#ecfdf5", color: "#059669" },
};
const rcFor = (r) => roleColor[r] || { bg: "#f3f4f6", color: "#374151" };

const downloadCSV = (rows) => {
  const cols = ["ID","User","Service","Txn Amount","Comm %","Commission","Date","Status"];
  const lines = [cols.join(","), ...rows.map(r =>
    [r.id, r.accountName||"—", r.sType||"—", r.transactionAmount||0, r.retailPercentage||0, r.amount||0, r.createdDate||"—", "Credited"].join(","))];
  const blob = new Blob([lines.join("\n")], { type: "text/csv" });
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "commission_report.csv"; a.click();
};

export default function CommissionReport() {
  const [data,       setData]       = useState([]);
  const [summary,    setSummary]    = useState(null);
  const [loading,    setLoading]    = useState(true);
  const [toast,      setToast]      = useState({ open: false, msg: "", sev: "success" });
  const [search,     setSearch]     = useState("");
  const [roleFilter, setRoleFilter] = useState("All");
  const [fromDate,   setFromDate]   = useState(monthStart());
  const [toDate,     setToDate]     = useState(today());
  const adminId = localStorage.getItem("userId") || "1";

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getCommissionDetails(adminId, fromDate, toDate);
      const d = res.data?.data;
      if (d?.entries) {
        setData(d.entries);
        setSummary(d);
      } else if (Array.isArray(d)) {
        setData(d);
        setSummary(null);
      }
    } catch {
      setToast({ open: true, msg: "Failed to load commission report.", sev: "error" });
    } finally { setLoading(false); }
  }, [adminId, fromDate, toDate]);

  useEffect(() => { load(); }, [load]);

  const filtered = data.filter(r => {
    const q = search.toLowerCase();
    return (
      (!search || (r.accountName||"").toLowerCase().includes(q) || String(r.id).includes(search)) &&
      (roleFilter === "All" || (r.accountType||"") === roleFilter)
    );
  });

  const totalComm   = filtered.reduce((s,r)=>s+Number(r.amount||0),0);
  const summaryCards = [
    { label: "Total Commission",       value: fmt(summary?.totalCommission ?? totalComm), color: "#7c3aed", bg: "#f5f3ff", icon: <PercentIcon /> },
    { label: "Opening Balance",        value: fmt(summary?.openingBalance),               color: "#1a56db", bg: "#e8efff", icon: <AccountBalanceWalletIcon /> },
    { label: "Closing Balance",        value: fmt(summary?.closingBalance),               color: "#059669", bg: "#ecfdf5", icon: <AccountBalanceWalletIcon /> },
    { label: "Entries",                value: filtered.length,                            color: "#d97706", bg: "#fffbeb", icon: <PercentIcon /> },
  ];

  return (
    <Box>
      <Box sx={{ mb: 3, display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 2 }}>
        <Box>
          <Typography sx={{ fontSize: 22, fontWeight: 800, color: C.text1 }}>Commission Report</Typography>
          <Typography sx={{ fontSize: 13, color: C.text3 }}>Commission earned by account in the selected period</Typography>
        </Box>
        <Button startIcon={<DownloadIcon />} variant="outlined" onClick={() => downloadCSV(filtered)}
          sx={{ borderRadius: "10px", textTransform: "none", borderColor: C.border, color: C.text2 }}>Export CSV</Button>
      </Box>

      <Grid container spacing={2} sx={{ mb: 3 }}>
        {summaryCards.map(c => (
          <Grid item xs={12} sm={6} md={3} key={c.label}>
            <Paper elevation={0} sx={{ p: 2.5, borderRadius: "14px", border: `1px solid ${C.border}`, display: "flex", alignItems: "center", gap: 2 }}>
              <Box sx={{ width: 44, height: 44, borderRadius: "12px", background: c.bg, display: "flex", alignItems: "center", justifyContent: "center", color: c.color }}>{c.icon}</Box>
              <Box>
                <Typography sx={{ fontSize: 11, fontWeight: 700, color: C.text3, textTransform: "uppercase", letterSpacing: "0.05em" }}>{c.label}</Typography>
                <Typography sx={{ fontSize: 18, fontWeight: 800, color: C.text1 }}>{c.value}</Typography>
              </Box>
            </Paper>
          </Grid>
        ))}
      </Grid>

      <Paper elevation={0} sx={{ p: 2, mb: 2.5, borderRadius: "14px", border: `1px solid ${C.border}`, display: "flex", gap: 2, flexWrap: "wrap", alignItems: "center" }}>
        <TextField size="small" placeholder="Search user…" value={search} onChange={e => setSearch(e.target.value)}
          InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }}
          sx={{ flex: 1, minWidth: 180, "& .MuiOutlinedInput-root": { borderRadius: "10px" } }} />
        <TextField select size="small" value={roleFilter} onChange={e => setRoleFilter(e.target.value)} sx={{ minWidth: 150, "& .MuiOutlinedInput-root": { borderRadius: "10px" } }}>
          {["All","Retailer","Distributor","SuperDist"].map(s => <MenuItem key={s} value={s}>{s}</MenuItem>)}
        </TextField>
        <TextField size="small" type="date" label="From" value={fromDate} onChange={e => setFromDate(e.target.value)} InputLabelProps={{ shrink: true }} sx={{ "& .MuiOutlinedInput-root": { borderRadius: "10px" } }} />
        <TextField size="small" type="date" label="To"   value={toDate}   onChange={e => setToDate(e.target.value)}   InputLabelProps={{ shrink: true }} sx={{ "& .MuiOutlinedInput-root": { borderRadius: "10px" } }} />
        <Button variant="contained" onClick={load} startIcon={<RefreshIcon />}
          sx={{ background: A, borderRadius: "10px", textTransform: "none", fontWeight: 700, "&:hover": { background: "#b91c1c" } }}>Load</Button>
      </Paper>

      <Paper elevation={0} sx={{ borderRadius: "16px", border: `1px solid ${C.border}`, overflow: "hidden" }}>
        <TableContainer>
          <Table>
            <TableHead sx={{ background: "#f8faff" }}>
              <TableRow>
                {["ID","User","Service Type","Txn Amount","Comm %","Commission","Date"].map(h => (
                  <TableCell key={h} sx={{ fontWeight: 700, color: C.text3, fontSize: 11, textTransform: "uppercase", letterSpacing: "0.05em" }}>{h}</TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow><TableCell colSpan={7} align="center" sx={{ py: 6 }}><CircularProgress sx={{ color: A }} /></TableCell></TableRow>
              ) : filtered.length === 0 ? (
                <TableRow><TableCell colSpan={7} align="center" sx={{ py: 6, color: C.text3 }}>No commission entries in this period.</TableCell></TableRow>
              ) : filtered.map((r, i) => {
                const rc = rcFor(r.accountType);
                const pct = r.retailPercentage || r.distributorPercentage || r.superDistributorPercentage || 0;
                return (
                  <TableRow key={r.id || i} hover>
                    <TableCell sx={{ fontSize: 12, color: C.text3, fontFamily: "monospace" }}>#{r.id}</TableCell>
                    <TableCell>
                      <Typography sx={{ fontSize: 13, fontWeight: 700, color: C.text1 }}>{r.accountName || "—"}</Typography>
                      <Chip label={r.accountType||"—"} size="small" sx={{ ...rc, fontWeight: 600, fontSize: 10, height: 18, mt: 0.3 }} />
                    </TableCell>
                    <TableCell><Chip label={r.sType||"—"} size="small" sx={{ background:"#e8efff",color:"#1a56db",fontWeight:600,fontSize:11 }}/></TableCell>
                    <TableCell sx={{ fontWeight: 600, fontSize: 13, color: C.text1 }}>{fmt(r.transactionAmount || 0)}</TableCell>
                    <TableCell sx={{ fontSize: 13, color: C.text2 }}>{Number(pct).toFixed(3)}%</TableCell>
                    <TableCell sx={{ fontWeight: 800, fontSize: 13, color: "#059669" }}>{fmt(r.amount)}</TableCell>
                    <TableCell sx={{ fontSize: 12, color: C.text3 }}>{r.createdDate ? new Date(r.createdDate).toLocaleDateString("en-IN") : "—"}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
        <Box sx={{ px: 3, py: 1.5, borderTop: `1px solid ${C.border}`, display: "flex", justifyContent: "space-between" }}>
          <Typography sx={{ fontSize: 12, color: C.text3 }}>Showing {filtered.length} of {data.length} entries</Typography>
          <Typography sx={{ fontSize: 12, color: C.text3 }}>Total Commission: <strong style={{ color: "#059669" }}>{fmt(totalComm)}</strong></Typography>
        </Box>
      </Paper>

      <Snackbar open={toast.open} autoHideDuration={3500} onClose={() => setToast({ ...toast, open: false })} anchorOrigin={{ vertical: "bottom", horizontal: "right" }}>
        <Alert severity={toast.sev} sx={{ borderRadius: "10px" }}>{toast.msg}</Alert>
      </Snackbar>
    </Box>
  );
}
