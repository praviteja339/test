import { useState, useEffect, useCallback } from "react";
import {
  Box, Typography, Paper, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Chip, TextField, MenuItem, Button,
  InputAdornment, Grid, CircularProgress, Alert, Snackbar,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import DownloadIcon from "@mui/icons-material/Download";
import RefreshIcon from "@mui/icons-material/Refresh";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import TrendingDownIcon from "@mui/icons-material/TrendingDown";
import { getLedgerByDateRange } from "../../services/adminApi";

const C = { border: "#e5eaf5", text1: "#0f1623", text2: "#3a4563", text3: "#7a8aab" };
const A = "#dc2626";
const fmt  = (n) => n == null ? "₹0.00" : "₹" + Number(n).toLocaleString("en-IN", { minimumFractionDigits: 2 });
const today = () => new Date().toISOString().split("T")[0];
const monthStart = () => { const d = new Date(); d.setDate(1); return d.toISOString().split("T")[0]; };

const downloadCSV = (rows) => {
  const cols = ["ID","Type","Description","Amount","Balance","Date"];
  const lines = [cols.join(","), ...rows.map(r =>
    [r.id, r.eType||"—", (r.description||r.narration||"—").replace(/,/g," "), r.amount, r.closingBalance||"—", r.createdDate||"—"].join(","))];
  const blob = new Blob([lines.join("\n")], { type: "text/csv" });
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "wallet_report.csv"; a.click();
};

export default function WalletReport() {
  const [data,       setData]       = useState([]);
  const [summary,    setSummary]    = useState(null);
  const [loading,    setLoading]    = useState(true);
  const [toast,      setToast]      = useState({ open: false, msg: "", sev: "success" });
  const [search,     setSearch]     = useState("");
  const [typeFilter, setTypeFilter] = useState("All");
  const [fromDate,   setFromDate]   = useState(monthStart());
  const [toDate,     setToDate]     = useState(today());
  const adminId = localStorage.getItem("userId") || "1";

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getLedgerByDateRange(adminId, fromDate, toDate);
      const d = res.data?.data;
      if (d?.entries) {
        setData(d.entries);
        setSummary(d);
      } else if (Array.isArray(d)) {
        setData(d);
        setSummary(null);
      }
    } catch {
      setToast({ open: true, msg: "Failed to load wallet report.", sev: "error" });
    } finally { setLoading(false); }
  }, [adminId, fromDate, toDate]);

  useEffect(() => { load(); }, [load]);

  const filtered = data.filter(r => {
    const q = search.toLowerCase();
    return (
      (!search || (r.description||r.narration||"").toLowerCase().includes(q) || String(r.id).includes(search)) &&
      (typeFilter === "All" || (r.eType||"").toUpperCase() === typeFilter)
    );
  });

  const totalCredit = filtered.filter(r=>(r.eType||"").toLowerCase()==="cr").reduce((s,r)=>s+Number(r.amount||0),0);
  const totalDebit  = filtered.filter(r=>(r.eType||"").toLowerCase()==="dr").reduce((s,r)=>s+Number(r.amount||0),0);

  const summaryCards = [
    { label: "Total Credits",   value: fmt(summary?.totalCredit ?? totalCredit),  icon: <TrendingUpIcon />,         color: "#059669", bg: "#ecfdf5" },
    { label: "Total Debits",    value: fmt(summary?.totalDebit  ?? totalDebit),   icon: <TrendingDownIcon />,        color: "#dc2626", bg: "#fef2f2" },
    { label: "Opening Balance", value: fmt(summary?.openingBalance),              icon: <AccountBalanceWalletIcon/>, color: "#1a56db", bg: "#e8efff" },
    { label: "Closing Balance", value: fmt(summary?.closingBalance),              icon: <AccountBalanceWalletIcon/>, color: "#7c3aed", bg: "#f5f3ff" },
  ];

  return (
    <Box>
      <Box sx={{ mb: 3, display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 2 }}>
        <Box>
          <Typography sx={{ fontSize: 22, fontWeight: 800, color: C.text1 }}>Wallet Report</Typography>
          <Typography sx={{ fontSize: 13, color: C.text3 }}>Admin wallet ledger — credits and debits over the selected period</Typography>
        </Box>
        <Button startIcon={<DownloadIcon />} variant="outlined" onClick={() => downloadCSV(filtered)}
          sx={{ borderRadius: "10px", textTransform: "none", borderColor: C.border, color: C.text2 }}>Export CSV</Button>
      </Box>

      <Grid container spacing={2} sx={{ mb: 3 }}>
        {summaryCards.map(c => (
          <Grid item xs={12} sm={6} md={3} key={c.label}>
            <Paper elevation={0} sx={{ p: 2.5, borderRadius: "14px", border: `1px solid ${C.border}`, display: "flex", alignItems: "center", gap: 2 }}>
              <Box sx={{ width: 44, height: 44, borderRadius: "12px", background: c.bg, display: "flex", alignItems: "center", justifyContent: "center", color: c.color }}>{c.icon}</Box>
              <Box>
                <Typography sx={{ fontSize: 11, fontWeight: 700, color: C.text3, textTransform: "uppercase", letterSpacing: "0.05em" }}>{c.label}</Typography>
                <Typography sx={{ fontSize: 18, fontWeight: 800, color: C.text1 }}>{c.value}</Typography>
              </Box>
            </Paper>
          </Grid>
        ))}
      </Grid>

      <Paper elevation={0} sx={{ p: 2, mb: 2.5, borderRadius: "14px", border: `1px solid ${C.border}`, display: "flex", gap: 2, flexWrap: "wrap", alignItems: "center" }}>
        <TextField size="small" placeholder="Search description…" value={search} onChange={e => setSearch(e.target.value)}
          InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }}
          sx={{ flex: 1, minWidth: 180, "& .MuiOutlinedInput-root": { borderRadius: "10px" } }} />
        <TextField select size="small" value={typeFilter} onChange={e => setTypeFilter(e.target.value)} sx={{ minWidth: 130, "& .MuiOutlinedInput-root": { borderRadius: "10px" } }}>
          {["All","CR","DR"].map(s => <MenuItem key={s} value={s}>{s === "All" ? "All" : s === "CR" ? "Credits" : "Debits"}</MenuItem>)}
        </TextField>
        <TextField size="small" type="date" label="From" value={fromDate} onChange={e => setFromDate(e.target.value)} InputLabelProps={{ shrink: true }} sx={{ "& .MuiOutlinedInput-root": { borderRadius: "10px" } }} />
        <TextField size="small" type="date" label="To"   value={toDate}   onChange={e => setToDate(e.target.value)}   InputLabelProps={{ shrink: true }} sx={{ "& .MuiOutlinedInput-root": { borderRadius: "10px" } }} />
        <Button variant="contained" onClick={load} startIcon={<RefreshIcon />}
          sx={{ background: A, borderRadius: "10px", textTransform: "none", fontWeight: 700, "&:hover": { background: "#b91c1c" } }}>Load</Button>
      </Paper>

      <Paper elevation={0} sx={{ borderRadius: "16px", border: `1px solid ${C.border}`, overflow: "hidden" }}>
        <TableContainer>
          <Table>
            <TableHead sx={{ background: "#f8faff" }}>
              <TableRow>
                {["ID","Type","Description","Amount","Balance After","Date"].map(h => (
                  <TableCell key={h} sx={{ fontWeight: 700, color: C.text3, fontSize: 11, textTransform: "uppercase", letterSpacing: "0.05em" }}>{h}</TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow><TableCell colSpan={6} align="center" sx={{ py: 6 }}><CircularProgress sx={{ color: A }} /></TableCell></TableRow>
              ) : filtered.length === 0 ? (
                <TableRow><TableCell colSpan={6} align="center" sx={{ py: 6, color: C.text3 }}>No entries in this period.</TableCell></TableRow>
              ) : filtered.map((r, i) => {
                const isCr = (r.eType||"").toLowerCase() === "cr";
                return (
                  <TableRow key={r.id || i} hover>
                    <TableCell sx={{ fontSize: 12, color: C.text3, fontFamily: "monospace" }}>#{r.id}</TableCell>
                    <TableCell>
                      <Chip label={isCr ? "Credit" : "Debit"} size="small"
                        sx={{ background: isCr ? "#ecfdf5" : "#fef2f2", color: isCr ? "#059669" : "#dc2626", fontWeight: 700, fontSize: 11,
                          display: "flex", alignItems: "center", gap: 0.4 }}
                        icon={isCr ? <TrendingUpIcon sx={{ fontSize: "14px !important" }} /> : <TrendingDownIcon sx={{ fontSize: "14px !important" }} />} />
                    </TableCell>
                    <TableCell sx={{ fontSize: 13, color: C.text2 }}>{r.description || r.narration || "—"}</TableCell>
                    <TableCell sx={{ fontWeight: 800, fontSize: 13, color: isCr ? "#059669" : "#dc2626" }}>
                      {isCr ? "+" : "−"}{fmt(r.amount)}
                    </TableCell>
                    <TableCell sx={{ fontSize: 13, color: C.text1, fontWeight: 600 }}>{fmt(r.closingBalance || r.balance)}</TableCell>
                    <TableCell sx={{ fontSize: 12, color: C.text3 }}>{r.createdDate ? new Date(r.createdDate).toLocaleDateString("en-IN") : "—"}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
        <Box sx={{ px: 3, py: 1.5, borderTop: `1px solid ${C.border}`, display: "flex", justifyContent: "space-between" }}>
          <Typography sx={{ fontSize: 12, color: C.text3 }}>Showing {filtered.length} of {data.length} entries</Typography>
          <Typography sx={{ fontSize: 12, color: C.text3 }}>Net: <strong style={{ color: totalCredit - totalDebit >= 0 ? "#059669" : "#dc2626" }}>{fmt(totalCredit - totalDebit)}</strong></Typography>
        </Box>
      </Paper>

      <Snackbar open={toast.open} autoHideDuration={3500} onClose={() => setToast({ ...toast, open: false })} anchorOrigin={{ vertical: "bottom", horizontal: "right" }}>
        <Alert severity={toast.sev} sx={{ borderRadius: "10px" }}>{toast.msg}</Alert>
      </Snackbar>
    </Box>
  );
}
