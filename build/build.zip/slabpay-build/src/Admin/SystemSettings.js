import { useState, useEffect } from "react";
import {
  Box, Typography, Paper, TextField, Button, Switch,
  Divider, Alert, Grid, InputAdornment, CircularProgress, Snackbar,
} from "@mui/material";
import SettingsIcon from "@mui/icons-material/Settings";
import SaveIcon from "@mui/icons-material/Save";
import SecurityIcon from "@mui/icons-material/Security";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";
import { getSettings, updateSettings } from "../services/adminApi";

const A = "#dc2626";
const C = { border:"#e5eaf5", text1:"#0f1623", text2:"#3a4563", text3:"#7a8aab" };

const DEFAULTS = {
  general: { companyName:"SlabPay E Com Solutions Pvt. Ltd.", supportEmail:"support@slabpay.com",
             supportPhone:"+91-8147172176", gstNumber:"36AABCS1429B1ZB", timezone:"Asia/Kolkata" },
  wallet:  { minTopup:"1000", maxTopup:"500000", dailyLimit:"200000", transferFee:"0.5" },
  platform:{ maintenanceMode:"false", newRegistrations:"true", emailNotifications:"true",
             smsNotifications:"true", twoFactor:"false", autoSettle:"true" },
};

const cardStyle = { borderRadius:"16px", border:`1px solid ${C.border}`, p:3, mb:3 };

const Section = ({ icon, title, children }) => (
  <Paper elevation={0} sx={cardStyle}>
    <Box sx={{ display:"flex", alignItems:"center", gap:1.5, mb:2.5 }}>
      <Box sx={{ width:38,height:38,borderRadius:"10px",background:"#fef2f2",display:"flex",alignItems:"center",justifyContent:"center",color:A }}>
        {icon}
      </Box>
      <Typography sx={{ fontSize:16, fontWeight:700, color:C.text1 }}>{title}</Typography>
    </Box>
    <Divider sx={{ mb:2.5, borderColor:C.border }}/>
    {children}
  </Paper>
);

export default function SystemSettings() {
  const [loading,  setLoading]  = useState(true);
  const [saving,   setSaving]   = useState(false);
  const [toast,    setToast]    = useState({ open:false, msg:"", sev:"success" });
  const [general,  setGeneral]  = useState(DEFAULTS.general);
  const [wallet,   setWallet]   = useState(DEFAULTS.wallet);
  const [toggles,  setToggles]  = useState(
    Object.fromEntries(Object.entries(DEFAULTS.platform).map(([k,v])=>[k, v==="true"]))
  );

  useEffect(() => {
    getSettings()
      .then(res => {
        const d = res.data.data || {};
        if (d.general  && Object.keys(d.general).length)  setGeneral(g=>({...g,...d.general}));
        if (d.wallet   && Object.keys(d.wallet).length)   setWallet(w=>({...w,...d.wallet}));
        if (d.platform && Object.keys(d.platform).length)
          setToggles(t=>({ ...t, ...Object.fromEntries(Object.entries(d.platform).map(([k,v])=>[k,v==="true"])) }));
      })
      .catch(()=>{}) // use defaults if settings not persisted yet
      .finally(()=>setLoading(false));
  }, []);

  const handleSave = async () => {
    setSaving(true);
    const settings = {
      ...Object.fromEntries(Object.entries(general).map(([k,v])=>[k,v])),
      ...Object.fromEntries(Object.entries(wallet).map(([k,v])=>[k,String(v)])),
      ...Object.fromEntries(Object.entries(toggles).map(([k,v])=>[k,String(v)])),
    };
    try {
      await updateSettings({ settings, updatedBy: Number(localStorage.getItem("userId")||1) });
      setToast({ open:true, msg:"Settings saved successfully!", sev:"success" });
    } catch {
      setToast({ open:true, msg:"Failed to save settings.", sev:"error" });
    } finally { setSaving(false); }
  };

  if (loading) return <Box sx={{ display:"flex",justifyContent:"center",mt:8 }}><CircularProgress sx={{ color:A }}/></Box>;

  return (
    <Box>
      <Box sx={{ mb:3, display:"flex", justifyContent:"space-between", alignItems:"flex-start", flexWrap:"wrap", gap:2 }}>
        <Box>
          <Typography sx={{ fontSize:22, fontWeight:800, color:C.text1 }}>System Settings</Typography>
          <Typography sx={{ fontSize:13, color:C.text3 }}>Configure platform-wide settings — changes persist to the database</Typography>
        </Box>
        <Button startIcon={<SaveIcon/>} variant="contained" onClick={handleSave} disabled={saving}
          sx={{ background:A, borderRadius:"10px", textTransform:"none", fontWeight:700, "&:hover":{background:"#b91c1c"} }}>
          {saving ? <CircularProgress size={18} sx={{ color:"#fff" }}/> : "Save All Changes"}
        </Button>
      </Box>

      {/* General */}
      <Section icon={<SettingsIcon fontSize="small"/>} title="General Settings">
        <Grid container spacing={2}>
          {[
            { key:"companyName", label:"Company Name" },
            { key:"supportEmail",label:"Support Email" },
            { key:"supportPhone",label:"Support Phone" },
            { key:"gstNumber",   label:"GST Number" },
            { key:"timezone",    label:"Timezone" },
          ].map(f=>(
            <Grid item xs={12} sm={6} key={f.key}>
              <TextField label={f.label} value={general[f.key]||""} fullWidth size="small"
                onChange={e=>setGeneral({...general,[f.key]:e.target.value})}
                sx={{ "& .MuiOutlinedInput-root":{ borderRadius:"10px" } }}/>
            </Grid>
          ))}
        </Grid>
      </Section>

      {/* Wallet Limits */}
      <Section icon={<AccountBalanceWalletIcon fontSize="small"/>} title="Wallet & Transaction Limits">
        <Grid container spacing={2}>
          {[
            { key:"minTopup",   label:"Minimum Top-up (₹)",           prefix:"₹" },
            { key:"maxTopup",   label:"Maximum Top-up (₹)",           prefix:"₹" },
            { key:"dailyLimit", label:"Daily Transaction Limit (₹)",  prefix:"₹" },
            { key:"transferFee",label:"Transfer Fee (%)",              prefix:"%"  },
          ].map(f=>(
            <Grid item xs={12} sm={6} key={f.key}>
              <TextField label={f.label} value={wallet[f.key]||""} type="number" fullWidth size="small"
                onChange={e=>setWallet({...wallet,[f.key]:e.target.value})}
                InputProps={{ startAdornment:<InputAdornment position="start">{f.prefix}</InputAdornment> }}
                sx={{ "& .MuiOutlinedInput-root":{ borderRadius:"10px" } }}/>
            </Grid>
          ))}
        </Grid>
      </Section>

      {/* Toggles */}
      <Section icon={<SecurityIcon fontSize="small"/>} title="Platform Controls & Notifications">
        <Grid container spacing={0}>
          {[
            { key:"maintenanceMode",    label:"Maintenance Mode",         desc:"Take platform offline for maintenance" },
            { key:"newRegistrations",   label:"Allow New Registrations",  desc:"Enable new user sign-ups" },
            { key:"emailNotifications", label:"Email Notifications",      desc:"Send email alerts for transactions" },
            { key:"smsNotifications",   label:"SMS Notifications",        desc:"Send SMS alerts for transactions" },
            { key:"twoFactor",          label:"Two-Factor Auth",          desc:"Require OTP for admin logins" },
            { key:"autoSettle",         label:"Auto Settlement",          desc:"Automatically settle pending balances" },
          ].map(({ key, label, desc })=>(
            <Grid item xs={12} sm={6} key={key}>
              <Box sx={{ display:"flex",justifyContent:"space-between",alignItems:"center",py:1.5,px:1,borderRadius:"10px","&:hover":{background:"#f8faff"} }}>
                <Box>
                  <Typography sx={{ fontSize:14,fontWeight:600,color:C.text1 }}>{label}</Typography>
                  <Typography sx={{ fontSize:12,color:C.text3 }}>{desc}</Typography>
                </Box>
                <Switch checked={!!toggles[key]} onChange={e=>setToggles({...toggles,[key]:e.target.checked})}
                  sx={{ "& .MuiSwitch-switchBase.Mui-checked":{ color:A },
                        "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track":{ background:A } }}/>
              </Box>
            </Grid>
          ))}
        </Grid>
      </Section>

      <Snackbar open={toast.open} autoHideDuration={3500} onClose={()=>setToast({...toast,open:false})}
        anchorOrigin={{ vertical:"bottom",horizontal:"right" }}>
        <Alert severity={toast.sev} sx={{ borderRadius:"10px" }}>{toast.msg}</Alert>
      </Snackbar>
    </Box>
  );
}
