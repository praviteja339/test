import { useState, useEffect, useCallback } from "react";
import {
  Box, Typography, Paper, Chip, Avatar, Button, TextField, Dialog,
  DialogTitle, DialogContent, DialogActions, Select, MenuItem,
  InputAdornment, Grid, CircularProgress, Alert, Snackbar, IconButton, Tooltip,
} from "@mui/material";
import { Search, Add, Edit, Block, CheckCircle, Refresh } from "@mui/icons-material";
import { getAllUsers, createUser, updateUserStatus } from "../services/adminApi";

const A = "#dc2626";
const C = { border:"#e5eaf5", text1:"#0f1623", text2:"#3a4563", text3:"#7a8aab" };

const TYPE_LABEL = { A:"Admin", S:"Super Dist.", D:"Distributor", R:"Retailer/Agent", E:"Employee" };
const roleColor = {
  "Admin":         { bg:"#fef2f2", color:A },
  "Super Dist.":   { bg:"#ede9fe", color:"#7c3aed" },
  "Distributor":   { bg:"#e8efff", color:"#1a56db" },
  "Retailer/Agent":{ bg:"#ecfdf5", color:"#059669" },
  "Employee":      { bg:"#f3f4f6", color:"#374151" },
};
const statusCfg = {
  active:    { label:"Active",    bg:"#ecfdf5", color:"#059669" },
  suspended: { label:"Suspended", bg:"#fef2f2", color:A        },
  locked:    { label:"Locked",    bg:"#fef2f2", color:A        },
  inactive:  { label:"Inactive",  bg:"#f3f4f6", color:"#6b7280"},
};

const userStatus = (u) => u.isLocked ? "suspended" : "active";

export default function UserManagement() {
  const [users,       setUsers]       = useState([]);
  const [loading,     setLoading]     = useState(true);
  const [error,       setError]       = useState(null);
  const [toast,       setToast]       = useState({ open:false, msg:"", sev:"success" });
  const [search,      setSearch]      = useState("");
  const [roleFilter,  setRoleFilter]  = useState("All");
  const [statusFilter,setStatusFilter]= useState("All");
  const [editOpen,    setEditOpen]    = useState(false);
  const [editUser,    setEditUser]    = useState(null);
  const [addOpen,     setAddOpen]     = useState(false);
  const [saving,      setSaving]      = useState(false);
  const [newUser,     setNewUser]     = useState({ userName:"", registeredMobileNo:"", emailId:"", uType:"R", city:"", area:"" });

  const showToast = (msg, sev="success") => setToast({ open:true, msg, sev });

  const loadUsers = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const res = await getAllUsers();
      setUsers(Array.isArray(res.data.data) ? res.data.data : []);
    } catch {
      setError("Failed to load users. Please retry.");
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { loadUsers(); }, [loadUsers]);

  const filtered = users.filter(u => {
    const role = TYPE_LABEL[u.uType] || u.uType;
    const st   = userStatus(u);
    return (
      (search === "" || (u.userName||"").toLowerCase().includes(search.toLowerCase()) ||
        (u.emailId||"").toLowerCase().includes(search.toLowerCase()) || String(u.id).includes(search)) &&
      (roleFilter === "All" || role === roleFilter) &&
      (statusFilter === "All" || st === statusFilter.toLowerCase())
    );
  });

  const handleToggleStatus = async (u) => {
    const current = userStatus(u);
    const next    = current === "active" ? "SUSPENDED" : "ACTIVE";
    try {
      await updateUserStatus(u.id, next);
      showToast(`User ${next === "ACTIVE" ? "activated" : "suspended"} successfully.`);
      loadUsers();
    } catch { showToast("Failed to update user status.", "error"); }
  };

  const handleAddUser = async () => {
    setSaving(true);
    try {
      await createUser({ ...newUser, uPassword: "Welcome@123" });
      showToast("User created successfully.");
      setAddOpen(false);
      setNewUser({ userName:"", registeredMobileNo:"", emailId:"", uType:"R", city:"", area:"" });
      loadUsers();
    } catch (e) {
      showToast(e?.response?.data?.error || "Failed to create user.", "error");
    } finally { setSaving(false); }
  };

  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb:3, display:"flex", alignItems:"flex-start", justifyContent:"space-between", flexWrap:"wrap", gap:2 }}>
        <Box>
          <Typography sx={{ fontSize:22, fontWeight:800, color:C.text1 }}>User Management</Typography>
          <Typography sx={{ fontSize:13, color:C.text3 }}>
            {users.length} total users · {users.filter(u=>!u.isLocked).length} active
          </Typography>
        </Box>
        <Box sx={{ display:"flex", gap:1 }}>
          <Tooltip title="Refresh">
            <IconButton onClick={loadUsers} sx={{ border:`1px solid ${C.border}`, borderRadius:"10px" }}>
              <Refresh fontSize="small"/>
            </IconButton>
          </Tooltip>
          <Button startIcon={<Add/>} variant="contained" onClick={()=>setAddOpen(true)}
            sx={{ background:A, borderRadius:"10px", textTransform:"none", fontWeight:700, "&:hover":{ background:"#b91c1c" } }}>
            Add User
          </Button>
        </Box>
      </Box>

      {error && <Alert severity="error" sx={{ mb:2, borderRadius:"10px" }}>{error}</Alert>}

      {/* Filters */}
      <Paper elevation={0} sx={{ p:2, mb:2.5, borderRadius:"14px", border:`1px solid ${C.border}`, display:"flex", gap:2, flexWrap:"wrap" }}>
        <TextField size="small" placeholder="Search by name, email, ID…" value={search} onChange={e=>setSearch(e.target.value)}
          InputProps={{ startAdornment:<InputAdornment position="start"><Search fontSize="small"/></InputAdornment> }}
          sx={{ flex:1, minWidth:200, "& .MuiOutlinedInput-root":{ borderRadius:"10px" } }}/>
        <Select size="small" value={roleFilter} onChange={e=>setRoleFilter(e.target.value)}
          sx={{ minWidth:160, borderRadius:"10px" }}>
          <MenuItem value="All">All Roles</MenuItem>
          {Object.values(TYPE_LABEL).map(r=><MenuItem key={r} value={r}>{r}</MenuItem>)}
        </Select>
        <Select size="small" value={statusFilter} onChange={e=>setStatusFilter(e.target.value)}
          sx={{ minWidth:140, borderRadius:"10px" }}>
          {["All","Active","Suspended"].map(s=><MenuItem key={s} value={s}>{s}</MenuItem>)}
        </Select>
      </Paper>

      {/* Table */}
      <Paper elevation={0} sx={{ borderRadius:"16px", border:`1px solid ${C.border}`, overflow:"hidden" }}>
        {/* Header row */}
        <Box sx={{ display:"grid", gridTemplateColumns:"1fr 1.2fr 1fr 0.8fr 0.7fr 0.7fr", gap:1,
          px:2.5, py:1.5, background:"#f8faff", borderBottom:`1px solid ${C.border}` }}>
          {["User","Contact","Role","Status","Balance","Actions"].map(h=>(
            <Typography key={h} sx={{ fontSize:11,fontWeight:700,color:C.text3,textTransform:"uppercase",letterSpacing:"0.05em" }}>{h}</Typography>
          ))}
        </Box>

        {loading ? (
          <Box sx={{ p:6, textAlign:"center" }}><CircularProgress sx={{ color:A }}/></Box>
        ) : filtered.length === 0 ? (
          <Box sx={{ p:6, textAlign:"center" }}>
            <Typography sx={{ color:C.text3 }}>No users match the current filters.</Typography>
          </Box>
        ) : filtered.map(u => {
          const role = TYPE_LABEL[u.uType] || u.uType;
          const rc   = roleColor[role] || { bg:"#f3f4f6", color:"#374151" };
          const st   = userStatus(u);
          const sc   = statusCfg[st] || statusCfg.inactive;
          return (
            <Box key={u.id} sx={{ display:"grid", gridTemplateColumns:"1fr 1.2fr 1fr 0.8fr 0.7fr 0.7fr",
              gap:1, px:2.5, py:1.8, borderBottom:`1px solid ${C.border}`,
              "&:hover":{ background:"#fafbff" }, alignItems:"center" }}>
              <Box sx={{ display:"flex", alignItems:"center", gap:1.2 }}>
                <Avatar sx={{ width:34,height:34,fontSize:13,bgcolor:rc.bg,color:rc.color,fontWeight:700 }}>
                  {(u.userName||"?")[0].toUpperCase()}
                </Avatar>
                <Box>
                  <Typography sx={{ fontSize:13,fontWeight:700,color:C.text1 }}>{u.userName}</Typography>
                  <Typography sx={{ fontSize:11,color:C.text3 }}>#{u.id}</Typography>
                </Box>
              </Box>
              <Box>
                <Typography sx={{ fontSize:12,color:C.text2 }}>{u.registeredMobileNo}</Typography>
                <Typography sx={{ fontSize:11,color:C.text3 }}>{u.emailId||"—"}</Typography>
              </Box>
              <Chip label={role} size="small" sx={{ background:rc.bg,color:rc.color,fontWeight:600,fontSize:11 }}/>
              <Chip label={sc.label} size="small" sx={{ background:sc.bg,color:sc.color,fontWeight:600,fontSize:11 }}/>
              <Typography sx={{ fontSize:13,fontWeight:700,color:C.text1 }}>
                ₹{Number(u.balance||0).toLocaleString("en-IN",{minimumFractionDigits:2})}
              </Typography>
              <Box sx={{ display:"flex", gap:0.5 }}>
                <Tooltip title="Edit">
                  <IconButton size="small" onClick={()=>{ setEditUser({...u}); setEditOpen(true); }}>
                    <Edit fontSize="small" sx={{ color:C.text3 }}/>
                  </IconButton>
                </Tooltip>
                <Tooltip title={st==="active"?"Suspend":"Activate"}>
                  <IconButton size="small" onClick={()=>handleToggleStatus(u)}>
                    {st==="active"
                      ? <Block fontSize="small" sx={{ color:A }}/>
                      : <CheckCircle fontSize="small" sx={{ color:"#059669" }}/>}
                  </IconButton>
                </Tooltip>
              </Box>
            </Box>
          );
        })}

        <Box sx={{ px:2.5,py:1.5,borderTop:`1px solid ${C.border}` }}>
          <Typography sx={{ fontSize:12,color:C.text3 }}>Showing {filtered.length} of {users.length} users</Typography>
        </Box>
      </Paper>

      {/* Add User Dialog */}
      <Dialog open={addOpen} onClose={()=>setAddOpen(false)} maxWidth="sm" fullWidth
        PaperProps={{ sx:{ borderRadius:"16px" } }}>
        <DialogTitle sx={{ fontWeight:800,color:C.text1 }}>Add New User</DialogTitle>
        <DialogContent dividers>
          <Grid container spacing={2} sx={{ pt:1 }}>
            {[
              { label:"Username",    key:"userName",           type:"text" },
              { label:"Mobile",      key:"registeredMobileNo", type:"text" },
              { label:"Email",       key:"emailId",            type:"email" },
              { label:"City",        key:"city",               type:"text" },
              { label:"Area",        key:"area",               type:"text" },
            ].map(f=>(
              <Grid item xs={12} sm={6} key={f.key}>
                <TextField label={f.label} type={f.type} value={newUser[f.key]} fullWidth size="small"
                  onChange={e=>setNewUser({...newUser,[f.key]:e.target.value})}
                  sx={{ "& .MuiOutlinedInput-root":{ borderRadius:"10px" } }}/>
              </Grid>
            ))}
            <Grid item xs={12} sm={6}>
              <Select size="small" fullWidth value={newUser.uType}
                onChange={e=>setNewUser({...newUser,uType:e.target.value})}
                sx={{ borderRadius:"10px" }}>
                {Object.entries(TYPE_LABEL).filter(([k])=>k!=="A").map(([k,v])=>(
                  <MenuItem key={k} value={k}>{v}</MenuItem>
                ))}
              </Select>
            </Grid>
          </Grid>
          <Typography sx={{ fontSize:11,color:C.text3,mt:2 }}>Default password: <strong>Welcome@123</strong></Typography>
        </DialogContent>
        <DialogActions sx={{ p:2.5,gap:1 }}>
          <Button onClick={()=>setAddOpen(false)} sx={{ textTransform:"none",borderRadius:"10px" }}>Cancel</Button>
          <Button onClick={handleAddUser} variant="contained" disabled={saving}
            sx={{ background:A,borderRadius:"10px",textTransform:"none",fontWeight:700,"&:hover":{background:"#b91c1c"} }}>
            {saving ? <CircularProgress size={18} sx={{ color:"#fff" }}/> : "Create User"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Edit User Dialog */}
      <Dialog open={editOpen} onClose={()=>setEditOpen(false)} maxWidth="sm" fullWidth
        PaperProps={{ sx:{ borderRadius:"16px" } }}>
        <DialogTitle sx={{ fontWeight:800,color:C.text1 }}>Edit User</DialogTitle>
        <DialogContent dividers>
          {editUser && (
            <Grid container spacing={2} sx={{ pt:1 }}>
              <Grid item xs={12}><TextField label="Username" value={editUser.userName||""} fullWidth size="small"
                onChange={e=>setEditUser({...editUser,userName:e.target.value})}
                sx={{ "& .MuiOutlinedInput-root":{ borderRadius:"10px" } }}/></Grid>
              <Grid item xs={12}><TextField label="Email" value={editUser.emailId||""} fullWidth size="small"
                onChange={e=>setEditUser({...editUser,emailId:e.target.value})}
                sx={{ "& .MuiOutlinedInput-root":{ borderRadius:"10px" } }}/></Grid>
              <Grid item xs={12}><TextField label="City" value={editUser.city||""} fullWidth size="small"
                onChange={e=>setEditUser({...editUser,city:e.target.value})}
                sx={{ "& .MuiOutlinedInput-root":{ borderRadius:"10px" } }}/></Grid>
            </Grid>
          )}
        </DialogContent>
        <DialogActions sx={{ p:2.5,gap:1 }}>
          <Button onClick={()=>setEditOpen(false)} sx={{ textTransform:"none",borderRadius:"10px" }}>Cancel</Button>
          <Button variant="contained" onClick={()=>{ showToast("User updated (wire PUT /users/{id} when needed)."); setEditOpen(false); }}
            sx={{ background:A,borderRadius:"10px",textTransform:"none",fontWeight:700,"&:hover":{background:"#b91c1c"} }}>
            Save
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar open={toast.open} autoHideDuration={3500} onClose={()=>setToast({...toast,open:false})}
        anchorOrigin={{ vertical:"bottom",horizontal:"right" }}>
        <Alert severity={toast.sev} sx={{ borderRadius:"10px" }}>{toast.msg}</Alert>
      </Snackbar>
    </Box>
  );
}
