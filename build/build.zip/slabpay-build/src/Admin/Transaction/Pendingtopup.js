import { useState, useEffect, useCallback } from "react";
import {
  Box, Typography, Paper, Chip, Button, TextField, Select, MenuItem,
  InputAdornment, CircularProgress, Alert, Snackbar, IconButton, Tooltip, Dialog,
  DialogTitle, DialogContent, DialogActions,
} from "@mui/material";
import { Search, CheckCircle, Cancel, Refresh, Visibility } from "@mui/icons-material";
import { getPendingTopUps, approveTopUp, rejectTopUp } from "../../services/adminApi";

const A = "#dc2626";
const C = { border:"#e5eaf5", text1:"#0f1623", text2:"#3a4563", text3:"#7a8aab" };
const statusCfg = {
  PENDING:  { label:"Pending",  bg:"#fffbeb", color:"#d97706" },
  APPROVED: { label:"Approved", bg:"#ecfdf5", color:"#059669" },
  REJECTED: { label:"Rejected", bg:"#fef2f2", color:A         },
};

export default function Pendingtopup() {
  const [data,       setData]       = useState([]);
  const [loading,    setLoading]    = useState(true);
  const [toast,      setToast]      = useState({ open:false, msg:"", sev:"success" });
  const [search,     setSearch]     = useState("");
  const [rejectOpen, setRejectOpen] = useState(false);
  const [rejectId,   setRejectId]   = useState(null);
  const [rejectNote, setRejectNote] = useState("");
  const [detailOpen, setDetailOpen] = useState(false);
  const [detail,     setDetail]     = useState(null);
  const adminId = localStorage.getItem("userId") || "1";

  const showToast = (msg, sev="success") => setToast({ open:true, msg, sev });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getPendingTopUps(adminId);
      setData(Array.isArray(res.data.data) ? res.data.data : []);
    } catch { showToast("Failed to load pending top-ups.", "error"); }
    finally { setLoading(false); }
  }, [adminId]);

  useEffect(() => { load(); }, [load]);

  const handleApprove = async (id) => {
    try { await approveTopUp(id); showToast("Top-up approved."); load(); }
    catch { showToast("Failed to approve.", "error"); }
  };

  const handleReject = async () => {
    try { await rejectTopUp(rejectId, { reason: rejectNote }); showToast("Top-up rejected."); setRejectOpen(false); setRejectNote(""); load(); }
    catch { showToast("Failed to reject.", "error"); }
  };

  const fmt = (n) => n == null ? "₹0.00" : "₹" + Number(n).toLocaleString("en-IN",{ minimumFractionDigits:2 });

  const filtered = data.filter(r =>
    search==="" || String(r.id).includes(search) ||
    (r.requesterUsername||"").toLowerCase().includes(search.toLowerCase())
  );

  return (
    <Box>
      <Box sx={{ mb:3,display:"flex",alignItems:"flex-start",justifyContent:"space-between",flexWrap:"wrap",gap:2 }}>
        <Box>
          <Typography sx={{ fontSize:22,fontWeight:800,color:C.text1 }}>Pending Top-ups</Typography>
          <Typography sx={{ fontSize:13,color:C.text3 }}>{data.length} request(s) awaiting approval</Typography>
        </Box>
        <Tooltip title="Refresh"><IconButton onClick={load} sx={{ border:`1px solid ${C.border}`,borderRadius:"10px" }}><Refresh fontSize="small"/></IconButton></Tooltip>
      </Box>

      <Paper elevation={0} sx={{ p:2,mb:2.5,borderRadius:"14px",border:`1px solid ${C.border}` }}>
        <TextField size="small" placeholder="Search by ID or requester…" value={search} onChange={e=>setSearch(e.target.value)} fullWidth
          InputProps={{ startAdornment:<InputAdornment position="start"><Search fontSize="small"/></InputAdornment> }}
          sx={{ "& .MuiOutlinedInput-root":{ borderRadius:"10px" } }}/>
      </Paper>

      <Paper elevation={0} sx={{ borderRadius:"16px",border:`1px solid ${C.border}`,overflow:"hidden" }}>
        <Box sx={{ display:"grid",gridTemplateColumns:"0.6fr 1fr 1fr 0.8fr 0.8fr 0.8fr 1fr",gap:1,
          px:2.5,py:1.5,background:"#f8faff",borderBottom:`1px solid ${C.border}` }}>
          {["ID","Requester","Type","Amount","Status","Date","Actions"].map(h=>(
            <Typography key={h} sx={{ fontSize:11,fontWeight:700,color:C.text3,textTransform:"uppercase",letterSpacing:"0.05em" }}>{h}</Typography>
          ))}
        </Box>

        {loading ? (
          <Box sx={{ p:6,textAlign:"center" }}><CircularProgress sx={{ color:A }}/></Box>
        ) : filtered.length===0 ? (
          <Box sx={{ p:6,textAlign:"center" }}><Typography sx={{ color:C.text3 }}>No pending top-ups.</Typography></Box>
        ) : filtered.map(r=>{
          const sc = statusCfg[r.status]||statusCfg.PENDING;
          const isPending = r.status==="PENDING";
          return (
            <Box key={r.id} sx={{ display:"grid",gridTemplateColumns:"0.6fr 1fr 1fr 0.8fr 0.8fr 0.8fr 1fr",
              gap:1,px:2.5,py:1.8,borderBottom:`1px solid ${C.border}`,"&:hover":{background:"#fafbff"},alignItems:"center" }}>
              <Typography sx={{ fontSize:12,color:C.text3,fontFamily:"monospace" }}>#{r.id}</Typography>
              <Box>
                <Typography sx={{ fontSize:13,fontWeight:700,color:C.text1 }}>{r.requesterUsername||"—"}</Typography>
                <Typography sx={{ fontSize:11,color:C.text3 }}>{r.requesterType||"—"}</Typography>
              </Box>
              <Typography sx={{ fontSize:12,color:C.text2 }}>{r.paymentMode||r.topupType||"—"}</Typography>
              <Typography sx={{ fontSize:13,fontWeight:700,color:C.text1 }}>{fmt(r.amount)}</Typography>
              <Chip label={sc.label} size="small" sx={{ background:sc.bg,color:sc.color,fontWeight:600,fontSize:11 }}/>
              <Typography sx={{ fontSize:12,color:C.text3 }}>{r.requestDate ? new Date(r.requestDate).toLocaleDateString("en-IN") : "—"}</Typography>
              <Box sx={{ display:"flex",gap:0.5 }}>
                <Tooltip title="View"><IconButton size="small" onClick={()=>{ setDetail(r); setDetailOpen(true); }}><Visibility fontSize="small" sx={{ color:C.text3 }}/></IconButton></Tooltip>
                {isPending && <>
                  <Tooltip title="Approve"><IconButton size="small" onClick={()=>handleApprove(r.id)}><CheckCircle fontSize="small" sx={{ color:"#059669" }}/></IconButton></Tooltip>
                  <Tooltip title="Reject"><IconButton size="small" onClick={()=>{ setRejectId(r.id); setRejectOpen(true); }}><Cancel fontSize="small" sx={{ color:A }}/></IconButton></Tooltip>
                </>}
              </Box>
            </Box>
          );
        })}
        <Box sx={{ px:2.5,py:1.5,borderTop:`1px solid ${C.border}` }}>
          <Typography sx={{ fontSize:12,color:C.text3 }}>Showing {filtered.length} of {data.length}</Typography>
        </Box>
      </Paper>

      {/* Reject Dialog */}
      <Dialog open={rejectOpen} onClose={()=>setRejectOpen(false)} maxWidth="xs" fullWidth PaperProps={{ sx:{ borderRadius:"16px" } }}>
        <DialogTitle sx={{ fontWeight:800,color:C.text1 }}>Reject Top-up</DialogTitle>
        <DialogContent dividers>
          <TextField label="Rejection Reason" multiline rows={3} fullWidth size="small" value={rejectNote}
            onChange={e=>setRejectNote(e.target.value)} sx={{ "& .MuiOutlinedInput-root":{ borderRadius:"10px" } }}/>
        </DialogContent>
        <DialogActions sx={{ p:2,gap:1 }}>
          <Button onClick={()=>setRejectOpen(false)} sx={{ textTransform:"none",borderRadius:"10px" }}>Cancel</Button>
          <Button onClick={handleReject} variant="contained" sx={{ background:A,borderRadius:"10px",textTransform:"none",fontWeight:700,"&:hover":{background:"#b91c1c"} }}>Reject</Button>
        </DialogActions>
      </Dialog>

      {/* Detail Dialog */}
      <Dialog open={detailOpen} onClose={()=>setDetailOpen(false)} maxWidth="sm" fullWidth PaperProps={{ sx:{ borderRadius:"16px" } }}>
        <DialogTitle sx={{ fontWeight:800,color:C.text1 }}>Top-up Details #{detail?.id}</DialogTitle>
        <DialogContent dividers>
          {detail && Object.entries({
            "Requester": detail.requesterUsername, "Amount": fmt(detail.amount),
            "Payment Mode": detail.paymentMode||"—", "UTR / Ref": detail.utrNumber||"—",
            "Status": detail.status, "Requested On": detail.requestDate ? new Date(detail.requestDate).toLocaleString("en-IN") : "—",
            "Remarks": detail.remarks||"—",
          }).map(([k,v])=>(
            <Box key={k} sx={{ display:"flex",justifyContent:"space-between",py:1,borderBottom:"1px solid #f0f0f0" }}>
              <Typography sx={{ fontSize:13,color:C.text3 }}>{k}</Typography>
              <Typography sx={{ fontSize:13,fontWeight:600,color:C.text1 }}>{v}</Typography>
            </Box>
          ))}
        </DialogContent>
        <DialogActions sx={{ p:2 }}><Button onClick={()=>setDetailOpen(false)} sx={{ textTransform:"none",borderRadius:"10px" }}>Close</Button></DialogActions>
      </Dialog>

      <Snackbar open={toast.open} autoHideDuration={3500} onClose={()=>setToast({...toast,open:false})} anchorOrigin={{ vertical:"bottom",horizontal:"right" }}>
        <Alert severity={toast.sev} sx={{ borderRadius:"10px" }}>{toast.msg}</Alert>
      </Snackbar>
    </Box>
  );
}
