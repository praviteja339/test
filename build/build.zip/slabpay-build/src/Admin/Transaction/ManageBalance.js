import { useState, useEffect, useCallback } from "react";
import {
  Box, Typography, TextField, MenuItem, Paper, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, Chip, IconButton, Tooltip,
  InputAdornment, Grid, CircularProgress, Alert, Snackbar, Button,
} from "@mui/material";
import RefreshIcon from "@mui/icons-material/Refresh";
import SearchIcon from "@mui/icons-material/Search";
import DownloadIcon from "@mui/icons-material/Download";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";
import { getDistTransfers, getAllUsers } from "../../services/adminApi";

const C = {
  border: "#e5eaf5", text1: "#0f1623", text2: "#3a4563", text3: "#7a8aab",
  primary: "#dc2626",
};

const userTypeConfig = {
  Company:     { color: "#2563eb", bg: "#eff6ff", border: "#bfdbfe" },
  Admin:       { color: "#2563eb", bg: "#eff6ff", border: "#bfdbfe" },
  Retailer:    { color: "#059669", bg: "#f0fdf4", border: "#bbf7d0" },
  Distributor: { color: "#7c3aed", bg: "#f5f3ff", border: "#ddd6fe" },
  SuperDist:   { color: "#d97706", bg: "#fffbeb", border: "#fde68a" },
};

const cfgFor = (type) => userTypeConfig[type] || { color: "#374151", bg: "#f3f4f6", border: "#e5e7eb" };

const fmt = (n) => n == null ? "₹0.00" : "₹" + Number(n).toLocaleString("en-IN", { minimumFractionDigits: 2 });

const downloadCSV = (rows) => {
  const cols = ["ID","Dr Type","Dr User","Cr Type","Cr User","Amount","Date"];
  const lines = [cols.join(","), ...rows.map(r =>
    [r.id, r.drType||"—", r.drUsername||"—", r.crType||"—", r.crUsername||"—", r.amount, r.createdDate||"—"].join(","))];
  const blob = new Blob([lines.join("\n")], { type: "text/csv" });
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob);
  a.download = "balance_transfers.csv"; a.click();
};

export default function ManageBalance() {
  const [rows,      setRows]      = useState([]);
  const [loading,   setLoading]   = useState(true);
  const [toast,     setToast]     = useState({ open: false, msg: "", sev: "success" });
  const [search,    setSearch]    = useState("");
  const [distId,    setDistId]    = useState("all");
  const [dists,     setDists]     = useState([]);

  const adminId = localStorage.getItem("userId") || "1";

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [tRes, uRes] = await Promise.all([
        getDistTransfers(distId === "all" ? adminId : distId),
        getAllUsers(),
      ]);
      const entries = Array.isArray(tRes.data?.data) ? tRes.data.data :
                      Array.isArray(tRes.data?.data?.entries) ? tRes.data.data.entries : [];
      setRows(entries);
      const users = Array.isArray(uRes.data?.data) ? uRes.data.data : [];
      setDists(users.filter(u => u.uType === "D" || u.uType === "S"));
    } catch {
      setToast({ open: true, msg: "Failed to load balance transfers.", sev: "error" });
    } finally { setLoading(false); }
  }, [distId, adminId]);

  useEffect(() => { load(); }, [load]);

  const filtered = rows.filter(r => {
    const q = search.toLowerCase();
    return !search ||
      (r.drUsername||"").toLowerCase().includes(q) ||
      (r.crUsername||"").toLowerCase().includes(q) ||
      String(r.id).includes(q);
  });

  const totalAmt = filtered.reduce((s, r) => s + Number(r.amount || 0), 0);

  return (
    <Box>
      <Box sx={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", mb: 3, flexWrap: "wrap", gap: 2 }}>
        <Box>
          <Typography sx={{ fontSize: 22, fontWeight: 800, color: C.text1 }}>Manage Balance</Typography>
          <Typography sx={{ fontSize: 13, color: C.text3 }}>View all balance transfers across the network</Typography>
        </Box>
        <Box sx={{ display: "flex", gap: 1 }}>
          <Tooltip title="Refresh">
            <IconButton onClick={load} disabled={loading} sx={{ border: `1px solid ${C.border}`, borderRadius: "10px" }}>
              <RefreshIcon fontSize="small" />
            </IconButton>
          </Tooltip>
          <Button startIcon={<DownloadIcon />} variant="outlined" onClick={() => downloadCSV(filtered)}
            sx={{ borderRadius: "10px", textTransform: "none", borderColor: C.border, color: C.text2 }}>
            Export CSV
          </Button>
        </Box>
      </Box>

      {/* Summary cards */}
      <Grid container spacing={2} sx={{ mb: 3 }}>
        {[
          { label: "Total Records",        value: filtered.length,       color: "#1a56db", bg: "#e8efff", icon: <AccountBalanceWalletIcon sx={{ fontSize: 20 }} /> },
          { label: "Total Transfer Amount", value: fmt(totalAmt),        color: "#059669", bg: "#ecfdf5", icon: <AccountBalanceWalletIcon sx={{ fontSize: 20 }} /> },
        ].map(c => (
          <Grid item xs={12} sm={6} key={c.label}>
            <Paper elevation={0} sx={{ p: 2.5, borderRadius: "14px", border: `1px solid ${C.border}`, display: "flex", alignItems: "center", gap: 2 }}>
              <Box sx={{ width: 44, height: 44, borderRadius: "12px", background: c.bg, display: "flex", alignItems: "center", justifyContent: "center", color: c.color }}>
                {c.icon}
              </Box>
              <Box>
                <Typography sx={{ fontSize: 11, fontWeight: 700, color: C.text3, textTransform: "uppercase", letterSpacing: "0.05em" }}>{c.label}</Typography>
                <Typography sx={{ fontSize: 20, fontWeight: 800, color: C.text1 }}>{c.value}</Typography>
              </Box>
            </Paper>
          </Grid>
        ))}
      </Grid>

      {/* Filters */}
      <Paper elevation={0} sx={{ p: 2, mb: 2.5, borderRadius: "14px", border: `1px solid ${C.border}`, display: "flex", gap: 2, flexWrap: "wrap" }}>
        <TextField size="small" placeholder="Search by user or ID…" value={search} onChange={e => setSearch(e.target.value)}
          InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }}
          sx={{ flex: 1, minWidth: 220, "& .MuiOutlinedInput-root": { borderRadius: "10px" } }} />
        <TextField select size="small" value={distId} onChange={e => setDistId(e.target.value)}
          sx={{ minWidth: 200, "& .MuiOutlinedInput-root": { borderRadius: "10px" } }}>
          <MenuItem value="all">All Distributors</MenuItem>
          {dists.map(d => <MenuItem key={d.id} value={d.id}>{d.userName} ({d.uType})</MenuItem>)}
        </TextField>
      </Paper>

      {/* Table */}
      <Paper elevation={0} sx={{ borderRadius: "16px", border: `1px solid ${C.border}`, overflow: "hidden" }}>
        <TableContainer>
          <Table>
            <TableHead sx={{ background: "#f8faff" }}>
              <TableRow>
                {["ID", "Dr Type", "Debit User", "Cr Type", "Credit User", "Amount", "Date"].map(h => (
                  <TableCell key={h} sx={{ fontWeight: 700, color: C.text3, fontSize: 11, textTransform: "uppercase", letterSpacing: "0.05em" }}>{h}</TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow><TableCell colSpan={7} align="center" sx={{ py: 6 }}><CircularProgress sx={{ color: C.primary }} /></TableCell></TableRow>
              ) : filtered.length === 0 ? (
                <TableRow><TableCell colSpan={7} align="center" sx={{ py: 6, color: C.text3 }}>No transfers found.</TableCell></TableRow>
              ) : filtered.map((row, i) => {
                const drCfg = cfgFor(row.drType || "Company");
                const crCfg = cfgFor(row.crType || "Retailer");
                return (
                  <TableRow key={row.id || i} hover>
                    <TableCell sx={{ fontSize: 12, color: C.text3, fontFamily: "monospace" }}>#{row.id}</TableCell>
                    <TableCell>
                      <Chip label={row.drType || "—"} size="small"
                        sx={{ background: drCfg.bg, color: drCfg.color, border: `1px solid ${drCfg.border}`, fontWeight: 700, fontSize: 11 }} />
                    </TableCell>
                    <TableCell>
                      <Typography sx={{ fontWeight: 600, fontSize: 13, color: C.text1 }}>{row.drUsername || "—"}</Typography>
                      <Typography sx={{ fontSize: 11, color: C.text3 }}>{row.drContact || ""}</Typography>
                    </TableCell>
                    <TableCell>
                      <Chip label={row.crType || "—"} size="small"
                        sx={{ background: crCfg.bg, color: crCfg.color, border: `1px solid ${crCfg.border}`, fontWeight: 700, fontSize: 11 }} />
                    </TableCell>
                    <TableCell>
                      <Typography sx={{ fontWeight: 600, fontSize: 13, color: C.text1 }}>{row.crUsername || "—"}</Typography>
                      <Typography sx={{ fontSize: 11, color: C.text3 }}>{row.crContact || ""}</Typography>
                    </TableCell>
                    <TableCell>
                      <Typography sx={{ fontWeight: 800, fontSize: 14, color: "#059669" }}>{fmt(row.amount)}</Typography>
                    </TableCell>
                    <TableCell sx={{ color: C.text3, fontSize: 12.5, whiteSpace: "nowrap" }}>
                      {row.createdDate ? new Date(row.createdDate).toLocaleString("en-IN") : "—"}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
        <Box sx={{ px: 3, py: 1.5, borderTop: `1px solid ${C.border}`, display: "flex", justifyContent: "space-between", background: "#fafafa" }}>
          <Typography sx={{ fontSize: 12, color: C.text3 }}>Showing {filtered.length} of {rows.length} records</Typography>
          <Typography sx={{ fontSize: 12, color: C.text3 }}>Total: <strong>{fmt(totalAmt)}</strong></Typography>
        </Box>
      </Paper>

      <Snackbar open={toast.open} autoHideDuration={3500} onClose={() => setToast({ ...toast, open: false })} anchorOrigin={{ vertical: "bottom", horizontal: "right" }}>
        <Alert severity={toast.sev} sx={{ borderRadius: "10px" }}>{toast.msg}</Alert>
      </Snackbar>
    </Box>
  );
}
