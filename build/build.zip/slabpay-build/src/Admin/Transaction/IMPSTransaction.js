import { useState } from "react";
import {
  Box, Typography, Paper, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, Chip, TextField,
  MenuItem, Button, InputAdornment, IconButton, Tooltip, Grid,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import DownloadIcon from "@mui/icons-material/Download";
import RefreshIcon from "@mui/icons-material/Refresh";
import SwapHorizIcon from "@mui/icons-material/SwapHoriz";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import PendingIcon from "@mui/icons-material/HourglassEmpty";
import CancelIcon from "@mui/icons-material/Cancel";

const A = "#dc2626";
const C = { border: "#e5eaf5", text1: "#0f1623", text3: "#7a8aab" };

const mockData = [
  { id: "IMPS001", sender: "RAVI KUMAR", receiver: "SURESH BABU", senderAcc: "****4521", receiverAcc: "****8832", ifsc: "HDFC0001234", amount: 25000, utr: "425001234567", date: "2025-04-01 10:22", status: "Success" },
  { id: "IMPS002", sender: "SNEHA REDDY", receiver: "KAVITA NAIR", senderAcc: "****1102", receiverAcc: "****3341", ifsc: "SBI0005678", amount: 8500, utr: "425001234568", date: "2025-04-01 12:05", status: "Success" },
  { id: "IMPS003", sender: "MANOJ PATEL", receiver: "PRIYA SHARMA", senderAcc: "****7744", receiverAcc: "****9921", ifsc: "ICIC0002345", amount: 50000, utr: "425001234569", date: "2025-04-02 09:15", status: "Pending" },
  { id: "IMPS004", sender: "ABDUL RAHMAN", receiver: "DEEPAK JOSHI", senderAcc: "****3302", receiverAcc: "****6651", ifsc: "AXIS0003456", amount: 12000, utr: "425001234570", date: "2025-04-02 15:30", status: "Failed" },
  { id: "IMPS005", sender: "LEELA KRISHNA", receiver: "ANAND RAO", senderAcc: "****8810", receiverAcc: "****2241", ifsc: "KOTAK00567", amount: 35000, utr: "425001234571", date: "2025-04-03 08:00", status: "Success" },
];

const statusConfig = {
  Success: { color: "#059669", bg: "#ecfdf5", icon: <CheckCircleIcon sx={{ fontSize: 14 }} /> },
  Pending: { color: "#d97706", bg: "#fffbeb", icon: <PendingIcon sx={{ fontSize: 14 }} /> },
  Failed:  { color: "#dc2626", bg: "#fef2f2", icon: <CancelIcon sx={{ fontSize: 14 }} /> },
};

const summaryCards = [
  { label: "Total IMPS", value: "₹1,30,500", color: "#1a56db", bg: "#e8efff" },
  { label: "Successful", value: "₹68,500", color: "#059669", bg: "#ecfdf5" },
  { label: "Pending", value: "₹50,000", color: "#d97706", bg: "#fffbeb" },
  { label: "Failed", value: "₹12,000", color: "#dc2626", bg: "#fef2f2" },
];

export default function IMPSTransaction() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");

  const filtered = mockData.filter(r => {
    const matchSearch = r.sender.toLowerCase().includes(search.toLowerCase()) || r.utr.includes(search);
    const matchStatus = statusFilter === "All" || r.status === statusFilter;
    return matchSearch && matchStatus;
  });

  return (
    <Box>
      <Box sx={{ mb: 3 }}>
        <Typography sx={{ fontSize: 22, fontWeight: 800, color: C.text1 }}>IMPS Transactions</Typography>
        <Typography sx={{ fontSize: 13, color: C.text3 }}>Instant Money Payment Service transaction records</Typography>
      </Box>

      <Grid container spacing={2} sx={{ mb: 3 }}>
        {summaryCards.map(c => (
          <Grid item xs={6} md={3} key={c.label}>
            <Paper elevation={0} sx={{ p: 2.5, borderRadius: "14px", border: `1px solid ${C.border}`, display: "flex", alignItems: "center", gap: 2 }}>
              <Box sx={{ width: 44, height: 44, borderRadius: "12px", background: c.bg, display: "flex", alignItems: "center", justifyContent: "center", color: c.color }}>
                <SwapHorizIcon />
              </Box>
              <Box>
                <Typography sx={{ fontSize: 18, fontWeight: 800, color: C.text1 }}>{c.value}</Typography>
                <Typography sx={{ fontSize: 11, color: C.text3 }}>{c.label}</Typography>
              </Box>
            </Paper>
          </Grid>
        ))}
      </Grid>

      <Paper elevation={0} sx={{ borderRadius: "16px", border: `1px solid ${C.border}` }}>
        <Box sx={{ p: 2.5, display: "flex", gap: 2, flexWrap: "wrap", alignItems: "center", borderBottom: `1px solid ${C.border}` }}>
          <TextField size="small" placeholder="Search by sender or UTR..." value={search}
            onChange={e => setSearch(e.target.value)}
            InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 18, color: C.text3 }} /></InputAdornment> }}
            sx={{ minWidth: 280, "& .MuiOutlinedInput-root": { borderRadius: "10px" } }} />
          <TextField select size="small" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}
            sx={{ minWidth: 140, "& .MuiOutlinedInput-root": { borderRadius: "10px" } }}>
            {["All", "Success", "Pending", "Failed"].map(s => <MenuItem key={s} value={s}>{s}</MenuItem>)}
          </TextField>
          <Box sx={{ flex: 1 }} />
          <Tooltip title="Refresh"><IconButton sx={{ border: `1px solid ${C.border}`, borderRadius: "10px" }}><RefreshIcon fontSize="small" /></IconButton></Tooltip>
          <Button startIcon={<DownloadIcon />} variant="outlined" size="small"
            sx={{ borderRadius: "10px", borderColor: C.border, color: C.text1, textTransform: "none" }}>Export</Button>
        </Box>

        <TableContainer>
          <Table>
            <TableHead>
              <TableRow sx={{ "& th": { fontWeight: 700, fontSize: 12, color: C.text3, background: "#f8faff", py: 1.5 } }}>
                <TableCell>Txn ID</TableCell><TableCell>Sender</TableCell><TableCell>Receiver</TableCell>
                <TableCell>IFSC</TableCell><TableCell>UTR No.</TableCell>
                <TableCell align="right">Amount</TableCell><TableCell>Date</TableCell><TableCell>Status</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filtered.map((row) => {
                const sc = statusConfig[row.status];
                return (
                  <TableRow key={row.id} sx={{ "&:hover": { background: "#f8faff" }, "& td": { fontSize: 13, py: 1.5 } }}>
                    <TableCell sx={{ fontWeight: 600, color: A }}>{row.id}</TableCell>
                    <TableCell>
                      <Typography sx={{ fontWeight: 600, fontSize: 13 }}>{row.sender}</Typography>
                      <Typography sx={{ fontSize: 11, color: C.text3 }}>{row.senderAcc}</Typography>
                    </TableCell>
                    <TableCell>
                      <Typography sx={{ fontWeight: 600, fontSize: 13 }}>{row.receiver}</Typography>
                      <Typography sx={{ fontSize: 11, color: C.text3 }}>{row.receiverAcc}</Typography>
                    </TableCell>
                    <TableCell sx={{ fontFamily: "monospace", fontSize: 12 }}>{row.ifsc}</TableCell>
                    <TableCell sx={{ fontFamily: "monospace", fontSize: 12 }}>{row.utr}</TableCell>
                    <TableCell align="right" sx={{ fontWeight: 700 }}>₹{row.amount.toLocaleString()}</TableCell>
                    <TableCell sx={{ color: C.text3, fontSize: 12 }}>{row.date}</TableCell>
                    <TableCell>
                      <Chip icon={sc.icon} label={row.status} size="small"
                        sx={{ background: sc.bg, color: sc.color, fontWeight: 600, fontSize: 11, "& .MuiChip-icon": { color: sc.color } }} />
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>

        <Box sx={{ px: 3, py: 2, borderTop: `1px solid ${C.border}`, display: "flex", justifyContent: "space-between" }}>
          <Typography sx={{ fontSize: 13, color: C.text3 }}>Showing {filtered.length} of {mockData.length} records</Typography>
          <Typography sx={{ fontSize: 13, fontWeight: 700, color: C.text1 }}>
            Total: ₹{filtered.reduce((s, r) => s + r.amount, 0).toLocaleString()}
          </Typography>
        </Box>
      </Paper>
    </Box>
  );
}
