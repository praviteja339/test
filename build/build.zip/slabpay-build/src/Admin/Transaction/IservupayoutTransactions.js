import { useState } from "react";
import {
  Box, Typography, TextField, MenuItem, Button,
  Paper, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Chip, IconButton, Tooltip,
  InputAdornment, Breadcrumbs, Link, Grid,
} from "@mui/material";
import RefreshIcon from "@mui/icons-material/Refresh";
import DownloadIcon from "@mui/icons-material/Download";
import FilterListIcon from "@mui/icons-material/FilterList";
import SearchIcon from "@mui/icons-material/Search";
import HomeIcon from "@mui/icons-material/Home";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import PaymentsIcon from "@mui/icons-material/Payments";
import CalendarTodayIcon from "@mui/icons-material/CalendarToday";
import PendingActionsIcon from "@mui/icons-material/PendingActions";

const mockData = [
  {
    entryNo: 5779,
    date: "Jul 11 2024 12:43PM",
    retailerName: "UTTAM MANNA",
    retailerContact: "9032512253",
    mobileNo: "9030512253",
    beneficiaryName: "UTTAM COMMUNICATION",
    accountNo: "40472047590",
    ifscCode: "SBIN0009209",
    amount: 100.0,
    refDate: "Jul 20 2024 9:56PM",
    status: "Refund",
    transType: "IMPS-2",
    utrNo: "",
    refOrderId: "",
    orderId: "SP101124071112435830",
  },
  {
    entryNo: 5812,
    date: "Jul 15 2024 3:20PM",
    retailerName: "PADAMALA GURU",
    retailerContact: "7680093128",
    mobileNo: "7680093128",
    beneficiaryName: "GURU ENTERPRISES",
    accountNo: "50112345678",
    ifscCode: "HDFC0001234",
    amount: 5000.0,
    refDate: "Jul 15 2024 3:45PM",
    status: "Success",
    transType: "IMPS-1",
    utrNo: "UTR123456789",
    refOrderId: "REF001",
    orderId: "SP201124071534512345",
  },
  {
    entryNo: 5834,
    date: "Jul 18 2024 10:11AM",
    retailerName: "EDIGA SARITHA",
    retailerContact: "9866742542",
    mobileNo: "9866742542",
    beneficiaryName: "SARITHA STORES",
    accountNo: "31298765432",
    ifscCode: "ICIC0005678",
    amount: 2500.0,
    refDate: "Jul 18 2024 10:30AM",
    status: "Pending",
    transType: "NEFT",
    utrNo: "",
    refOrderId: "REF002",
    orderId: "SP301124071810112345",
  },
  {
    entryNo: 5860,
    date: "Jul 22 2024 5:45PM",
    retailerName: "TALARI ESWARAMMA",
    retailerContact: "6309153285",
    mobileNo: "6309153285",
    beneficiaryName: "ESWARAMMA TRADERS",
    accountNo: "20987654321",
    ifscCode: "SBIN0001122",
    amount: 8000.0,
    refDate: "Jul 22 2024 6:00PM",
    status: "Failed",
    transType: "IMPS-2",
    utrNo: "",
    refOrderId: "",
    orderId: "SP401124072217452345",
  },
];

const statusConfig = {
  Success: { color: "#059669", bg: "#f0fdf4", border: "#bbf7d0" },
  Pending: { color: "#d97706", bg: "#fffbeb", border: "#fde68a" },
  Failed:  { color: "#dc2626", bg: "#fef2f2", border: "#fecaca" },
  Refund:  { color: "#7c3aed", bg: "#f5f3ff", border: "#ddd6fe" },
};

const statCards = [
  { label: "Total Entries", value: 4, color: "#0891b2", bg: "#ecfeff", border: "#a5f3fc" },
  { label: "Total Amount", value: "₹15,600", color: "#059669", bg: "#f0fdf4", border: "#bbf7d0" },
  { label: "Success", value: 1, color: "#2563eb", bg: "#eff6ff", border: "#bfdbfe" },
  { label: "Pending / Failed", value: 2, color: "#d97706", bg: "#fffbeb", border: "#fde68a" },
];

export default function IServeUPayoutTransactions() {
  const [loadData, setLoadData] = useState("10");
  const [retailer, setRetailer] = useState("");
  const [status, setStatus] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [uptoDate, setUptoDate] = useState("");
  const [fromId, setFromId] = useState("");
  const [uptoId, setUptoId] = useState("");
  const [search, setSearch] = useState("");
  const [rows] = useState(mockData);

  const filtered = rows.filter((r) => {
    const q = search.toLowerCase();
    const matchStatus = !status || r.status === status;
    const matchRetailer = !retailer || r.retailerName === retailer;
    const matchSearch = !search ||
      r.retailerName.toLowerCase().includes(q) ||
      r.beneficiaryName.toLowerCase().includes(q) ||
      String(r.entryNo).includes(q) ||
      r.orderId.toLowerCase().includes(q);
    const matchFromId = !fromId || r.entryNo >= Number(fromId);
    const matchUptoId = !uptoId || r.entryNo <= Number(uptoId);
    return matchStatus && matchRetailer && matchSearch && matchFromId && matchUptoId;
  });

  const totalAmt = filtered.reduce((s, r) => s + r.amount, 0);

  const handleReset = () => {
    setRetailer(""); setStatus(""); setFromDate("");
    setUptoDate(""); setFromId(""); setUptoId(""); setSearch("");
  };

  return (
    <Box sx={{ background: "#f1f5f9", minHeight: "100vh" }}>

      <Box>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, mb: 0.5 }}>
            <Box sx={{
              width: 38, height: 38, borderRadius: "10px",
              background: "linear-gradient(135deg, #0ea5e9, #2563eb)",
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              <PendingActionsIcon sx={{ color: "#fff", fontSize: 20 }} />
            </Box>
            <Typography sx={{ fontSize: 22, fontWeight: 800, color: "#0f172a", letterSpacing: "-0.3px" }}>
              Iservu payout transactions
            </Typography>
          </Box>
        </Box>
      

      <Box sx={{ p: 3 }}>

        {/* FILTER CARD */}
        <Paper elevation={0} sx={{
          background: "#fff", borderRadius: "16px",
          border: "1px solid #e2e8f0", p: 2.5, mb: 3,
        }}>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 2.5 }}>
            <FilterListIcon sx={{ color: "#0891b2", fontSize: 18 }} />
            <Typography sx={{ fontWeight: 700, fontSize: 14, color: "#0f172a" }}>Filters</Typography>
          </Box>

          {/* ROW 1 */}
          <Box sx={{ display: "flex", gap: 2, flexWrap: "wrap", alignItems: "flex-end", mb: 2 }}>
            <Box sx={{ minWidth: 150 }}>
              <Typography sx={labelStyle}>Load Data</Typography>
              <TextField select value={loadData} onChange={(e) => setLoadData(e.target.value)}
                size="small" sx={{ ...inputStyle, width: 150 }}>
                {["10", "25", "50", "100"].map((v) => (
                  <MenuItem key={v} value={v}>{v} Records</MenuItem>
                ))}
              </TextField>
            </Box>

            <Box sx={{ flex: "0 0 auto" }}>
              <Typography sx={labelStyle}>Total Amt.</Typography>
              <Box sx={{
                height: 40, px: 2, display: "flex", alignItems: "center",
                background: "#f0fdf4", border: "1px solid #bbf7d0",
                borderRadius: "10px", minWidth: 140,
              }}>
                <Typography sx={{ fontWeight: 800, fontSize: 16, color: "#059669" }}>
                  ₹{totalAmt.toLocaleString("en-IN", { minimumFractionDigits: 2 })}{" "}
                  <span style={{ fontSize: 13, color: "#6ee7b7" }}>({filtered.length})</span>
                </Typography>
              </Box>
            </Box>

            <Box sx={{ flex: "1 1 200px" }}>
              <Typography sx={labelStyle}>Retailer</Typography>
              <TextField select value={retailer} onChange={(e) => setRetailer(e.target.value)}
                fullWidth size="small" sx={inputStyle} SelectProps={{ displayEmpty: true }}>
                <MenuItem value="">Select Retailer</MenuItem>
                {["UTTAM MANNA", "PADAMALA GURU", "EDIGA SARITHA", "TALARI ESWARAMMA"].map((r) => (
                  <MenuItem key={r} value={r}>{r}</MenuItem>
                ))}
              </TextField>
            </Box>

            <Box sx={{ flex: "1 1 160px" }}>
              <Typography sx={labelStyle}>Status</Typography>
              <TextField select value={status} onChange={(e) => setStatus(e.target.value)}
                fullWidth size="small" sx={inputStyle} SelectProps={{ displayEmpty: true }}>
                <MenuItem value="">All Status</MenuItem>
                {["Success", "Pending", "Failed", "Refund"].map((s) => (
                  <MenuItem key={s} value={s}>{s}</MenuItem>
                ))}
              </TextField>
            </Box>

            <Button onClick={() => {}} sx={{
              borderRadius: "10px", textTransform: "none", fontWeight: 600,
              fontSize: 13.5, px: 2.5, height: 40, minWidth: 44,
              background: "linear-gradient(135deg, #0891b2, #0ea5e9)",
              color: "#fff", boxShadow: "none",
              "&:hover": { background: "linear-gradient(135deg,#0e7490,#0891b2)", boxShadow: "none" },
            }}>
              <FilterListIcon sx={{ fontSize: 18 }} />
            </Button>
          </Box>

          {/* ROW 2 */}
          <Box sx={{ display: "flex", gap: 2, flexWrap: "wrap", alignItems: "flex-end" }}>
            <Box sx={{ flex: "1 1 150px" }}>
              <Typography sx={labelStyle}>From Date</Typography>
              <TextField type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)}
                size="small" fullWidth sx={inputStyle}
                InputProps={{ startAdornment: <InputAdornment position="start"><CalendarTodayIcon sx={{ fontSize: 15, color: "#94a3b8" }} /></InputAdornment> }}
                InputLabelProps={{ shrink: true }}
              />
            </Box>
            <Box sx={{ flex: "1 1 150px" }}>
              <Typography sx={labelStyle}>Upto Date</Typography>
              <TextField type="date" value={uptoDate} onChange={(e) => setUptoDate(e.target.value)}
                size="small" fullWidth sx={inputStyle}
                InputProps={{ startAdornment: <InputAdornment position="start"><CalendarTodayIcon sx={{ fontSize: 15, color: "#94a3b8" }} /></InputAdornment> }}
                InputLabelProps={{ shrink: true }}
              />
            </Box>
            <Box sx={{ flex: "1 1 140px" }}>
              <Typography sx={labelStyle}>From ID</Typography>
              <TextField value={fromId} onChange={(e) => setFromId(e.target.value)}
                placeholder="From ID" size="small" fullWidth sx={inputStyle} />
            </Box>
            <Box sx={{ flex: "1 1 140px" }}>
              <Typography sx={labelStyle}>Upto ID</Typography>
              <TextField value={uptoId} onChange={(e) => setUptoId(e.target.value)}
                placeholder="Upto ID" size="small" fullWidth sx={inputStyle} />
            </Box>
            <Box sx={{ flex: "1 1 200px" }}>
              <Typography sx={labelStyle}>Search</Typography>
              <TextField value={search} onChange={(e) => setSearch(e.target.value)}
                placeholder="Name, order ID..." size="small" fullWidth sx={inputStyle}
                InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 16, color: "#94a3b8" }} /></InputAdornment> }}
              />
            </Box>
            <Button onClick={handleReset} sx={{
              borderRadius: "10px", textTransform: "none", fontWeight: 600,
              fontSize: 13, px: 2.5, height: 40,
              color: "#64748b", border: "1px solid #e2e8f0",
              "&:hover": { background: "#f1f5f9" },
            }}>
              Reset
            </Button>
          </Box>
        </Paper>

        {/* TABLE CARD */}
        <Paper elevation={0} sx={{
          background: "#fff", borderRadius: "16px",
          border: "1px solid #e2e8f0", overflow: "hidden",
        }}>
          <Box sx={{
            px: 3, py: 2, display: "flex", alignItems: "center",
            justifyContent: "space-between", borderBottom: "1px solid #f1f5f9",
          }}>
            <Box>
              <Typography sx={{ fontWeight: 700, fontSize: 15, color: "#0f172a" }}>
                Payout Records
              </Typography>
              <Typography sx={{ fontSize: 12.5, color: "#94a3b8", mt: 0.3 }}>
                {filtered.length} entries · Total:{" "}
                <span style={{ color: "#0891b2", fontWeight: 700 }}>
                  ₹{totalAmt.toLocaleString("en-IN", { minimumFractionDigits: 2 })}
                </span>
              </Typography>
            </Box>
            <Button startIcon={<DownloadIcon />} sx={{
              borderRadius: "10px", textTransform: "none", fontWeight: 600,
              fontSize: 13, px: 2, height: 38,
              background: "#f8fafc", border: "1px solid #e2e8f0", color: "#475569",
              boxShadow: "none", "&:hover": { background: "#f1f5f9", boxShadow: "none" },
            }}>
              Export
            </Button>
          </Box>

          <TableContainer sx={{ overflowX: "auto" }}>
            <Table sx={{ minWidth: 1400 }}>
              <TableHead>
                <TableRow sx={{ background: "#f8fafc" }}>
                  {[
                    "Entry No", "Date", "Retailer Name", "Mobile No",
                    "Beneficiary Name", "Account No", "IFSC Code",
                    "Amount", "Ref. Date", "Status", "Trans Type",
                    "UTR No", "Ref. Order ID", "Order ID",
                  ].map((h) => (
                    <TableCell key={h} sx={{
                      fontSize: 11, fontWeight: 700, color: "#94a3b8",
                      letterSpacing: "0.6px", textTransform: "uppercase",
                      borderBottom: "1px solid #e2e8f0", py: 1.8,
                      whiteSpace: "nowrap",
                    }}>
                      {h}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {filtered.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={14} sx={{ textAlign: "center", py: 8, border: "none" }}>
                      <PaymentsIcon sx={{ fontSize: 40, color: "#e2e8f0", mb: 1 }} />
                      <Typography sx={{ color: "#94a3b8", fontSize: 14, fontWeight: 500 }}>
                        No records found
                      </Typography>
                      <Typography sx={{ color: "#cbd5e1", fontSize: 12 }}>
                        Adjust your filters and try again
                      </Typography>
                    </TableCell>
                  </TableRow>
                ) : (
                  filtered.map((row) => {
                    const sc = statusConfig[row.status] || statusConfig.Pending;
                    return (
                      <TableRow key={row.entryNo} sx={{
                        "&:hover": { background: "#f8fafc" },
                        transition: "background 0.15s",
                        borderBottom: "1px solid #f1f5f9",
                      }}>
                        <TableCell sx={{ py: 2 }}>
                          <Box component="span" sx={{
                            background: "linear-gradient(135deg,#ecfeff,#e0f2fe)",
                            color: "#0891b2", borderRadius: "8px",
                            px: 1.2, py: 0.5, fontSize: 12, fontWeight: 700,
                          }}>
                            {row.entryNo}
                          </Box>
                        </TableCell>
                        <TableCell sx={{ fontSize: 12.5, color: "#475569", whiteSpace: "nowrap" }}>
                          {row.date}
                        </TableCell>
                        <TableCell>
                          <Typography sx={{ fontWeight: 600, fontSize: 13, color: "#0f172a", whiteSpace: "nowrap" }}>
                            {row.retailerName}
                          </Typography>
                          <Typography sx={{ fontSize: 11, color: "#94a3b8" }}>
                            {row.retailerContact}
                          </Typography>
                        </TableCell>
                        <TableCell sx={{ fontSize: 13, color: "#475569" }}>{row.mobileNo}</TableCell>
                        <TableCell sx={{ fontWeight: 600, fontSize: 13, color: "#0f172a", whiteSpace: "nowrap" }}>
                          {row.beneficiaryName}
                        </TableCell>
                        <TableCell>
                          <Box component="span" sx={{
                            background: "#f8fafc", border: "1px solid #e2e8f0",
                            borderRadius: "6px", px: 1, py: 0.4,
                            fontSize: 12, fontWeight: 600, color: "#334155",
                            fontFamily: "monospace",
                          }}>
                            {row.accountNo}
                          </Box>
                        </TableCell>
                        <TableCell>
                          <Box component="span" sx={{
                            background: "#eff6ff", border: "1px solid #bfdbfe",
                            borderRadius: "6px", px: 1, py: 0.4,
                            fontSize: 12, fontWeight: 600, color: "#2563eb",
                            fontFamily: "monospace",
                          }}>
                            {row.ifscCode}
                          </Box>
                        </TableCell>
                        <TableCell>
                          <Typography sx={{ fontWeight: 800, fontSize: 14, color: "#059669", whiteSpace: "nowrap" }}>
                            ₹{row.amount.toLocaleString("en-IN", { minimumFractionDigits: 2 })}
                          </Typography>
                        </TableCell>
                        <TableCell sx={{ fontSize: 12, color: "#64748b", whiteSpace: "nowrap" }}>
                          {row.refDate}
                        </TableCell>
                        <TableCell>
                          <Chip label={row.status} size="small" sx={{
                            background: sc.bg, color: sc.color,
                            border: `1px solid ${sc.border}`,
                            fontWeight: 700, fontSize: 11.5,
                          }} />
                        </TableCell>
                        <TableCell>
                          <Box component="span" sx={{
                            background: "#f5f3ff", border: "1px solid #ddd6fe",
                            borderRadius: "6px", px: 1, py: 0.4,
                            fontSize: 12, fontWeight: 700, color: "#7c3aed",
                          }}>
                            {row.transType}
                          </Box>
                        </TableCell>
                        <TableCell sx={{ fontSize: 12, color: "#64748b" }}>
                          {row.utrNo || <span style={{ color: "#cbd5e1" }}>—</span>}
                        </TableCell>
                        <TableCell sx={{ fontSize: 12, color: "#64748b" }}>
                          {row.refOrderId || <span style={{ color: "#cbd5e1" }}>—</span>}
                        </TableCell>
                        <TableCell>
                          <Box component="span" sx={{
                            background: "#f8fafc", border: "1px solid #e2e8f0",
                            borderRadius: "6px", px: 1, py: 0.4,
                            fontSize: 11, fontWeight: 600, color: "#475569",
                            fontFamily: "monospace", whiteSpace: "nowrap",
                          }}>
                            {row.orderId || <span style={{ color: "#cbd5e1" }}>—</span>}
                          </Box>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </TableContainer>

          <Box sx={{
            px: 3, py: 1.5, borderTop: "1px solid #f1f5f9",
            display: "flex", justifyContent: "space-between",
            background: "#fafafa",
          }}>
            <Typography sx={{ fontSize: 12.5, color: "#94a3b8" }}>
              Showing {filtered.length} of {rows.length} records
            </Typography>
            <Typography sx={{ fontSize: 12, color: "#94a3b8" }}>
              Last updated: just now
            </Typography>
          </Box>
        </Paper>
      </Box>
    </Box>
  );
}

const labelStyle = {
  fontSize: 12.5, fontWeight: 600, color: "#64748b", mb: 0.8,
};

const inputStyle = {
  "& .MuiOutlinedInput-root": {
    background: "#f8fafc", borderRadius: "10px",
    fontSize: 13.5, color: "#0f172a",
    "& fieldset": { borderColor: "#e2e8f0" },
    "&:hover fieldset": { borderColor: "#0891b2" },
    "&.Mui-focused fieldset": { borderColor: "#0891b2" },
  },
  "& .MuiInputLabel-root": { color: "#94a3b8" },
  "& .MuiSelect-icon": { color: "#94a3b8" },
};