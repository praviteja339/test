import { useState, useEffect, useCallback } from "react";
import {
  Box, Typography, Paper, Chip, TextField, Select, MenuItem,
  InputAdornment, CircularProgress, Alert, Snackbar, IconButton, Tooltip,
} from "@mui/material";
import { Search, Refresh } from "@mui/icons-material";
import { getAllTopUps } from "../../services/adminApi";

const A = "#dc2626";
const C = { border:"#e5eaf5", text1:"#0f1623", text2:"#3a4563", text3:"#7a8aab" };
const statusCfg = {
  PENDING:  { label:"Pending",  bg:"#fffbeb", color:"#d97706" },
  APPROVED: { label:"Approved", bg:"#ecfdf5", color:"#059669" },
  REJECTED: { label:"Rejected", bg:"#fef2f2", color:A         },
};

export default function AllTopUpList() {
  const [data,         setData]         = useState([]);
  const [loading,      setLoading]      = useState(true);
  const [toast,        setToast]        = useState({ open:false, msg:"", sev:"success" });
  const [search,       setSearch]       = useState("");
  const [statusFilter, setStatusFilter] = useState("All");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getAllTopUps();
      setData(Array.isArray(res.data.data) ? res.data.data : []);
    } catch { setToast({ open:true, msg:"Failed to load top-ups.", sev:"error" }); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const fmt = (n) => n==null ? "₹0.00" : "₹"+Number(n).toLocaleString("en-IN",{minimumFractionDigits:2});

  const filtered = data.filter(r =>
    (search==="" || String(r.id).includes(search) || (r.requesterUsername||"").toLowerCase().includes(search.toLowerCase())) &&
    (statusFilter==="All" || r.status===statusFilter)
  );

  const totals = {
    APPROVED: data.filter(r=>r.status==="APPROVED").reduce((s,r)=>s+Number(r.amount||0),0),
    PENDING:  data.filter(r=>r.status==="PENDING").reduce((s,r)=>s+Number(r.amount||0),0),
  };

  return (
    <Box>
      <Box sx={{ mb:3,display:"flex",alignItems:"flex-start",justifyContent:"space-between",flexWrap:"wrap",gap:2 }}>
        <Box>
          <Typography sx={{ fontSize:22,fontWeight:800,color:C.text1 }}>All Top-up Requests</Typography>
          <Typography sx={{ fontSize:13,color:C.text3 }}>{data.length} total records</Typography>
        </Box>
        <Tooltip title="Refresh"><IconButton onClick={load} sx={{ border:`1px solid ${C.border}`,borderRadius:"10px" }}><Refresh fontSize="small"/></IconButton></Tooltip>
      </Box>

      {/* Summary chips */}
      <Box sx={{ display:"flex",gap:2,mb:2.5,flexWrap:"wrap" }}>
        {[
          { label:"Approved Amount", value:fmt(totals.APPROVED), bg:"#ecfdf5", color:"#059669" },
          { label:"Pending Amount",  value:fmt(totals.PENDING),  bg:"#fffbeb", color:"#d97706" },
          { label:"Total Records",   value:data.length,          bg:"#e8efff", color:"#1a56db" },
        ].map(c=>(
          <Paper key={c.label} elevation={0} sx={{ px:2.5,py:1.5,borderRadius:"12px",border:`1px solid ${C.border}` }}>
            <Typography sx={{ fontSize:11,color:C.text3,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.05em" }}>{c.label}</Typography>
            <Typography sx={{ fontSize:18,fontWeight:800,color:c.color }}>{c.value}</Typography>
          </Paper>
        ))}
      </Box>

      <Paper elevation={0} sx={{ p:2,mb:2.5,borderRadius:"14px",border:`1px solid ${C.border}`,display:"flex",gap:2,flexWrap:"wrap" }}>
        <TextField size="small" placeholder="Search by ID or name…" value={search} onChange={e=>setSearch(e.target.value)}
          InputProps={{ startAdornment:<InputAdornment position="start"><Search fontSize="small"/></InputAdornment> }}
          sx={{ flex:1,minWidth:200,"& .MuiOutlinedInput-root":{ borderRadius:"10px" } }}/>
        <Select size="small" value={statusFilter} onChange={e=>setStatusFilter(e.target.value)} sx={{ minWidth:140,borderRadius:"10px" }}>
          {["All","PENDING","APPROVED","REJECTED"].map(s=><MenuItem key={s} value={s}>{s}</MenuItem>)}
        </Select>
      </Paper>

      <Paper elevation={0} sx={{ borderRadius:"16px",border:`1px solid ${C.border}`,overflow:"hidden" }}>
        <Box sx={{ display:"grid",gridTemplateColumns:"0.5fr 1fr 1fr 0.8fr 0.9fr 0.8fr",gap:1,
          px:2.5,py:1.5,background:"#f8faff",borderBottom:`1px solid ${C.border}` }}>
          {["ID","Requester","Mode","Amount","Status","Date"].map(h=>(
            <Typography key={h} sx={{ fontSize:11,fontWeight:700,color:C.text3,textTransform:"uppercase",letterSpacing:"0.05em" }}>{h}</Typography>
          ))}
        </Box>
        {loading ? (
          <Box sx={{ p:6,textAlign:"center" }}><CircularProgress sx={{ color:A }}/></Box>
        ) : filtered.length===0 ? (
          <Box sx={{ p:6,textAlign:"center" }}><Typography sx={{ color:C.text3 }}>No records found.</Typography></Box>
        ) : filtered.map(r=>{
          const sc = statusCfg[r.status]||statusCfg.PENDING;
          return (
            <Box key={r.id} sx={{ display:"grid",gridTemplateColumns:"0.5fr 1fr 1fr 0.8fr 0.9fr 0.8fr",
              gap:1,px:2.5,py:1.8,borderBottom:`1px solid ${C.border}`,"&:hover":{background:"#fafbff"},alignItems:"center" }}>
              <Typography sx={{ fontSize:12,color:C.text3,fontFamily:"monospace" }}>#{r.id}</Typography>
              <Box>
                <Typography sx={{ fontSize:13,fontWeight:700,color:C.text1 }}>{r.requesterUsername||"—"}</Typography>
                <Typography sx={{ fontSize:11,color:C.text3 }}>{r.requesterType||"—"}</Typography>
              </Box>
              <Typography sx={{ fontSize:12,color:C.text2 }}>{r.paymentMode||"—"}</Typography>
              <Typography sx={{ fontSize:13,fontWeight:700,color:C.text1 }}>{fmt(r.amount)}</Typography>
              <Chip label={sc.label} size="small" sx={{ background:sc.bg,color:sc.color,fontWeight:600,fontSize:11 }}/>
              <Typography sx={{ fontSize:12,color:C.text3 }}>{r.requestDate ? new Date(r.requestDate).toLocaleDateString("en-IN") : "—"}</Typography>
            </Box>
          );
        })}
        <Box sx={{ px:2.5,py:1.5,borderTop:`1px solid ${C.border}` }}>
          <Typography sx={{ fontSize:12,color:C.text3 }}>Showing {filtered.length} of {data.length}</Typography>
        </Box>
      </Paper>
      <Snackbar open={toast.open} autoHideDuration={3500} onClose={()=>setToast({...toast,open:false})} anchorOrigin={{ vertical:"bottom",horizontal:"right" }}>
        <Alert severity={toast.sev} sx={{ borderRadius:"10px" }}>{toast.msg}</Alert>
      </Snackbar>
    </Box>
  );
}
