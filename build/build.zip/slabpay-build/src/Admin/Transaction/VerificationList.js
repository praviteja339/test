import { useState, useEffect, useCallback } from "react";
import {
  Box, Typography, Paper, Chip, TextField, Select, MenuItem, Button,
  InputAdornment, CircularProgress, Alert, Snackbar, IconButton, Tooltip,
  Dialog, DialogTitle, DialogContent, DialogActions,
} from "@mui/material";
import { Search, Refresh, CheckCircle, Cancel, Visibility } from "@mui/icons-material";
import { getEnquiries, acceptEnquiry, rejectEnquiry, generateCreds } from "../../services/adminApi";

const A = "#dc2626";
const C = { border:"#e5eaf5", text1:"#0f1623", text2:"#3a4563", text3:"#7a8aab" };
const statusCfg = {
  PENDING:   { label:"Pending",    bg:"#fffbeb", color:"#d97706" },
  ACCEPTED:  { label:"Accepted",   bg:"#ecfdf5", color:"#059669" },
  REJECTED:  { label:"Rejected",   bg:"#fef2f2", color:A         },
  CONVERTED: { label:"Converted",  bg:"#e8efff", color:"#1a56db" },
};

export default function VerificationList() {
  const [data,         setData]         = useState([]);
  const [loading,      setLoading]      = useState(true);
  const [toast,        setToast]        = useState({ open:false, msg:"", sev:"success" });
  const [search,       setSearch]       = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [rejectOpen,   setRejectOpen]   = useState(false);
  const [rejectId,     setRejectId]     = useState(null);
  const [rejectNote,   setRejectNote]   = useState("");
  const [detailOpen,   setDetailOpen]   = useState(false);
  const [detail,       setDetail]       = useState(null);

  const showToast = (msg,sev="success") => setToast({ open:true,msg,sev });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getEnquiries();
      setData(Array.isArray(res.data.data) ? res.data.data : []);
    } catch { showToast("Failed to load verification list.","error"); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleAccept = async (id) => {
    try { await acceptEnquiry(id); showToast("Enquiry accepted."); load(); }
    catch { showToast("Failed to accept.","error"); }
  };

  const handleReject = async () => {
    try { await rejectEnquiry(rejectId, rejectNote); showToast("Enquiry rejected."); setRejectOpen(false); setRejectNote(""); load(); }
    catch { showToast("Failed to reject.","error"); }
  };

  const handleGenCreds = async (id) => {
    try { await generateCreds(id); showToast("Credentials generated and sent."); load(); }
    catch { showToast("Failed to generate credentials.","error"); }
  };

  const filtered = data.filter(r =>
    (search==="" || (r.applicantName||"").toLowerCase().includes(search.toLowerCase()) ||
      (r.mobileNumber||"").includes(search)) &&
    (statusFilter==="All" || r.status===statusFilter)
  );

  return (
    <Box>
      <Box sx={{ mb:3,display:"flex",alignItems:"flex-start",justifyContent:"space-between",flexWrap:"wrap",gap:2 }}>
        <Box>
          <Typography sx={{ fontSize:22,fontWeight:800,color:C.text1 }}>KYC Verification List</Typography>
          <Typography sx={{ fontSize:13,color:C.text3 }}>{data.filter(d=>d.status==="PENDING").length} pending review</Typography>
        </Box>
        <Tooltip title="Refresh"><IconButton onClick={load} sx={{ border:`1px solid ${C.border}`,borderRadius:"10px" }}><Refresh fontSize="small"/></IconButton></Tooltip>
      </Box>

      <Paper elevation={0} sx={{ p:2,mb:2.5,borderRadius:"14px",border:`1px solid ${C.border}`,display:"flex",gap:2,flexWrap:"wrap" }}>
        <TextField size="small" placeholder="Search by name or mobile…" value={search} onChange={e=>setSearch(e.target.value)}
          InputProps={{ startAdornment:<InputAdornment position="start"><Search fontSize="small"/></InputAdornment> }}
          sx={{ flex:1,minWidth:200,"& .MuiOutlinedInput-root":{ borderRadius:"10px" } }}/>
        <Select size="small" value={statusFilter} onChange={e=>setStatusFilter(e.target.value)} sx={{ minWidth:150,borderRadius:"10px" }}>
          {["All","PENDING","ACCEPTED","REJECTED","CONVERTED"].map(s=><MenuItem key={s} value={s}>{s}</MenuItem>)}
        </Select>
      </Paper>

      <Paper elevation={0} sx={{ borderRadius:"16px",border:`1px solid ${C.border}`,overflow:"hidden" }}>
        <Box sx={{ display:"grid",gridTemplateColumns:"1.2fr 0.8fr 0.8fr 0.8fr 0.9fr 1.2fr",gap:1,
          px:2.5,py:1.5,background:"#f8faff",borderBottom:`1px solid ${C.border}` }}>
          {["Applicant","User Type","Mobile","Status","Date","Actions"].map(h=>(
            <Typography key={h} sx={{ fontSize:11,fontWeight:700,color:C.text3,textTransform:"uppercase",letterSpacing:"0.05em" }}>{h}</Typography>
          ))}
        </Box>
        {loading ? (
          <Box sx={{ p:6,textAlign:"center" }}><CircularProgress sx={{ color:A }}/></Box>
        ) : filtered.length===0 ? (
          <Box sx={{ p:6,textAlign:"center" }}><Typography sx={{ color:C.text3 }}>No records.</Typography></Box>
        ) : filtered.map(r=>{
          const sc = statusCfg[r.status]||statusCfg.PENDING;
          const isPending = r.status==="PENDING";
          const isAccepted = r.status==="ACCEPTED";
          return (
            <Box key={r.id} sx={{ display:"grid",gridTemplateColumns:"1.2fr 0.8fr 0.8fr 0.8fr 0.9fr 1.2fr",
              gap:1,px:2.5,py:1.8,borderBottom:`1px solid ${C.border}`,"&:hover":{background:"#fafbff"},alignItems:"center" }}>
              <Box>
                <Typography sx={{ fontSize:13,fontWeight:700,color:C.text1 }}>{r.applicantName||"—"}</Typography>
                <Typography sx={{ fontSize:11,color:C.text3 }}>{r.emailId||"—"}</Typography>
              </Box>
              <Chip label={r.userType||"—"} size="small" sx={{ background:"#e8efff",color:"#1a56db",fontWeight:600,fontSize:11 }}/>
              <Typography sx={{ fontSize:12,color:C.text2 }}>{r.mobileNumber||"—"}</Typography>
              <Chip label={sc.label} size="small" sx={{ background:sc.bg,color:sc.color,fontWeight:600,fontSize:11 }}/>
              <Typography sx={{ fontSize:12,color:C.text3 }}>{r.createdDate ? new Date(r.createdDate).toLocaleDateString("en-IN") : "—"}</Typography>
              <Box sx={{ display:"flex",gap:0.5 }}>
                <Tooltip title="View Details"><IconButton size="small" onClick={()=>{ setDetail(r); setDetailOpen(true); }}><Visibility fontSize="small" sx={{ color:C.text3 }}/></IconButton></Tooltip>
                {isPending && <>
                  <Tooltip title="Accept"><IconButton size="small" onClick={()=>handleAccept(r.id)}><CheckCircle fontSize="small" sx={{ color:"#059669" }}/></IconButton></Tooltip>
                  <Tooltip title="Reject"><IconButton size="small" onClick={()=>{ setRejectId(r.id); setRejectOpen(true); }}><Cancel fontSize="small" sx={{ color:A }}/></IconButton></Tooltip>
                </>}
                {isAccepted && (
                  <Button size="small" variant="outlined" onClick={()=>handleGenCreds(r.id)}
                    sx={{ fontSize:11,textTransform:"none",borderRadius:"8px",borderColor:A,color:A,"&:hover":{borderColor:"#b91c1c",background:"#fef2f2"} }}>
                    Gen Creds
                  </Button>
                )}
              </Box>
            </Box>
          );
        })}
        <Box sx={{ px:2.5,py:1.5,borderTop:`1px solid ${C.border}` }}>
          <Typography sx={{ fontSize:12,color:C.text3 }}>Showing {filtered.length} of {data.length}</Typography>
        </Box>
      </Paper>

      <Dialog open={rejectOpen} onClose={()=>setRejectOpen(false)} maxWidth="xs" fullWidth PaperProps={{ sx:{ borderRadius:"16px" } }}>
        <DialogTitle sx={{ fontWeight:800,color:C.text1 }}>Reject KYC Enquiry</DialogTitle>
        <DialogContent dividers>
          <TextField label="Rejection Reason" multiline rows={3} fullWidth size="small" value={rejectNote}
            onChange={e=>setRejectNote(e.target.value)} sx={{ "& .MuiOutlinedInput-root":{ borderRadius:"10px" } }}/>
        </DialogContent>
        <DialogActions sx={{ p:2,gap:1 }}>
          <Button onClick={()=>setRejectOpen(false)} sx={{ textTransform:"none",borderRadius:"10px" }}>Cancel</Button>
          <Button onClick={handleReject} variant="contained" sx={{ background:A,borderRadius:"10px",textTransform:"none",fontWeight:700,"&:hover":{background:"#b91c1c"} }}>Reject</Button>
        </DialogActions>
      </Dialog>

      <Dialog open={detailOpen} onClose={()=>setDetailOpen(false)} maxWidth="sm" fullWidth PaperProps={{ sx:{ borderRadius:"16px" } }}>
        <DialogTitle sx={{ fontWeight:800,color:C.text1 }}>Enquiry Details</DialogTitle>
        <DialogContent dividers>
          {detail && Object.entries({
            "Name": detail.applicantName, "Email": detail.emailId||"—", "Mobile": detail.mobileNumber||"—",
            "User Type": detail.userType||"—", "Status": detail.status,
            "KYC Type": detail.kycType||"—", "Aadhaar": detail.aadhaarNumber ? "****"+detail.aadhaarNumber.slice(-4) : "—",
            "PAN": detail.panNumber||"—", "Applied On": detail.createdDate ? new Date(detail.createdDate).toLocaleString("en-IN") : "—",
          }).map(([k,v])=>(
            <Box key={k} sx={{ display:"flex",justifyContent:"space-between",py:1,borderBottom:"1px solid #f0f0f0" }}>
              <Typography sx={{ fontSize:13,color:C.text3 }}>{k}</Typography>
              <Typography sx={{ fontSize:13,fontWeight:600,color:C.text1 }}>{v}</Typography>
            </Box>
          ))}
        </DialogContent>
        <DialogActions sx={{ p:2 }}><Button onClick={()=>setDetailOpen(false)} sx={{ textTransform:"none",borderRadius:"10px" }}>Close</Button></DialogActions>
      </Dialog>

      <Snackbar open={toast.open} autoHideDuration={3500} onClose={()=>setToast({...toast,open:false})} anchorOrigin={{ vertical:"bottom",horizontal:"right" }}>
        <Alert severity={toast.sev} sx={{ borderRadius:"10px" }}>{toast.msg}</Alert>
      </Snackbar>
    </Box>
  );
}
