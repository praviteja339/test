import { Box, Container, Typography, Grid, Chip } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { SERVICES, ECO_CARDS, BBPS_UTILITIES } from '../data/siteData';
import { Check } from '@mui/icons-material';

const C = { primary: '#1a56db', primaryLight: '#e8efff', secondary: '#0e9f6e', text1: '#0f1623', text2: '#3a4563', text3: '#7a8aab', border: '#e5eaf5', surface2: '#f8faff' };

export default function ServicesPage() {
  const navigate = useNavigate();
  const handleNav = (key) => navigate({ home: '/', services: '/services', about: '/about', contact: '/contact', login: '/login' }[key] || '/');

  return (
    <Box sx={{ background: '#ffffff', minHeight: '100vh' }}>
      <Navbar currentPage="services" />
      <Box sx={{ pt: { xs: 12, md: 16 }, pb: 8, background: 'linear-gradient(160deg, #f8faff 0%, #e8efff 60%, #f0f5ff 100%)', textAlign: 'center' }}>
        <Container maxWidth="md">
          <Chip label="🏦 Full-Stack Fintech" sx={{ mb: 3, background: C.primaryLight, color: C.primary, fontWeight: 700, height: 36, borderRadius: '20px' }} />
          <Typography sx={{ fontSize: { xs: 32, md: 50 }, fontWeight: 800, color: C.text1, letterSpacing: '-1.5px', mb: 2, lineHeight: 1.1 }}>
            Our Service Portfolio
          </Typography>
          <Typography sx={{ fontSize: 17, color: C.text3, lineHeight: 1.8 }}>
            A complete fintech ecosystem for banking, payments, and travel services.
          </Typography>
        </Container>
      </Box>

      {/* Services Cards */}
      <Box sx={{ py: 10, background: '#ffffff' }}>
        <Container maxWidth="lg">
          <Grid container spacing={3}>
            {SERVICES.map((s, i) => (
              <Grid item xs={12} md={4} key={i}>
                <Box sx={{
                  p: 4, borderRadius: '20px',
                  background: s.featured ? 'linear-gradient(135deg, #1a56db, #3b7af7)' : '#f8faff',
                  border: `1px solid ${s.featured ? 'transparent' : C.border}`,
                  height: '100%', boxShadow: s.featured ? '0 16px 48px rgba(26,86,219,0.3)' : '0 2px 8px rgba(15,22,35,0.04)',
                  transition: 'all 0.25s ease',
                  '&:hover': { transform: 'translateY(-4px)', boxShadow: s.featured ? '0 24px 60px rgba(26,86,219,0.4)' : '0 12px 36px rgba(15,22,35,0.1)' },
                }}>
                  <Box sx={{ fontSize: 40, mb: 2.5 }}>{s.icon}</Box>
                  <Typography sx={{ fontSize: 22, fontWeight: 800, color: s.featured ? '#fff' : C.text1, mb: 2 }}>{s.title}</Typography>
                  {s.items.map(item => (
                    <Box key={item} sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1.2 }}>
                      <Check sx={{ fontSize: 16, color: s.featured ? 'rgba(255,255,255,0.8)' : C.secondary }} />
                      <Typography sx={{ fontSize: 14, color: s.featured ? 'rgba(255,255,255,0.85)' : C.text2, fontWeight: 500 }}>{item}</Typography>
                    </Box>
                  ))}
                </Box>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      {/* Ecosystem */}
      <Box sx={{ py: 10, background: C.surface2 }}>
        <Container maxWidth="lg">
          <Box sx={{ textAlign: 'center', mb: 7 }}>
            <Typography sx={{ fontSize: { xs: 28, md: 40 }, fontWeight: 800, color: C.text1, letterSpacing: '-1px', mb: 2 }}>Full Ecosystem</Typography>
            <Typography sx={{ fontSize: 16, color: C.text3 }}>Everything you need to power financial services.</Typography>
          </Box>
          <Grid container spacing={2.5}>
            {ECO_CARDS.map((card, i) => (
              <Grid item xs={12} sm={6} md={4} key={i}>
                <Box sx={{ p: 3, background: '#ffffff', borderRadius: '16px', border: `1px solid ${C.border}`, height: '100%', transition: 'all 0.2s ease', '&:hover': { boxShadow: '0 8px 24px rgba(15,22,35,0.08)', transform: 'translateY(-3px)', borderColor: C.primary } }}>
                  <Box sx={{ fontSize: 28, mb: 1.5 }}>{card.icon}</Box>
                  <Typography sx={{ fontSize: 16, fontWeight: 700, color: C.text1, mb: 1 }}>{card.title}</Typography>
                  <Typography sx={{ fontSize: 13.5, color: C.text3, lineHeight: 1.7 }}>{card.desc}</Typography>
                </Box>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      {/* BBPS */}
      <Box sx={{ py: 10, background: '#ffffff' }}>
        <Container maxWidth="lg">
          <Box sx={{ textAlign: 'center', mb: 6 }}>
            <Typography sx={{ fontSize: { xs: 26, md: 36 }, fontWeight: 800, color: C.text1, letterSpacing: '-0.8px', mb: 2 }}>BBPS Utilities</Typography>
            <Typography sx={{ fontSize: 16, color: C.text3 }}>20,000+ billers across every utility category.</Typography>
          </Box>
          <Grid container spacing={3} justifyContent="center">
            {BBPS_UTILITIES.map((u, i) => (
              <Grid item xs={6} sm={3} key={i}>
                <Box sx={{ p: 3, background: C.primaryLight, borderRadius: '16px', textAlign: 'center', border: `1px solid ${C.border}`, transition: 'all 0.2s ease', '&:hover': { background: C.primary, '& .label': { color: '#fff' }, '& .emoji': { transform: 'scale(1.2)' } } }}>
                  <Box className="emoji" sx={{ fontSize: 36, mb: 1.5, transition: 'transform 0.2s ease', display: 'block' }}>{u.icon}</Box>
                  <Typography className="label" sx={{ fontSize: 14, fontWeight: 700, color: C.primary, transition: 'color 0.2s ease' }}>{u.label}</Typography>
                </Box>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      <Footer navigate={handleNav} />
    </Box>
  );
}
