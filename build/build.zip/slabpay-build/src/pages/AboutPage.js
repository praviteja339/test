import { Box, Container, Typography, Grid, Chip } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { ECO_CARDS, VISION_STATS } from '../data/siteData';

const C = { primary: '#1a56db', primaryLight: '#e8efff', secondary: '#0e9f6e', text1: '#0f1623', text2: '#3a4563', text3: '#7a8aab', border: '#e5eaf5', surface2: '#f8faff' };

export default function AboutPage() {
  const navigate = useNavigate();
  const handleNav = (key) => navigate({ home: '/', services: '/services', about: '/about', contact: '/contact', login: '/login' }[key] || '/');

  const team = [
    { name: 'Arjun Mehta', role: 'CEO & Co-Founder', emoji: '👨‍💼' },
    { name: 'Priya Sharma', role: 'CTO', emoji: '👩‍💻' },
    { name: 'Ravi Kumar', role: 'Head of Compliance', emoji: '👨‍⚖️' },
    { name: 'Lakshmi Rao', role: 'VP of Engineering', emoji: '👩‍🔬' },
  ];

  return (
    <Box sx={{ background: '#ffffff', minHeight: '100vh' }}>
      <Navbar currentPage="about" />
      <Box sx={{ pt: { xs: 12, md: 16 }, pb: 8, background: 'linear-gradient(160deg, #f8faff 0%, #e8efff 60%, #f0f5ff 100%)', textAlign: 'center' }}>
        <Container maxWidth="md">
          <Chip label="🏢 Our Story" sx={{ mb: 3, background: C.primaryLight, color: C.primary, fontWeight: 700, height: 36, borderRadius: '20px' }} />
          <Typography sx={{ fontSize: { xs: 32, md: 50 }, fontWeight: 800, color: C.text1, letterSpacing: '-1.5px', mb: 2, lineHeight: 1.1 }}>
            The Precision Architect<br />of Fintech
          </Typography>
          <Typography sx={{ fontSize: 17, color: C.text3, lineHeight: 1.8, maxWidth: 560, mx: 'auto' }}>
            We're building the infrastructure that powers tomorrow's global financial economy — one API at a time.
          </Typography>
        </Container>
      </Box>

      {/* Mission */}
      <Box sx={{ py: 10, background: '#ffffff' }}>
        <Container maxWidth="lg">
          <Grid container spacing={6} alignItems="center">
            <Grid item xs={12} md={6}>
              <Typography sx={{ fontSize: { xs: 28, md: 38 }, fontWeight: 800, color: C.text1, letterSpacing: '-0.8px', mb: 3, lineHeight: 1.2 }}>
                Bringing Banking to <span style={{ color: C.primary }}>Everyone</span>
              </Typography>
              <Typography sx={{ fontSize: 15, color: C.text3, lineHeight: 1.9, mb: 4 }}>
                SlabPay was founded with a clear mission: democratize financial services for every Indian. From rural micro-ATMs to enterprise BBPS bill payments, we power it all on a single platform.
              </Typography>
              {VISION_STATS.map(({ icon, text }, i) => (
                <Box key={i} sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2, p: 2, background: C.surface2, borderRadius: '12px', border: `1px solid ${C.border}` }}>
                  <Box sx={{ fontSize: 22 }}>{icon}</Box>
                  <Typography sx={{ fontSize: 14, fontWeight: 600, color: C.text2 }}>{text}</Typography>
                </Box>
              ))}
            </Grid>
            <Grid item xs={12} md={6}>
              <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2 }}>
                {[
                  { val: '1,000+', label: 'Enterprise Clients', color: C.primary },
                  { val: '99.99%', label: 'Uptime SLA', color: C.secondary },
                  { val: '₹500Cr+', label: 'Monthly Volume', color: '#d97706' },
                  { val: '20K+', label: 'BBPS Billers', color: '#0891b2' },
                ].map((s, i) => (
                  <Box key={i} sx={{ p: 3, background: C.surface2, borderRadius: '16px', border: `1px solid ${C.border}`, textAlign: 'center' }}>
                    <Typography sx={{ fontSize: 30, fontWeight: 800, color: s.color, letterSpacing: '-0.8px' }}>{s.val}</Typography>
                    <Typography sx={{ fontSize: 13, color: C.text3, mt: 0.5, fontWeight: 500 }}>{s.label}</Typography>
                  </Box>
                ))}
              </Box>
            </Grid>
          </Grid>
        </Container>
      </Box>

      {/* Team */}
      <Box sx={{ py: 10, background: C.surface2 }}>
        <Container maxWidth="lg">
          <Box sx={{ textAlign: 'center', mb: 7 }}>
            <Typography sx={{ fontSize: { xs: 28, md: 38 }, fontWeight: 800, color: C.text1, letterSpacing: '-0.8px', mb: 2 }}>Meet the Team</Typography>
            <Typography sx={{ fontSize: 16, color: C.text3 }}>Experienced leaders building the future of fintech.</Typography>
          </Box>
          <Grid container spacing={3} justifyContent="center">
            {team.map((member, i) => (
              <Grid item xs={12} sm={6} md={3} key={i}>
                <Box sx={{ p: 3, background: '#ffffff', borderRadius: '20px', border: `1px solid ${C.border}`, textAlign: 'center', transition: 'all 0.2s ease', '&:hover': { boxShadow: '0 12px 32px rgba(15,22,35,0.1)', transform: 'translateY(-4px)' } }}>
                  <Box sx={{ fontSize: 48, mb: 2 }}>{member.emoji}</Box>
                  <Typography sx={{ fontSize: 16, fontWeight: 700, color: C.text1 }}>{member.name}</Typography>
                  <Typography sx={{ fontSize: 13, color: C.text3, mt: 0.5 }}>{member.role}</Typography>
                </Box>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      <Footer navigate={handleNav} />
    </Box>
  );
}
