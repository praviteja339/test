import { useState, useEffect } from 'react';
import { Box, Typography, TextField, Button, InputAdornment, IconButton, Paper, Divider, Alert, CircularProgress } from '@mui/material';
import { Email, Lock, Visibility, VisibilityOff, ArrowForward } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

const inputStyle = {
  "& .MuiOutlinedInput-root": {
    background: "#f8faff", borderRadius: "12px", color: "#0f1623",
    "& fieldset": { borderColor: "#e5eaf5" },
    "&:hover fieldset": { borderColor: "#1a56db" },
    "&.Mui-focused fieldset": { borderColor: "#1a56db", borderWidth: 2 },
  },
  "& .MuiInputLabel-root": { color: "#7a8aab" },
  "& .MuiInputLabel-root.Mui-focused": { color: "#1a56db" },
};

// utype from API response → dashboard route
const UTYPE_ROUTES = {
  A: "/admin/dashboard",
  S: "/superdistributor/dashboard",
  D: "/distributor/dashboard",
  R: "/agent/dashboard",
  E: "/employee/dashboard",
};

const roles = [
  { key: 'superdistributor', label: 'Super Dist.', emoji: '👑' },
  { key: 'distributor',      label: 'Distributor', emoji: '🏪' },
  { key: 'agent',            label: 'Agent',       emoji: '🧑‍💼' },
];

export default function LoginPage() {
  const navigate = useNavigate();
  const [showPw,  setShowPw]  = useState(false);
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState("");
  const [form,    setForm]    = useState({ email: '', password: '', role: 'superdistributor' });

  // If already logged in, redirect away from login page
  useEffect(() => {
    const token = localStorage.getItem("token");
    const utype = localStorage.getItem("utype");
    if (token) {
      const UTYPE_ROUTES = { A: "/admin/dashboard", S: "/superdistributor/dashboard", D: "/distributor/dashboard", R: "/agent/dashboard" };
      navigate(UTYPE_ROUTES[utype] || "/dashboard", { replace: true });
    }
  }, [navigate]);

  // Block Back button from returning to login after logout
  useEffect(() => {
    window.history.pushState(null, "", window.location.href);
    const handlePop = () => { window.history.pushState(null, "", window.location.href); };
    window.addEventListener("popstate", handlePop);
    return () => window.removeEventListener("popstate", handlePop);
  }, []);

  const handleLogin = async () => {
    if (!form.email.trim() || !form.password.trim()) {
      setError("Please enter your username and password.");
      return;
    }
    setError("");
    setLoading(true);

    try {
      const res = await fetch("https://slabpay.azurewebsites.net/api/v1/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userName: form.email, password: form.password }),
      });

      const result = await res.json();

      if (!res.ok || !result.success) {
        setError(result.message || result.error || "Login failed. Please try again.");
        return;
      }

      const { token, userId, userName, email, roleName, utype } = result.data;

      // Save everything to localStorage
      localStorage.setItem("token",    token);
      localStorage.setItem("userId",   String(userId));
      localStorage.setItem("userName", userName);
      localStorage.setItem("email",    email    || "");
      localStorage.setItem("roleName", roleName || "");
      localStorage.setItem("utype",    utype    || "");

      // Navigate based on utype returned by API
      const route = UTYPE_ROUTES[utype] || "/dashboard";
      navigate(route);

    } catch (err) {
      console.error("Login error:", err);
      setError("Network error – please check your connection.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box sx={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #f8faff 0%, #e8efff 50%, #f0f5ff 100%)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      position: 'relative', overflow: 'hidden',
    }}>
      {/* Background blobs */}
      <Box sx={{ position: 'absolute', top: -80, right: -80, width: 300, height: 300, borderRadius: '50%', background: '#1a56db', opacity: 0.06 }} />
      <Box sx={{ position: 'absolute', bottom: -60, left: -60, width: 250, height: 250, borderRadius: '50%', background: '#0e9f6e', opacity: 0.06 }} />
      <Box sx={{ position: 'absolute', top: '40%', left: '10%', width: 120, height: 120, borderRadius: '50%', background: '#7c3aed', opacity: 0.04 }} />

      <Box sx={{ display: 'flex', width: '100%', maxWidth: 960, mx: 3, gap: 4, alignItems: 'center', position: 'relative', zIndex: 1 }}>

        {/* Left branding */}
        <Box sx={{ flex: 1, display: { xs: 'none', md: 'block' } }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 4 }}>
            <Box sx={{ width: 48, height: 48, borderRadius: '14px', background: 'linear-gradient(135deg, #1a56db, #3b7af7)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 800, fontSize: 18, boxShadow: '0 8px 24px rgba(26,86,219,0.35)' }}>SP</Box>
            <Typography sx={{ fontWeight: 800, fontSize: 22, color: '#0f1623', letterSpacing: '-0.5px' }}>
              Slab<span style={{ color: '#1a56db' }}>Pay</span>
            </Typography>
          </Box>
          <Typography sx={{ fontSize: { xs: 28, md: 38 }, fontWeight: 800, color: '#0f1623', lineHeight: 1.2, letterSpacing: '-1px', mb: 2 }}>
            The Precision<br />
            <span style={{ color: '#1a56db' }}>Architect</span> of<br />
            Fintech.
          </Typography>
          <Typography sx={{ fontSize: 15, color: '#7a8aab', lineHeight: 1.8, mb: 4, maxWidth: 380 }}>
            Powering 20,000+ BBPS billers, biometric banking, and real-time settlements with 99.99% uptime.
          </Typography>
          {[
            { emoji: '⚡', text: 'Real-time settlements in under 200ms' },
            { emoji: '🔐', text: 'AES-256 encrypted, biometric-secured'  },
            { emoji: '📋', text: '20,000+ BBPS billers integrated'       },
          ].map(({ emoji, text }) => (
            <Box key={text} sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1.5 }}>
              <Box sx={{ width: 32, height: 32, borderRadius: '8px', background: '#e8efff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 15, flexShrink: 0 }}>{emoji}</Box>
              <Typography sx={{ fontSize: 14, color: '#3a4563', fontWeight: 500 }}>{text}</Typography>
            </Box>
          ))}
        </Box>

        {/* Login Card */}
        <Paper sx={{ width: '100%', maxWidth: 420, borderRadius: '24px', border: '1px solid #e5eaf5', p: { xs: 3, md: 4 }, boxShadow: '0 20px 60px rgba(15,22,35,0.1)', background: '#ffffff' }}>
          <Box sx={{ textAlign: 'center', mb: 3 }}>
            <Box sx={{ width: 52, height: 52, borderRadius: '14px', background: 'linear-gradient(135deg, #1a56db, #3b7af7)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 800, fontSize: 20, mx: 'auto', mb: 2, boxShadow: '0 6px 18px rgba(26,86,219,0.3)' }}>SP</Box>
            <Typography sx={{ fontSize: 22, fontWeight: 800, color: '#0f1623' }}>Welcome back</Typography>
            <Typography sx={{ fontSize: 14, color: '#7a8aab', mt: 0.5 }}>Sign in to your SlabPay account</Typography>
          </Box>

          {/* Role Selector */}
          <Box sx={{ mb: 2.5 }}>
            <Typography sx={{ fontSize: 11, fontWeight: 700, color: '#7a8aab', textTransform: 'uppercase', letterSpacing: '0.8px', mb: 1 }}>Select Role</Typography>
            <Box sx={{ display: 'flex', gap: 1, p: 0.5, background: '#f8faff', borderRadius: '12px', border: '1px solid #e5eaf5' }}>
              {roles.map(({ key, label, emoji }) => (
                <Box
                  key={key}
                  onClick={() => setForm({ ...form, role: key })}
                  sx={{
                    flex: 1, py: 1.2, px: 0.5, borderRadius: '10px', cursor: 'pointer', textAlign: 'center',
                    background: form.role === key ? '#1a56db' : 'transparent',
                    color: form.role === key ? '#fff' : '#7a8aab',
                    transition: 'all 0.2s ease', fontSize: 12, fontWeight: 700,
                    boxShadow: form.role === key ? '0 4px 12px rgba(26,86,219,0.3)' : 'none',
                  }}
                >
                  <Box sx={{ fontSize: 16, mb: 0.3 }}>{emoji}</Box>
                  {label}
                </Box>
              ))}
            </Box>
          </Box>

          {/* Error alert */}
          {error && (
            <Alert severity="error" sx={{ mb: 2, borderRadius: "10px", fontSize: 13 }} onClose={() => setError("")}>
              {error}
            </Alert>
          )}

          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mb: 2.5 }}>
            <TextField
              label="Email / Username"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
              fullWidth sx={inputStyle}
              InputProps={{ startAdornment: <InputAdornment position="start"><Email sx={{ color: '#7a8aab', fontSize: 18 }} /></InputAdornment> }}
            />
            <TextField
              label="Password"
              type={showPw ? 'text' : 'password'}
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
              fullWidth sx={inputStyle}
              InputProps={{
                startAdornment: <InputAdornment position="start"><Lock sx={{ color: '#7a8aab', fontSize: 18 }} /></InputAdornment>,
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton size="small" onClick={() => setShowPw(!showPw)} sx={{ color: '#7a8aab' }}>
                      {showPw ? <VisibilityOff fontSize="small" /> : <Visibility fontSize="small" />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
          </Box>

          <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2.5 }}>
            <Typography sx={{ fontSize: 13, color: '#1a56db', cursor: 'pointer', fontWeight: 600 }}>Forgot password?</Typography>
          </Box>

          <Button
            fullWidth
            onClick={handleLogin}
            disabled={loading}
            endIcon={loading ? <CircularProgress size={18} color="inherit" /> : <ArrowForward />}
            sx={{
              background: 'linear-gradient(135deg, #1a56db, #3b7af7)',
              color: '#fff', borderRadius: '12px', height: 52,
              fontSize: 15, fontWeight: 700, textTransform: 'none',
              boxShadow: '0 6px 20px rgba(26,86,219,0.35)',
              '&:hover': { boxShadow: '0 8px 28px rgba(26,86,219,0.5)', transform: 'translateY(-1px)' },
              '&:disabled': { opacity: 0.7 },
              transition: 'all 0.2s ease',
            }}
          >
            {loading ? 'Signing in…' : 'Sign In'}
          </Button>

          <Divider sx={{ my: 2.5, borderColor: '#f0f4fb' }}>
            <Typography sx={{ fontSize: 12, color: '#b0bcd4', px: 1 }}>or</Typography>
          </Divider>

          <Button
            fullWidth
            onClick={() => navigate('/')}
            sx={{
              color: '#3a4563', border: '1.5px solid #e5eaf5', borderRadius: '12px', height: 46,
              fontSize: 14, fontWeight: 600, textTransform: 'none',
              '&:hover': { borderColor: '#1a56db', color: '#1a56db', background: '#e8efff' },
            }}
          >← Back to Home</Button>

          <Typography sx={{ textAlign: 'center', fontSize: 12, color: '#b0bcd4', mt: 2.5 }}>
            Protected by SSL · © 2025 SlabPay E Com Solutions
          </Typography>
        </Paper>
      </Box>
    </Box>
  );
}