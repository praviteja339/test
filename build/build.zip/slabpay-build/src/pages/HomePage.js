import { Box, Container, Typography, Button, Grid, Chip } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { FEATURES, NUMBERS, FLOW_NODES, SERVICES, TICKER_ITEMS } from '../data/siteData';
import { ArrowForward, Check } from '@mui/icons-material';

const C = {
  primary: '#1a56db', primaryLight: '#e8efff',
  secondary: '#0e9f6e', secondaryLight: '#e6faf3',
  text1: '#0f1623', text2: '#3a4563', text3: '#7a8aab',
  border: '#e5eaf5', surface2: '#f8faff',
};

export default function HomePage() {
  const navigate = useNavigate();
  const handleNav = (key) => {
    const routes = { home: '/', services: '/services', about: '/about', contact: '/contact', login: '/login' };
    navigate(routes[key] || '/');
  };

  return (
    <Box sx={{ background: '#ffffff', minHeight: '100vh' }}>
      <Navbar currentPage="home" />

      {/* HERO */}
      <Box sx={{
        pt: { xs: 12, md: 16 }, pb: { xs: 8, md: 12 },
        background: 'linear-gradient(160deg, #f8faff 0%, #ffffff 40%, #e8efff 100%)',
        position: 'relative', overflow: 'hidden',
      }}>
        {/* Decoration */}
        <Box sx={{ position: 'absolute', top: 80, right: '8%', width: 400, height: 400, borderRadius: '50%', background: '#1a56db', opacity: 0.05 }} />
        <Box sx={{ position: 'absolute', bottom: 40, left: '5%', width: 200, height: 200, borderRadius: '50%', background: '#0e9f6e', opacity: 0.06 }} />

        <Container maxWidth="lg" sx={{ position: 'relative', zIndex: 1 }}>
          <Box sx={{ maxWidth: 720, mx: 'auto', textAlign: 'center' }}>
            <Chip label="🏆 Trusted by 1,000+ Enterprises" sx={{ mb: 3, background: C.primaryLight, color: C.primary, fontWeight: 700, fontSize: 13, height: 36, borderRadius: '20px' }} />
            <Typography sx={{ fontSize: { xs: 36, md: 58 }, fontWeight: 800, color: C.text1, lineHeight: 1.1, letterSpacing: '-2px', mb: 3 }}>
              The Future of <span style={{ color: C.primary }}>Fintech</span> Infrastructure
            </Typography>
            <Typography sx={{ fontSize: { xs: 16, md: 18 }, color: C.text3, lineHeight: 1.8, mb: 5, maxWidth: 560, mx: 'auto' }}>
              SlabPay powers real-time payments, biometric banking, and BBPS bill collection — all on one enterprise-grade platform.
            </Typography>
            <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center', flexWrap: 'wrap' }}>
              <Button
                onClick={() => handleNav('contact')}
                endIcon={<ArrowForward />}
                sx={{
                  background: 'linear-gradient(135deg, #1a56db, #3b7af7)',
                  color: '#fff', borderRadius: '12px', px: 4, py: 1.8,
                  fontSize: 16, fontWeight: 700, textTransform: 'none',
                  boxShadow: '0 8px 24px rgba(26,86,219,0.35)',
                  '&:hover': { boxShadow: '0 12px 32px rgba(26,86,219,0.5)', transform: 'translateY(-2px)' },
                  transition: 'all 0.2s ease',
                }}
              >Get Started Free</Button>
              <Button
                onClick={() => handleNav('services')}
                sx={{
                  color: C.text2, border: '1.5px solid #d0d8ee', borderRadius: '12px',
                  px: 4, py: 1.8, fontSize: 16, fontWeight: 600, textTransform: 'none',
                  '&:hover': { borderColor: C.primary, color: C.primary, background: C.primaryLight },
                }}
              >View Services</Button>
            </Box>
          </Box>

          {/* Stats strip */}
          <Grid container spacing={3} sx={{ mt: 8, textAlign: 'center' }}>
            {NUMBERS.map((n, i) => (
              <Grid item xs={6} md={3} key={i}>
                <Box sx={{ p: 3, background: '#ffffff', borderRadius: '16px', border: `1px solid ${C.border}`, boxShadow: '0 2px 8px rgba(15,22,35,0.05)' }}>
                  <Typography sx={{ fontSize: 32, fontWeight: 800, color: C.primary, letterSpacing: '-1px' }}>{n.val}</Typography>
                  <Typography sx={{ fontSize: 13, color: C.text3, mt: 0.5, fontWeight: 500 }}>{n.label}</Typography>
                </Box>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      {/* TICKER */}
      <Box sx={{ background: C.primaryLight, borderTop: `1px solid ${C.border}`, borderBottom: `1px solid ${C.border}`, py: 1.5, overflow: 'hidden' }}>
        <Box sx={{ display: 'flex', gap: 4, animation: 'ticker 25s linear infinite', whiteSpace: 'nowrap', '@keyframes ticker': { '0%': { transform: 'translateX(0)' }, '100%': { transform: 'translateX(-50%)' } } }}>
          {[...TICKER_ITEMS, ...TICKER_ITEMS].map((item, i) => (
            <Box key={i} sx={{ display: 'flex', alignItems: 'center', gap: 1, flexShrink: 0 }}>
              <Typography sx={{ fontSize: 13, fontWeight: 700, color: C.primary }}>{item.label}</Typography>
              <Typography sx={{ fontSize: 13, color: C.text3, fontWeight: 500 }}>{item.value}</Typography>
              <Box sx={{ width: 4, height: 4, borderRadius: '50%', background: C.border, mx: 1 }} />
            </Box>
          ))}
        </Box>
      </Box>

      {/* FEATURES */}
      <Box sx={{ py: { xs: 8, md: 12 }, background: '#ffffff' }}>
        <Container maxWidth="lg">
          <Box sx={{ textAlign: 'center', mb: 8 }}>
            <Typography sx={{ fontSize: { xs: 28, md: 40 }, fontWeight: 800, color: C.text1, letterSpacing: '-1px', mb: 2 }}>
              Built for Enterprise Scale
            </Typography>
            <Typography sx={{ fontSize: 16, color: C.text3, maxWidth: 500, mx: 'auto', lineHeight: 1.7 }}>
              Every feature designed for reliability, speed, and security at financial-grade standards.
            </Typography>
          </Box>
          <Grid container spacing={3}>
            {FEATURES.map((f, i) => (
              <Grid item xs={12} md={4} key={i}>
                <Box sx={{
                  p: 4, borderRadius: '20px', background: '#f8faff',
                  border: `1px solid ${C.border}`, height: '100%',
                  transition: 'all 0.25s ease',
                  '&:hover': { background: '#ffffff', boxShadow: '0 12px 36px rgba(15,22,35,0.08)', transform: 'translateY(-4px)', borderColor: C.primary },
                }}>
                  <Box sx={{ fontSize: 36, mb: 2 }}>{f.icon}</Box>
                  <Typography sx={{ fontSize: 18, fontWeight: 700, color: C.text1, mb: 1.5 }}>{f.title}</Typography>
                  <Typography sx={{ fontSize: 14, color: C.text3, lineHeight: 1.8 }}>{f.desc}</Typography>
                </Box>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      {/* SERVICES */}
      <Box sx={{ py: { xs: 8, md: 12 }, background: C.surface2 }}>
        <Container maxWidth="lg">
          <Box sx={{ textAlign: 'center', mb: 8 }}>
            <Typography sx={{ fontSize: { xs: 28, md: 40 }, fontWeight: 800, color: C.text1, letterSpacing: '-1px', mb: 2 }}>
              Our Service Portfolio
            </Typography>
            <Typography sx={{ fontSize: 16, color: C.text3, maxWidth: 500, mx: 'auto' }}>
              A complete fintech ecosystem powering banking, payments, and travel services.
            </Typography>
          </Box>
          <Grid container spacing={3}>
            {SERVICES.map((s, i) => (
              <Grid item xs={12} md={4} key={i}>
                <Box sx={{
                  p: 4, borderRadius: '20px',
                  background: s.featured ? 'linear-gradient(135deg, #1a56db, #3b7af7)' : '#ffffff',
                  border: `1px solid ${s.featured ? 'transparent' : C.border}`,
                  height: '100%', position: 'relative', overflow: 'hidden',
                  boxShadow: s.featured ? '0 16px 48px rgba(26,86,219,0.3)' : '0 2px 8px rgba(15,22,35,0.04)',
                  transition: 'all 0.25s ease',
                  '&:hover': { transform: 'translateY(-4px)', boxShadow: s.featured ? '0 24px 60px rgba(26,86,219,0.4)' : '0 12px 36px rgba(15,22,35,0.1)' },
                }}>
                  {s.featured && <Chip label="Most Popular" size="small" sx={{ position: 'absolute', top: 16, right: 16, background: 'rgba(255,255,255,0.25)', color: '#fff', fontWeight: 700, fontSize: 11 }} />}
                  <Box sx={{ fontSize: 36, mb: 2 }}>{s.icon}</Box>
                  <Typography sx={{ fontSize: 22, fontWeight: 800, color: s.featured ? '#fff' : C.text1, mb: 2 }}>{s.title}</Typography>
                  <Box sx={{ mb: 3 }}>
                    {s.items.map(item => (
                      <Box key={item} sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1 }}>
                        <Check sx={{ fontSize: 16, color: s.featured ? 'rgba(255,255,255,0.8)' : C.secondary }} />
                        <Typography sx={{ fontSize: 14, color: s.featured ? 'rgba(255,255,255,0.85)' : C.text2, fontWeight: 500 }}>{item}</Typography>
                      </Box>
                    ))}
                  </Box>
                  <Button
                    onClick={() => handleNav('services')}
                    sx={{
                      background: s.featured ? 'rgba(255,255,255,0.2)' : C.primaryLight,
                      color: s.featured ? '#fff' : C.primary,
                      borderRadius: '10px', px: 3, py: 1, fontWeight: 700,
                      textTransform: 'none', fontSize: 14,
                      '&:hover': { background: s.featured ? 'rgba(255,255,255,0.3)' : '#d0deff' },
                    }}
                  >{s.btnLabel}</Button>
                </Box>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      {/* FLOW */}
      <Box sx={{ py: { xs: 8, md: 12 }, background: '#ffffff' }}>
        <Container maxWidth="lg">
          <Box sx={{ textAlign: 'center', mb: 8 }}>
            <Typography sx={{ fontSize: { xs: 28, md: 40 }, fontWeight: 800, color: C.text1, letterSpacing: '-1px', mb: 2 }}>
              Transaction Flow
            </Typography>
            <Typography sx={{ fontSize: 16, color: C.text3 }}>From initiation to settlement in milliseconds.</Typography>
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', gap: 2 }}>
            {FLOW_NODES.map((node, i) => (
              <Box key={i} sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Box sx={{
                  p: 3, borderRadius: '20px', textAlign: 'center', minWidth: 200,
                  background: node.highlight ? 'linear-gradient(135deg, #1a56db, #3b7af7)' : '#f8faff',
                  border: `1px solid ${node.highlight ? 'transparent' : C.border}`,
                  boxShadow: node.highlight ? '0 12px 36px rgba(26,86,219,0.3)' : '0 2px 8px rgba(15,22,35,0.04)',
                }}>
                  <Box sx={{ fontSize: 32, mb: 1.5 }}>{node.icon}</Box>
                  <Typography sx={{ fontSize: 14, fontWeight: 700, color: node.highlight ? '#fff' : C.text1, mb: 0.5 }}>{node.title}</Typography>
                  <Typography sx={{ fontSize: 12, color: node.highlight ? 'rgba(255,255,255,0.75)' : C.text3, mb: 1 }}>{node.sub}</Typography>
                  <Chip label={node.val} size="small" sx={{ background: node.highlight ? 'rgba(255,255,255,0.25)' : C.primaryLight, color: node.highlight ? '#fff' : C.primary, fontWeight: 700, fontSize: 11 }} />
                </Box>
                {i < FLOW_NODES.length - 1 && (
                  <Typography sx={{ fontSize: 24, color: C.border, fontWeight: 300 }}>→</Typography>
                )}
              </Box>
            ))}
          </Box>
        </Container>
      </Box>

      {/* CTA */}
      <Box sx={{ py: { xs: 8, md: 12 }, background: 'linear-gradient(135deg, #1a56db, #3b7af7)' }}>
        <Container maxWidth="md">
          <Box sx={{ textAlign: 'center' }}>
            <Typography sx={{ fontSize: { xs: 28, md: 42 }, fontWeight: 800, color: '#fff', letterSpacing: '-1px', mb: 2 }}>
              Ready to transform your payments?
            </Typography>
            <Typography sx={{ fontSize: 16, color: 'rgba(255,255,255,0.75)', mb: 5, lineHeight: 1.7 }}>
              Join 1,000+ enterprises already using SlabPay to power their financial operations.
            </Typography>
            <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center', flexWrap: 'wrap' }}>
              <Button
                onClick={() => handleNav('contact')}
                sx={{
                  background: '#ffffff', color: C.primary,
                  borderRadius: '12px', px: 4, py: 1.8, fontSize: 16, fontWeight: 700,
                  textTransform: 'none', boxShadow: '0 8px 24px rgba(0,0,0,0.2)',
                  '&:hover': { background: '#f0f4ff', transform: 'translateY(-2px)' },
                  transition: 'all 0.2s ease',
                }}
              >Start Free Trial</Button>
              <Button
                onClick={() => handleNav('login')}
                sx={{
                  color: '#fff', border: '1.5px solid rgba(255,255,255,0.4)', borderRadius: '12px',
                  px: 4, py: 1.8, fontSize: 16, fontWeight: 600, textTransform: 'none',
                  '&:hover': { background: 'rgba(255,255,255,0.1)', borderColor: 'rgba(255,255,255,0.7)' },
                }}
              >Sign In</Button>
            </Box>
          </Box>
        </Container>
      </Box>

      <Footer navigate={handleNav} />
    </Box>
  );
}
