import { useState } from 'react';
import { Box, Container, Typography, Grid, TextField, Button, Chip, Paper } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { Phone, Email, LocationOn, ArrowForward } from '@mui/icons-material';

const C = { primary: '#1a56db', primaryLight: '#e8efff', secondary: '#0e9f6e', text1: '#0f1623', text2: '#3a4563', text3: '#7a8aab', border: '#e5eaf5', surface2: '#f8faff' };

const inputStyle = {
  "& .MuiOutlinedInput-root": {
    background: "#f8faff", borderRadius: "12px", color: "#0f1623",
    "& fieldset": { borderColor: "#e5eaf5" },
    "&:hover fieldset": { borderColor: "#1a56db" },
    "&.Mui-focused fieldset": { borderColor: "#1a56db", borderWidth: 2 },
  },
  "& .MuiInputLabel-root": { color: "#7a8aab" },
  "& .MuiInputLabel-root.Mui-focused": { color: "#1a56db" },
};

const contactInfo = [
  { icon: <Phone />, label: 'Phone', value: '+91 98765 43210', sub: 'Mon–Sat, 9AM–6PM IST' },
  { icon: <Email />, label: 'Email', value: 'support@slabpay.com', sub: 'We reply within 24 hours' },
  { icon: <LocationOn />, label: 'Address', value: 'Hyderabad, Telangana', sub: 'India — 500001' },
];

export default function ContactPage() {
  const navigate = useNavigate();
  const handleNav = (key) => navigate({ home: '/', services: '/services', about: '/about', contact: '/contact', login: '/login' }[key] || '/');
  const [form, setForm] = useState({ name: '', email: '', company: '', message: '' });
  const [sent, setSent] = useState(false);

  const handleSubmit = () => setSent(true);

  return (
    <Box sx={{ background: '#ffffff', minHeight: '100vh' }}>
      <Navbar currentPage="contact" />
      <Box sx={{ pt: { xs: 12, md: 16 }, pb: 8, background: 'linear-gradient(160deg, #f8faff 0%, #e8efff 60%, #f0f5ff 100%)', textAlign: 'center' }}>
        <Container maxWidth="md">
          <Chip label="💬 Contact Us" sx={{ mb: 3, background: C.primaryLight, color: C.primary, fontWeight: 700, height: 36, borderRadius: '20px' }} />
          <Typography sx={{ fontSize: { xs: 32, md: 50 }, fontWeight: 800, color: C.text1, letterSpacing: '-1.5px', mb: 2, lineHeight: 1.1 }}>
            Let's Build Together
          </Typography>
          <Typography sx={{ fontSize: 17, color: C.text3, lineHeight: 1.8 }}>
            Have questions? Our team is ready to help you get started with SlabPay.
          </Typography>
        </Container>
      </Box>

      <Box sx={{ py: 10, background: '#ffffff' }}>
        <Container maxWidth="lg">
          <Grid container spacing={5}>
            {/* Contact Form */}
            <Grid item xs={12} md={7}>
              <Paper sx={{ p: 4, borderRadius: '20px', border: `1px solid ${C.border}`, boxShadow: '0 4px 20px rgba(15,22,35,0.06)' }}>
                {sent ? (
                  <Box sx={{ textAlign: 'center', py: 6 }}>
                    <Box sx={{ fontSize: 60, mb: 2 }}>✅</Box>
                    <Typography sx={{ fontSize: 22, fontWeight: 800, color: C.text1, mb: 1 }}>Message Sent!</Typography>
                    <Typography sx={{ fontSize: 14, color: C.text3, mb: 3 }}>Our team will reach out within 24 hours.</Typography>
                    <Button onClick={() => setSent(false)} sx={{ color: C.primary, fontWeight: 700, textTransform: 'none' }}>Send another →</Button>
                  </Box>
                ) : (
                  <>
                    <Typography sx={{ fontSize: 20, fontWeight: 800, color: C.text1, mb: 0.5 }}>Send us a message</Typography>
                    <Typography sx={{ fontSize: 14, color: C.text3, mb: 3 }}>We'll get back to you within 24 hours.</Typography>
                    <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 2, mb: 2 }}>
                      <TextField label="Full Name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} fullWidth sx={inputStyle} />
                      <TextField label="Work Email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} fullWidth sx={inputStyle} />
                      <TextField label="Company Name" value={form.company} onChange={e => setForm({ ...form, company: e.target.value })} fullWidth sx={{ ...inputStyle, gridColumn: '1 / -1' }} />
                    </Box>
                    <TextField label="How can we help?" value={form.message} onChange={e => setForm({ ...form, message: e.target.value })} multiline rows={4} fullWidth sx={{ ...inputStyle, mb: 3 }} />
                    <Button
                      fullWidth onClick={handleSubmit} endIcon={<ArrowForward />}
                      sx={{ background: 'linear-gradient(135deg, #1a56db, #3b7af7)', color: '#fff', borderRadius: '12px', height: 52, fontSize: 16, fontWeight: 700, textTransform: 'none', boxShadow: '0 6px 20px rgba(26,86,219,0.35)', '&:hover': { boxShadow: '0 8px 28px rgba(26,86,219,0.5)', transform: 'translateY(-1px)' }, transition: 'all 0.2s ease' }}
                    >Send Message</Button>
                  </>
                )}
              </Paper>
            </Grid>

            {/* Info */}
            <Grid item xs={12} md={5}>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2.5 }}>
                {contactInfo.map(({ icon, label, value, sub }) => (
                  <Box key={label} sx={{ p: 3, background: C.surface2, borderRadius: '16px', border: `1px solid ${C.border}`, display: 'flex', gap: 2, alignItems: 'flex-start', transition: 'all 0.2s ease', '&:hover': { boxShadow: '0 6px 18px rgba(15,22,35,0.07)', borderColor: C.primary } }}>
                    <Box sx={{ width: 44, height: 44, borderRadius: '12px', background: C.primaryLight, display: 'flex', alignItems: 'center', justifyContent: 'center', color: C.primary, flexShrink: 0 }}>{icon}</Box>
                    <Box>
                      <Typography sx={{ fontSize: 11, fontWeight: 700, color: C.text3, textTransform: 'uppercase', letterSpacing: '0.8px', mb: 0.3 }}>{label}</Typography>
                      <Typography sx={{ fontSize: 15, fontWeight: 700, color: C.text1 }}>{value}</Typography>
                      <Typography sx={{ fontSize: 12, color: C.text3, mt: 0.3 }}>{sub}</Typography>
                    </Box>
                  </Box>
                ))}

                <Box sx={{ p: 3, background: 'linear-gradient(135deg, #1a56db, #3b7af7)', borderRadius: '16px', mt: 1 }}>
                  <Typography sx={{ fontSize: 16, fontWeight: 800, color: '#fff', mb: 1 }}>Enterprise Support</Typography>
                  <Typography sx={{ fontSize: 14, color: 'rgba(255,255,255,0.75)', lineHeight: 1.7, mb: 2 }}>
                    Get dedicated account management, SLA guarantees, and 24/7 priority support.
                  </Typography>
                  <Button onClick={() => navigate('/login')} sx={{ background: 'rgba(255,255,255,0.2)', color: '#fff', borderRadius: '10px', px: 2.5, py: 1, fontWeight: 700, textTransform: 'none', fontSize: 14, '&:hover': { background: 'rgba(255,255,255,0.35)' } }}>
                    Contact Sales →
                  </Button>
                </Box>
              </Box>
            </Grid>
          </Grid>
        </Container>
      </Box>

      <Footer navigate={handleNav} />
    </Box>
  );
}
