import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const flowerSVG = (
  <svg
    viewBox="0 0 400 400"
    xmlns="http://www.w3.org/2000/svg"
    style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0.2 }}
  >
    {[...Array(12)].map((_, i) => (
      <ellipse key={i} cx="200" cy="200" rx="80" ry="160" fill="none" stroke="white" strokeWidth="1.5"
        transform={`rotate(${i * 30} 200 200)`} />
    ))}
    {[...Array(8)].map((_, i) => (
      <ellipse key={`inner-${i}`} cx="200" cy="200" rx="50" ry="110" fill="none" stroke="white" strokeWidth="1"
        transform={`rotate(${i * 22.5} 200 200)`} />
    ))}
    <circle cx="200" cy="200" r="30" fill="none" stroke="white" strokeWidth="1.5" />
    <circle cx="200" cy="200" r="10" fill="none" stroke="white" strokeWidth="1" />
  </svg>
);

const EyeIcon = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
    <circle cx="12" cy="12" r="3" />
  </svg>
);

const EyeOffIcon = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" />
    <line x1="1" y1="1" x2="23" y2="23" />
  </svg>
);

export default function AdminLoginPage() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ loginId: '', password: '', domain: '' });
  const [showPw, setShowPw] = useState(false);
  const [keepLogged, setKeepLogged] = useState(true);
  const [loading, setLoading] = useState(false);
  const [vkb, setVkb] = useState(false);
  const [error, setError] = useState('');

  // If already logged in as admin, redirect away
  useEffect(() => {
    const token = localStorage.getItem("token");
    const utype = localStorage.getItem("utype");
    if (token && utype === "A") {
      navigate("/admin/dashboard", { replace: true });
    } else if (token) {
      navigate("/dashboard", { replace: true });
    }
  }, [navigate]);

  // Block Back button from returning to admin login after logout
  useEffect(() => {
    window.history.pushState(null, "", window.location.href);
    const handlePop = () => { window.history.pushState(null, "", window.location.href); };
    window.addEventListener("popstate", handlePop);
    return () => window.removeEventListener("popstate", handlePop);
  }, []);

  const handleLogin = async () => {
    if (!form.loginId || !form.password) {
      setError('Please enter your Login ID and Password.');
      return;
    }

    setError('');
    setLoading(true);

    try {
      const response = await fetch('https://slabpay.azurewebsites.net/api/v1/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userName: form.loginId,
          password: form.password,
        }),
      });

      const data = await response.json();

      if (data.success) {
        // Store token and user info
        const storage = keepLogged ? localStorage : sessionStorage;
        storage.setItem('token', data.data.token);
        storage.setItem('userId', data.data.userId);
        storage.setItem('userName', data.data.userName);
        storage.setItem('email', data.data.email);
        storage.setItem('roleName', data.data.roleName);
        storage.setItem('utype', data.data.utype);

        navigate('/admin/dashboard');
      } else {
        setError(data.message || 'Login failed. Please check your credentials.');
      }
    } catch (err) {
      setError('Unable to connect to the server. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleClear = () => {
    setForm({ loginId: '', password: '', domain: '' });
    setError('');
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #0a2a6e 0%, #0d3b8e 20%, #1255b5 45%, #1976d2 68%, #42a5f5 88%, #90caf9 100%)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: "'Segoe UI', sans-serif",
      padding: '30px 20px',
    }}>

      {/* ── Card ── */}
      <div style={{
        width: '100%',
        maxWidth: '850px',
        borderRadius: '18px',
        overflow: 'hidden',
        boxShadow: '0 24px 64px rgba(0,0,0,0.35)',
        background: '#fff',
      }}>

        {/* Nav Bar */}
        <div style={{
          background: '#fff',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '13px 26px',
          borderBottom: '1px solid #ebebeb',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '18px' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', cursor: 'pointer' }}>
              {[0, 1, 2].map(i => (
                <span key={i} style={{ display: 'block', width: '20px', height: '2px', background: '#003b7a' }} />
              ))}
            </div>
            {['HOME', 'ABOUT', 'SERVICES', 'BLOG', 'CONTACT'].map(item => (
              <a key={item} href="#" style={{
                fontSize: '10px', fontWeight: '600', color: '#555',
                textDecoration: 'none', letterSpacing: '0.5px',
              }}>{item}</a>
            ))}
            <a href="#" style={{
              fontSize: '10px', fontWeight: '700', color: '#003b7a', textDecoration: 'none',
              letterSpacing: '0.5px', border: '1.5px solid #003b7a', padding: '3px 10px', borderRadius: '3px',
            }}>BOOK NOW</a>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '9px' }}>
            <div style={{
              width: '40px', height: '40px', background: '#003b7a', borderRadius: '5px',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: '#fff', fontWeight: '800', fontSize: '13px', letterSpacing: '0.5px',
            }}>SP</div>
            <div>
              <div style={{ fontSize: '17px', fontWeight: '700', color: '#003b7a', lineHeight: 1 }}>
                Slab<span style={{ color: '#e8441a' }}>Pay</span>
              </div>
              <div style={{ fontSize: '9px', color: '#999', letterSpacing: '0.3px' }}>E COM SOLUTIONS PVT. LTD.</div>
            </div>
          </div>
        </div>

        {/* Body */}
        <div style={{ display: 'flex', minHeight: '460px' }}>

          {/* ── Left Panel ── */}
          <div style={{
            width: '42%',
            flexShrink: 0,
            position: 'relative',
            overflow: 'hidden',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            minHeight: '460px',
            background: '#eaf0fb',
          }}>
            <div style={{
              position: 'absolute',
              left: '-55%',
              top: '-5%',
              width: '155%',
              height: '110%',
              borderRadius: '50%',
              background: 'linear-gradient(150deg, #0a2a6e 0%, #0d3b8e 25%, #1565c0 55%, #1e88e5 80%, #64b5f6 100%)',
              overflow: 'hidden',
              flexShrink: 0,
            }}>
              <div style={{ position: 'absolute', inset: 0 }}>{flowerSVG}</div>
            </div>

            <div style={{ position: 'relative', zIndex: 2, textAlign: 'center', paddingLeft: '10%' }}>
              <p style={{
                color: 'rgba(255,255,255,0.8)', fontSize: '11px', letterSpacing: '2.5px',
                fontWeight: '500', margin: '0 0 6px', textTransform: 'uppercase',
              }}>MY DASHBOARD</p>
              <h2 style={{
                color: '#fff', fontSize: '21px', fontWeight: '800',
                letterSpacing: '1px', margin: 0, textTransform: 'uppercase',
              }}>ADMIN LOGIN</h2>
            </div>
          </div>

          {/* ── Right Panel ── */}
          <div style={{
            flex: 1,
            background: '#f3f5f8',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '36px 44px',
          }}>
            <h1 style={{
              fontSize: '22px', fontWeight: '800', color: '#1a1a1a',
              margin: '0 0 5px', textAlign: 'center', letterSpacing: '0.4px',
            }}>WELCOME BACK!</h1>
            <p style={{ fontSize: '11px', color: '#999', margin: '0 0 22px', textAlign: 'center' }}>
              Please login to view your dashboard
            </p>

            {/* Error Message */}
            {error && (
              <div style={{
                width: '100%',
                background: '#fff0f0',
                border: '1.5px solid #f5c2c2',
                borderRadius: '5px',
                padding: '9px 14px',
                marginBottom: '12px',
                fontSize: '11.5px',
                color: '#c0392b',
                boxSizing: 'border-box',
                display: 'flex',
                alignItems: 'center',
                gap: '7px',
              }}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" />
                </svg>
                {error}
              </div>
            )}

            {/* Login ID */}
            <input
              type="text" placeholder="Login ID" value={form.loginId}
              onChange={e => { setForm({ ...form, loginId: e.target.value }); setError(''); }}
              style={{
                width: '100%', padding: '10px 14px', border: '1.5px solid #b8c9e0',
                borderRadius: '5px', fontSize: '12px', color: '#444', outline: 'none',
                marginBottom: '10px', background: '#fff', boxSizing: 'border-box',
              }}
            />

            {/* Password */}
            <div style={{ width: '100%', position: 'relative', marginBottom: '10px' }}>
              <input
                type={showPw ? 'text' : 'password'} placeholder="Password" value={form.password}
                onChange={e => { setForm({ ...form, password: e.target.value }); setError(''); }}
                onKeyDown={e => e.key === 'Enter' && handleLogin()}
                style={{
                  width: '100%', padding: '10px 36px 10px 14px', border: '1.5px solid #b8c9e0',
                  borderRadius: '5px', fontSize: '12px', color: '#444', outline: 'none',
                  background: '#fff', boxSizing: 'border-box',
                }}
              />
              <button onClick={() => setShowPw(!showPw)} style={{
                position: 'absolute', right: '10px', top: '50%', transform: 'translateY(-50%)',
                background: 'none', border: 'none', cursor: 'pointer', color: '#999',
                padding: 0, display: 'flex', alignItems: 'center',
              }}>
                {showPw ? <EyeOffIcon /> : <EyeIcon />}
              </button>
            </div>

            {/* Domain */}
            <select value={form.domain} onChange={e => setForm({ ...form, domain: e.target.value })}
              style={{
                width: '100%', padding: '10px 14px', border: '1.5px solid #b8c9e0',
                borderRadius: '5px', fontSize: '12px', color: form.domain ? '#444' : '#aaa',
                outline: 'none', marginBottom: '10px', background: '#fff',
                boxSizing: 'border-box', cursor: 'pointer',
              }}>
              <option value="">-- Select Domain --</option>
              <option value="admin">ADMIN</option>
              <option value="ops">OPERATIONS</option>
              <option value="finance">FINANCE</option>
              <option value="super">SUPER ADMIN</option>
            </select>

            {/* Keep logged & Forgot */}
            <div style={{
              width: '100%', display: 'flex', justifyContent: 'space-between',
              alignItems: 'center', marginBottom: '18px', flexWrap: 'wrap', gap: '6px',
            }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer' }}>
                <input type="checkbox" checked={keepLogged} onChange={e => setKeepLogged(e.target.checked)}
                  style={{ accentColor: '#003b7a', width: '13px', height: '13px' }} />
                <span style={{ fontSize: '11px', color: '#666' }}>Keep me logged in</span>
              </label>
              <span style={{ fontSize: '11px', color: '#999' }}>
                Forgot password?{' '}
                <a href="#" style={{ color: '#003b7a', fontWeight: '600', textDecoration: 'none' }}>Reset now</a>
              </span>
            </div>

            {/* Buttons */}
            <div style={{ display: 'flex', gap: '10px', marginBottom: '14px' }}>
              <button onClick={handleLogin} disabled={loading} style={{
                background: 'linear-gradient(90deg, #0a2a6e, #1565c0)',
                color: '#fff', border: 'none', borderRadius: '5px',
                padding: '11px 46px', fontSize: '13px', fontWeight: '700',
                letterSpacing: '1.5px', cursor: loading ? 'not-allowed' : 'pointer',
                opacity: loading ? 0.75 : 1, transition: 'opacity 0.2s',
              }}>{loading ? 'Logging in...' : 'LOGIN'}</button>
              <button onClick={handleClear} style={{
                background: '#fff', color: '#555', border: '1.5px solid #bbb',
                borderRadius: '5px', padding: '11px 26px', fontSize: '13px',
                fontWeight: '600', cursor: 'pointer', letterSpacing: '0.5px',
              }}>CLEAR</button>
            </div>

            {/* Virtual keyboard */}
            <div style={{ width: '100%', marginBottom: '12px' }}>
              <label style={{ display: 'flex', alignItems: 'flex-start', gap: '6px', cursor: 'pointer' }}>
                <input type="checkbox" checked={vkb} onChange={e => setVkb(e.target.checked)}
                  style={{ accentColor: '#003b7a', width: '13px', height: '13px', marginTop: '2px' }} />
                <span style={{ fontSize: '11px', color: '#888', lineHeight: '1.5' }}>
                  Click here to use virtual keyboard for password (Recommended)
                </span>
              </label>
            </div>

            {/* Terms */}
            <p style={{
              fontSize: '9.5px', color: '#bbb', textAlign: 'center',
              maxWidth: '300px', lineHeight: '1.7', margin: 0,
            }}>
              By signing in you accept all our{' '}
              <a href="#" style={{ color: '#003b7a', textDecoration: 'none' }}>terms &amp; conditions</a>,{' '}
              <a href="#" style={{ color: '#003b7a', textDecoration: 'none' }}>privacy policy</a> and cookie policy.
              SlabPay will never ask for your password or OTP over phone or email.
            </p>

            <p style={{ marginTop: '12px', fontSize: '11px', color: '#aaa', textAlign: 'center' }}>
              Not an admin?{' '}
              <span onClick={() => navigate('/login')}
                style={{ color: '#003b7a', fontWeight: '600', cursor: 'pointer' }}>
                Go to User Login →
              </span>
            </p>
          </div>
        </div>
      </div>

      {/* ── Footer ── */}
      <div style={{
        marginTop: '22px', display: 'flex', flexWrap: 'wrap',
        gap: '6px 20px', justifyContent: 'center', alignItems: 'center',
      }}>
        {['About Us', 'Privacy Policy', 'Terms & Conditions', 'Security Tips', 'Contact Us'].map(item => (
          <a key={item} href="#" style={{ fontSize: '11px', color: 'rgba(255,255,255,0.85)', textDecoration: 'none' }}>
            {item}
          </a>
        ))}
        <span style={{ fontSize: '11px', color: 'rgba(255,255,255,0.55)' }}>
          © 2026 SlabPay E Com Solutions Pvt. Ltd. All rights reserved.
        </span>
      </div>
    </div>
  );
}
