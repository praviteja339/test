// ─── Ticker items ──────────────────────────────────────────────────────────────
export const TICKER_ITEMS = [
  { label: "Money Transfer",    value: "✓ Instant"      },
  { label: "AEPS",   value: "✓ Biometric"    },
  { label: "BBPS",              value: "20,000+ Billers" },
  { label: "Micro ATM",         value: "✓ Active"       },
  { label: "Travel Bookings",   value: "✓ GDS Access"   },
  { label: "Success Rate",      value: "99.9%"           },
  { label: "Fraud Prevention",  value: "AI-Powered"      },
  { label: "Global Settlements",value: "Real-time"       },
];

// ─── Hero stats ────────────────────────────────────────────────────────────────
// export const HERO_STATS = [
//   { num: "99", suffix: ".99%",   label: "Uptime reliability"  },
//   { num: "20K", suffix: "+",     label: "Active billers"      },
//   { num: "₹",  suffix: "500Cr+", label: "Transactions/month"  },
// ];

// ─── Feature cards ─────────────────────────────────────────────────────────────
export const FEATURES = [
  {
    icon: "⚙️",
    title: "Turning Gears",
    desc: "Modular architecture that adapts to your business scale with automated precision and zero-latency processing across all transaction types.",
  },
  {
    icon: "🛡️",
    title: "Secure System",
    desc: "Bank-grade encryption paired with biometric authentication protocols using AES-256 to ensure your data and funds remain impenetrable.",
  },
  {
    icon: "✅",
    title: "Trusted Platform",
    desc: "Compliant with all global financial standards, serving thousands of enterprises with 99.99% uptime reliability and instant failover.",
  },
];

// ─── Numbers grid ──────────────────────────────────────────────────────────────
export const NUMBERS = [
  { val: "99.99%",  color: "secondary", label: "Transaction Success Rate" },
  { val: "20,000+", color: "primary",   label: "BBPS Billers"             },
  { val: "₹500Cr+", color: "warning",   label: "Monthly Volume"           },
  { val: "<200ms",  color: "secondary", label: "Settlement Latency"       },
];

// ─── Transaction flow nodes ────────────────────────────────────────────────────
export const FLOW_NODES = [
  { icon: "💳", title: "Payment Initiated",   sub: "Customer triggers transaction",   val: "0ms",   highlight: false },
  { icon: "🔐", title: "Auth & Verification", sub: "Biometric + AES-256 validation",  val: "12ms",  highlight: false },
  { icon: "⚡", title: "Instant Settlement",  sub: "Funds cleared in real-time",      val: "180ms", highlight: true  },
];

// ─── Services cards ────────────────────────────────────────────────────────────
export const SERVICES = [
  {
    icon: "🏦", color: "primary", title: "Banking",
    items: ["Money Transfer","AEPS", "Micro ATM", "Cash Deposit"],
    btnLabel: "Explore Banking", featured: false,
  },
  {
    icon: "📋", color: "secondary", title: "BBPS",
    items: ["Utility Bill Payments", "Insurance Premiums", "Fastag Recharge", "Gas & Water Bills"],
    btnLabel: "Get It Now", featured: true,
  },
  {
    icon: "✈️", color: "warning", title: "Travel",
    items: ["Flight Booking", "Hotel Reservation", "Bus Ticketing", "IRCTC Agent Services"],
    btnLabel: "Explore Travel", featured: false,
  },
];

// ─── BBPS utility grid ─────────────────────────────────────────────────────────
export const BBPS_UTILITIES = [
  { icon: "⚡", label: "Electricity"     },
  { icon: "💧", label: "Water & Gas"    },
  { icon: "📡", label: "Broadband"      },
  { icon: "🎓", label: "Education Fees" },
];

// ─── About ecosystem cards ─────────────────────────────────────────────────────
export const ECO_CARDS = [
  { icon: "💸", title: "Money Transfer",        desc: "Instant domestic remittances with end-to-end encryption and real-time status tracking.", color: "primary"   },
  { icon: "🔍", title: "AEPS",       desc: "Biometric-enabled banking: withdraw, deposit and check balances using just Aadhaar.",   color: "secondary" },
  { icon: "📋", title: "BBPS",                  desc: "Unified bill payment for electricity, water, gas and telecom through a single interface.", color: "primary"  },
  { icon: "🏧", title: "Matm",                  desc: "Transform any smartphone into a Micro-ATM point for debit card cash withdrawals.",        color: "warning"  },
  { icon: "✈️", title: "Travel",                desc: "Integrated booking engine for flights, trains and buses with competitive agent margins.",  color: "warning"  },
  { icon: "🤝", title: "Business Correspondent",desc: "Official banking representative status enabling comprehensive branchless banking.",        color: "primary"  },
];

// ─── About vision stats ────────────────────────────────────────────────────────
export const VISION_STATS = [
  { icon: "📊", text: "99.99% Transaction Success Rate" },
  { icon: "⚡", text: "Real-time Settlement Systems"    },
  { icon: "📍", text: "Hyper-local Agent Connectivity"  },
];
