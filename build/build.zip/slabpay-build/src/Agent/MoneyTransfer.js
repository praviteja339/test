import { useState } from "react";
import { Box, Typography, TextField, Button, Paper, Grid, MenuItem } from "@mui/material";
import { C, cardStyle, inputStyle, btnPrimary, btnOutline } from "./lightStyles";
import SendIcon from "@mui/icons-material/Send";

const BENEFICIARIES = [
  { id: 1, name: "Suresh Babu",  bank: "SBI",   acc: "****4521", ifsc: "SBIN0001234" },
  { id: 2, name: "Meena Devi",   bank: "HDFC",  acc: "****8832", ifsc: "HDFC0001122" },
];

export default function AgentMoneyTransfer() {
  const [amount, setAmount] = useState("");
  const [selected, setSelected] = useState("");
  const [success, setSuccess] = useState(false);

  const handleSend = () => { if (amount && selected) setSuccess(true); };

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ background: "linear-gradient(135deg,#e8efff,#f0f5ff)", borderRadius: "14px", px: 3, py: 1.5, mb: 2, borderLeft: "4px solid #1a56db", display: "flex", alignItems: "center" }}>
        <Typography sx={{ fontSize: 11, fontWeight: 700, letterSpacing: "2px", textTransform: "uppercase", color: C.primary }}>Agent Portal — Slabpay</Typography>
      </Box>
      <Typography sx={{ fontSize: 20, fontWeight: 800, mb: 3, color: C.text1 }}>Money Transfer</Typography>

      {success ? (
        <Paper sx={{ ...cardStyle, textAlign: "center", py: 6, maxWidth: 480 }}>
          <Box sx={{ fontSize: 56, mb: 2 }}>✅</Box>
          <Typography sx={{ fontSize: 20, fontWeight: 800, color: C.text1, mb: 1 }}>Transfer Successful!</Typography>
          <Typography sx={{ fontSize: 14, color: C.text3, mb: 3 }}>₹{amount} sent successfully.</Typography>
          <Button onClick={() => { setSuccess(false); setAmount(""); setSelected(""); }} sx={{ ...btnPrimary, height: 42, px: 4 }}>New Transfer</Button>
        </Paper>
      ) : (
        <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", lg: "1fr 380px" }, gap: 2 }}>
          <Paper sx={cardStyle}>
            <Typography sx={{ fontSize: 15, fontWeight: 700, color: C.text1, mb: 2.5, pb: 2, borderBottom: `1px solid ${C.border}` }}>Transfer Details</Typography>
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <TextField label="Sender Mobile No." fullWidth sx={inputStyle} />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField label="Sender Name" fullWidth sx={inputStyle} />
              </Grid>
              <Grid item xs={12}>
                <TextField select label="Select Beneficiary" value={selected} onChange={e => setSelected(e.target.value)} fullWidth sx={inputStyle}>
                  {BENEFICIARIES.map(b => (
                    <MenuItem key={b.id} value={b.id}>{b.name} — {b.bank} ({b.acc})</MenuItem>
                  ))}
                </TextField>
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField label="Amount (₹)" type="number" value={amount} onChange={e => setAmount(e.target.value)} fullWidth sx={inputStyle} />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField select label="Transfer Mode" fullWidth sx={inputStyle}>
                  <MenuItem value="imps">IMPS — Instant</MenuItem>
                  <MenuItem value="neft">NEFT</MenuItem>
                  <MenuItem value="rtgs">RTGS</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12}>
                <TextField label="Remarks (Optional)" fullWidth sx={inputStyle} />
              </Grid>
              <Grid item xs={12}>
                <Box sx={{ display: "flex", gap: 1.5, justifyContent: "flex-end" }}>
                  <Button sx={{ ...btnOutline, height: 42, px: 3 }}>Clear</Button>
                  <Button onClick={handleSend} startIcon={<SendIcon />} sx={{ ...btnPrimary, height: 42, px: 4 }}>Send Money</Button>
                </Box>
              </Grid>
            </Grid>
          </Paper>

          <Paper sx={cardStyle}>
            <Typography sx={{ fontSize: 14, fontWeight: 700, color: C.text1, mb: 2 }}>Saved Beneficiaries</Typography>
            <Box sx={{ display: "flex", flexDirection: "column", gap: 1.5 }}>
              {BENEFICIARIES.map(b => (
                <Box key={b.id} onClick={() => setSelected(b.id)} sx={{ p: 2, borderRadius: "12px", background: selected === b.id ? C.primaryLight : C.surface2, border: `1.5px solid ${selected === b.id ? C.primary : C.border}`, cursor: "pointer", transition: "all 0.18s ease" }}>
                  <Typography sx={{ fontSize: 13, fontWeight: 700, color: selected === b.id ? C.primary : C.text1 }}>{b.name}</Typography>
                  <Typography sx={{ fontSize: 12, color: C.text3, mt: 0.3 }}>{b.bank} · {b.acc} · {b.ifsc}</Typography>
                </Box>
              ))}
            </Box>
            <Box sx={{ mt: 3, p: 2.5, background: C.primaryLight, borderRadius: "12px", border: `1px solid ${C.border}` }}>
              <Typography sx={{ fontSize: 12, fontWeight: 700, color: C.text1, mb: 0.5 }}>Daily Limit</Typography>
              <Typography sx={{ fontSize: 20, fontWeight: 800, color: C.primary }}>₹25,000</Typography>
              <Typography sx={{ fontSize: 11, color: C.text3, mt: 0.3 }}>₹18,500 remaining today</Typography>
            </Box>
          </Paper>
        </Box>
      )}
    </Box>
  );
}
