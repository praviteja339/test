import { useState, useEffect } from "react";
import { Box, Typography, Button } from "@mui/material";
import { Download, Add } from "@mui/icons-material";
import { BarChart as ReBarChart, Bar, XAxis, ResponsiveContainer, Tooltip as RTooltip } from "recharts";
import { C } from "./lightStyles";

const statCards = [
  { ico: "₹",  label: "Current Balance",     value: "1,240.50", sub: "Updated just now",       accent: C.primary,    accentLight: C.primaryLight,   tag: "Live"   },
  { ico: "↓",  label: "Today Cr. Balance",   value: "320.00",   sub: "3 credits today",          accent: C.secondary,  accentLight: C.secondaryLight, tag: "Today"  },
  { ico: "↑",  label: "Today Dr. Balance",   value: "80.00",    sub: "1 debit today",            accent: C.danger,     accentLight: C.dangerLight,    tag: "Today"  },
  { ico: "🏧", label: "Wallet Balance",       value: "560.25",   sub: "+₹25.00 this week",        accent: C.warning,    accentLight: C.warningLight,   tag: "+₹25"  },
];

const quickActions = [
  { emoji: "💸", label: "Money Transfer",    accent: C.primary    },
  { emoji: "🏧", label: "Micro ATM",         accent: C.secondary  },
  { emoji: "📋", label: "BBPS Payments",     accent: C.cyan       },
  { emoji: "🆔", label: "AEPS",   accent: C.purple     },
  { emoji: "✈️", label: "Travel Booking",    accent: C.warning    },
  { emoji: "📱", label: "Mobile Recharge",   accent: C.danger     },
  { emoji: "⚡", label: "Electricity Bill",  accent: "#d97706"    },
  { emoji: "💧", label: "Water Bill",        accent: C.cyan       },
  { emoji: "🔒", label: "Change Password",   accent: C.text3      },
];

const transactions = [
  { emoji: "💸", name: "Money Transfer",   date: "Today · 10:22 AM",   amt: "+₹320.00", type: "cr" },
  { emoji: "🏧", name: "Micro ATM Txn",    date: "Today · 09:05 AM",   amt: "−₹80.00",  type: "dr" },
  { emoji: "📋", name: "BBPS Bill Paid",   date: "Yesterday · 04:30 PM", amt: "+₹12.00", type: "cr" },
  { emoji: "💼", name: "Commission Credit", date: "Mar 28 · 11:00 AM",  amt: "+₹18.50", type: "cr" },
  { emoji: "📥", name: "Wallet Top-Up",    date: "Mar 27 · 02:00 PM",  amt: "+₹500.00", type: "cr" },
];

const weeklyData = [
  { day: "Mon", credits: 320, debits: 80  },
  { day: "Tue", credits: 450, debits: 120 },
  { day: "Wed", credits: 210, debits: 60  },
  { day: "Thu", credits: 580, debits: 200 },
  { day: "Fri", credits: 140, debits: 40  },
  { day: "Sat", credits: 390, debits: 90  },
  { day: "Sun", credits: 80,  debits: 20  },
];

const quickAccess = [
  { emoji: "📊", name: "Ledger Statement",   sub: "View full ledger history",   accent: C.primary   },
  { emoji: "🧾", name: "Transaction Report", sub: "Daily summary",              accent: C.purple    },
  { emoji: "💰", name: "Commission Report",  sub: "Monthly earnings",           accent: C.warning   },
  { emoji: "🔐", name: "Security Settings",  sub: "Password · M-Pin",           accent: C.danger    },
  { emoji: "📞", name: "Support",            sub: "Contact help desk",          accent: C.cyan      },
];

function StatCard({ card }) {
  return (
    <Box sx={{
      background: C.surface, border: `1px solid ${C.border}`, borderRadius: "16px",
      p: "20px", position: "relative", overflow: "hidden", cursor: "pointer",
      transition: "all 0.25s ease",
      "&:hover": { transform: "translateY(-4px)", boxShadow: "0 12px 32px rgba(15,22,35,0.1)", borderColor: C.border2 },
      "&::before": { content: '""', position: "absolute", top: 0, right: 0, width: 100, height: 100, borderRadius: "50%", background: card.accent, opacity: 0.07, transform: "translate(30%,-30%)" },
    }}>
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", mb: 2 }}>
        <Box sx={{ width: 40, height: 40, borderRadius: "12px", background: card.accentLight, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, fontWeight: 800, color: card.accent }}>{card.ico}</Box>
        <Box sx={{ fontSize: 10, fontWeight: 700, px: 1.5, py: 0.5, borderRadius: "20px", background: card.accentLight, color: card.accent }}>{card.tag}</Box>
      </Box>
      <Typography sx={{ fontSize: 11, fontWeight: 600, letterSpacing: "1px", textTransform: "uppercase", color: C.text3, mb: 0.5 }}>{card.label}</Typography>
      <Typography sx={{ fontSize: 26, fontWeight: 800, color: card.accent, letterSpacing: "-1px" }}>₹{card.value}</Typography>
      <Typography sx={{ fontSize: 12, color: C.text3, mt: 0.5 }}>{card.sub}</Typography>
    </Box>
  );
}

export default function AgentDashboard() {
  const [clock, setClock] = useState("");
  useEffect(() => {
    const tick = () => setClock(new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", second: "2-digit" }));
    tick(); const id = setInterval(tick, 1000); return () => clearInterval(id);
  }, []);

  return (
    <Box sx={{ p: "28px 28px 48px", background: "#f8faff", minHeight: "100%" }}>

      {/* Live ticker */}
      <Box sx={{ display: "flex", alignItems: "center", gap: 2, background: C.surface, border: `1px solid ${C.border}`, borderRadius: "12px", px: 2.5, py: 1.5, mb: 3, boxShadow: "0 1px 4px rgba(15,22,35,0.05)" }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1, background: C.primaryLight, borderRadius: "8px", px: 1.2, py: 0.5, flexShrink: 0 }}>
          <Box sx={{ width: 6, height: 6, borderRadius: "50%", background: C.primary, animation: "pulse 2s infinite", "@keyframes pulse": { "0%,100%": { opacity: 1 }, "50%": { opacity: 0.4 } } }} />
          <Typography sx={{ fontSize: 10, fontWeight: 700, color: C.primary, letterSpacing: "1px" }}>LIVE</Typography>
        </Box>
        <Typography sx={{ fontSize: 13, color: C.text2 }}>
          Agent ID: <strong style={{ color: C.text1 }}>A-SLABPAY-2041</strong>
          <span style={{ color: C.text3, margin: "0 6px" }}>·</span>
          <strong style={{ color: C.text1 }}>Ravi Kumar</strong>
          <span style={{ color: C.text3, margin: "0 6px" }}>·</span>
          Last login: Today 08:30 AM · Session active
        </Typography>
        <Typography sx={{ ml: "auto", fontSize: 12, color: C.text3, flexShrink: 0, fontWeight: 700 }}>{clock}</Typography>
      </Box>

      {/* Header */}
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", mb: 3 }}>
        <Box>
          <Typography sx={{ fontSize: 24, fontWeight: 800, color: C.text1, letterSpacing: "-0.5px" }}>
            Good Morning, <span style={{ color: C.primary }}>Ravi Kumar</span> 👋
          </Typography>
          <Typography sx={{ fontSize: 14, color: C.text3, mt: 0.5 }}>Here's your agent activity summary for today.</Typography>
        </Box>
        <Box sx={{ display: "flex", gap: 1.5 }}>
          <Button startIcon={<Download sx={{ fontSize: "14px !important" }} />} sx={{ background: C.surface, border: `1px solid ${C.border2}`, color: C.text2, borderRadius: "10px", px: 2, py: 1, fontSize: 13, fontWeight: 600, textTransform: "none", "&:hover": { background: C.surface3 } }}>Export</Button>
          <Button startIcon={<Add sx={{ fontSize: "14px !important" }} />} sx={{ background: `linear-gradient(135deg, ${C.primary}, #3b7af7)`, color: "#fff", borderRadius: "10px", px: 2, py: 1, fontSize: 13, fontWeight: 600, textTransform: "none", boxShadow: "0 4px 14px rgba(26,86,219,0.3)", "&:hover": { boxShadow: "0 6px 20px rgba(26,86,219,0.45)", transform: "translateY(-1px)" } }}>New Transaction</Button>
        </Box>
      </Box>

      {/* Stat Cards */}
      <Box sx={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 2, mb: 3 }}>
        {statCards.map((card, i) => <StatCard key={i} card={card} />)}
      </Box>

      {/* Quick Actions */}
      <Box sx={{ display: "flex", alignItems: "center", gap: 2, mb: 2 }}>
        <Typography sx={{ fontSize: 14, fontWeight: 700, color: C.text1, whiteSpace: "nowrap" }}>Quick Actions</Typography>
        <Box sx={{ flex: 1, height: 1, background: C.border }} />
      </Box>
      <Box sx={{ display: "grid", gridTemplateColumns: "repeat(9,1fr)", gap: 1.5, mb: 3 }}>
        {quickActions.map((item, i) => (
          <Box key={i} sx={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: "14px", p: "16px 8px", display: "flex", flexDirection: "column", alignItems: "center", gap: 1, cursor: "pointer", transition: "all 0.2s ease", "&:hover": { transform: "translateY(-5px)", boxShadow: "0 10px 28px rgba(15,22,35,0.1)", borderColor: item.accent } }}>
            <Box sx={{ width: 44, height: 44, borderRadius: "13px", background: `${item.accent}15`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 }}>{item.emoji}</Box>
            <Typography sx={{ fontSize: 11, fontWeight: 500, color: C.text2, textAlign: "center", lineHeight: 1.3 }}>{item.label}</Typography>
          </Box>
        ))}
      </Box>

      {/* Activity & Transactions */}
      <Box sx={{ display: "flex", alignItems: "center", gap: 2, mb: 2 }}>
        <Typography sx={{ fontSize: 14, fontWeight: 700, color: C.text1, whiteSpace: "nowrap" }}>Activity & Transactions</Typography>
        <Box sx={{ flex: 1, height: 1, background: C.border }} />
        <Typography sx={{ fontSize: 12, color: C.primary, cursor: "pointer", whiteSpace: "nowrap", fontWeight: 600 }}>View Reports →</Typography>
      </Box>

      <Box sx={{ display: "grid", gridTemplateColumns: "1fr 1fr 320px", gap: 2 }}>
        {/* Transactions */}
        <Box sx={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: "16px", p: 3 }}>
          <Box sx={{ display: "flex", justifyContent: "space-between", mb: 2.5 }}>
            <Typography sx={{ fontSize: 14, fontWeight: 700, color: C.text1 }}>Recent Transactions</Typography>
            <Typography sx={{ fontSize: 12, color: C.primary, cursor: "pointer", fontWeight: 600 }}>See all →</Typography>
          </Box>
          <Box sx={{ display: "flex", flexDirection: "column", gap: 0.5 }}>
            {transactions.map((tx, i) => (
              <Box key={i} sx={{ display: "flex", alignItems: "center", gap: 1.5, px: 1, py: 1.2, borderRadius: "10px", cursor: "pointer", transition: "background 0.15s", "&:hover": { background: C.surface2 } }}>
                <Box sx={{ width: 36, height: 36, borderRadius: "10px", background: tx.type === "cr" ? C.secondaryLight : C.dangerLight, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15, flexShrink: 0 }}>{tx.emoji}</Box>
                <Box sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 13.5, fontWeight: 600, color: C.text1 }}>{tx.name}</Typography>
                  <Typography sx={{ fontSize: 11.5, color: C.text3 }}>{tx.date}</Typography>
                </Box>
                <Typography sx={{ fontSize: 13.5, fontWeight: 700, color: tx.type === "cr" ? C.secondary : C.danger }}>{tx.amt}</Typography>
              </Box>
            ))}
          </Box>
        </Box>

        {/* Weekly Chart */}
        <Box sx={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: "16px", p: 3 }}>
          <Box sx={{ display: "flex", justifyContent: "space-between", mb: 2 }}>
            <Typography sx={{ fontSize: 14, fontWeight: 700, color: C.text1 }}>Weekly Activity</Typography>
            <Typography sx={{ fontSize: 12, color: C.primary, cursor: "pointer", fontWeight: 600 }}>This Week ↓</Typography>
          </Box>
          <Box sx={{ display: "flex", gap: 2, mb: 1.5 }}>
            {[{ color: C.primary, label: "Credits" }, { color: C.danger, label: "Debits" }].map(l => (
              <Box key={l.label} sx={{ display: "flex", alignItems: "center", gap: 0.8 }}>
                <Box sx={{ width: 8, height: 8, borderRadius: "3px", background: l.color }} />
                <Typography sx={{ fontSize: 11.5, color: C.text3 }}>{l.label}</Typography>
              </Box>
            ))}
          </Box>
          <ResponsiveContainer width="100%" height={130}>
            <ReBarChart data={weeklyData} barCategoryGap="20%" barGap={3}>
              <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: C.text3 }} />
              <RTooltip contentStyle={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 8, fontSize: 12 }} cursor={{ fill: `${C.primary}0d` }} />
              <Bar dataKey="credits" fill={C.primary} radius={[4, 4, 0, 0]} />
              <Bar dataKey="debits" fill={C.danger} radius={[4, 4, 0, 0]} />
            </ReBarChart>
          </ResponsiveContainer>
          <Box sx={{ display: "flex", gap: 1, mt: 2 }}>
            {[{ label: "Total Credits", value: "₹2,170.00", color: C.primary, bg: C.primaryLight }, { label: "Total Debits", value: "₹610.00", color: C.danger, bg: C.dangerLight }].map(b => (
              <Box key={b.label} sx={{ flex: 1, borderRadius: "12px", p: 1.5, background: b.bg }}>
                <Typography sx={{ fontSize: 10.5, fontWeight: 600, color: C.text3, textTransform: "uppercase", letterSpacing: "0.8px", mb: 0.5 }}>{b.label}</Typography>
                <Typography sx={{ fontSize: 17, fontWeight: 800, color: b.color }}>{b.value}</Typography>
              </Box>
            ))}
          </Box>
        </Box>

        {/* Quick Access */}
        <Box sx={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: "16px", p: 3 }}>
          <Typography sx={{ fontSize: 14, fontWeight: 700, color: C.text1, mb: 2 }}>Quick Access</Typography>
          <Box sx={{ display: "flex", flexDirection: "column", gap: 1.5 }}>
            {quickAccess.map((item, i) => (
              <Box key={i} sx={{ display: "flex", alignItems: "center", gap: 1.5, p: 1.5, borderRadius: "12px", background: C.surface2, border: `1px solid ${C.border}`, cursor: "pointer", transition: "all 0.2s", "&:hover": { borderColor: item.accent, transform: "translateX(4px)", boxShadow: "0 4px 12px rgba(15,22,35,0.06)" } }}>
                <Box sx={{ width: 36, height: 36, borderRadius: "10px", background: `${item.accent}18`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 17, flexShrink: 0 }}>{item.emoji}</Box>
                <Box sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: 13, fontWeight: 600, color: C.text1 }}>{item.name}</Typography>
                  <Typography sx={{ fontSize: 11.5, color: C.text3 }}>{item.sub}</Typography>
                </Box>
                <Typography sx={{ color: C.text3, fontSize: 18, lineHeight: 1 }}>›</Typography>
              </Box>
            ))}
          </Box>
        </Box>
      </Box>
    </Box>
  );
}
