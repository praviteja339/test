import { Box, Typography, TextField, Button, Grid, Paper } from "@mui/material";
import DownloadIcon from "@mui/icons-material/Download";
import SearchIcon from "@mui/icons-material/Search";
import { C, cardStyle, statCard, inputStyle, btnPrimary, btnOutline, tableHeader } from "./lightStyles";

export default function AgentHistory() {
  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ background: "linear-gradient(135deg,#e8efff,#f0f5ff)", borderRadius: "14px", px: 3, py: 1.5, mb: 2, borderLeft: "4px solid #1a56db", display: "flex", alignItems: "center" }}>
        <Typography sx={{ fontSize: 11, fontWeight: 700, letterSpacing: "2px", textTransform: "uppercase", color: C.primary }}>Agent Portal — Slabpay</Typography>
      </Box>
      <Typography sx={{ fontSize: 20, fontWeight: 800, mb: 3, color: C.text1 }}>Transaction History</Typography>
      <Grid container spacing={2} alignItems="center" mb={1}>
        <Grid item xs={12} md={3}><TextField type="date" label="From Date" InputLabelProps={{ shrink: true }} fullWidth sx={inputStyle} /></Grid>
        <Grid item xs={12} md={3}><TextField type="date" label="To Date" InputLabelProps={{ shrink: true }} fullWidth sx={inputStyle} /></Grid>
        <Grid item xs={12} md={3}><Button startIcon={<SearchIcon />} sx={btnPrimary} fullWidth>Get Data</Button></Grid>
        <Grid item xs={12} md={3} textAlign="right"><Button startIcon={<DownloadIcon />} sx={btnOutline}>Export Excel</Button></Grid>
      </Grid>
      <Grid container spacing={2} mt={0.5}>
        {[
          { label: "Total Transactions", value: "0",      accent: C.primary   },
          { label: "Total Credit",       value: "₹0.00",  accent: C.secondary },
          { label: "Total Debit",        value: "₹0.00",  accent: C.danger    },
          { label: "Net Balance",        value: "₹0.00",  accent: C.cyan      },
        ].map((item, i) => (
          <Grid item xs={12} md={3} key={i}>
            <Paper sx={{ ...statCard, borderLeft: `4px solid ${item.accent}` }}>
              <Typography sx={{ fontSize: 11, color: C.text3, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.5px" }}>{item.label}</Typography>
              <Typography sx={{ fontSize: 20, fontWeight: 800, color: item.accent, mt: 0.5 }}>{item.value}</Typography>
            </Paper>
          </Grid>
        ))}
      </Grid>
      <Paper sx={{ ...cardStyle, mt: 3 }}>
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2.5 }}>
          <Typography sx={{ fontWeight: 700, fontSize: 15, color: C.text1 }}>Transaction Details</Typography>
          <Box sx={{ px: 2, py: 0.5, borderRadius: "20px", background: C.primaryLight, fontSize: 12, color: C.primary, fontWeight: 700 }}>0 Records</Box>
        </Box>
        <Box sx={{ ...tableHeader, gridTemplateColumns: "1fr 1fr 2fr 1fr 1fr 1fr 1fr" }}>
          {["Txn ID", "Date", "Description", "Type", "Credit", "Debit", "Balance"].map(h => <span key={h}>{h}</span>)}
        </Box>
        <Box sx={{ textAlign: "center", py: 8, color: C.text3 }}>
          <Box sx={{ fontSize: 40, mb: 1 }}>📋</Box>
          <Typography sx={{ fontWeight: 600, color: C.text2 }}>No transactions found</Typography>
          <Typography sx={{ fontSize: 12, mt: 0.5 }}>Select date range and click Get Data</Typography>
        </Box>
      </Paper>
    </Box>
  );
}
