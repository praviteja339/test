import { useState } from "react";
import { Box, Typography, TextField, Button, Paper, Grid, MenuItem } from "@mui/material";
import { C, cardStyle, inputStyle, btnPrimary } from "./lightStyles";

const categories = ["Electricity", "Water", "Gas", "Broadband", "DTH", "Insurance", "Fastag", "Mobile Postpaid", "Education"];

export default function AgentBBPS() {
  const [category, setCategory] = useState("");
  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ background: "linear-gradient(135deg,#e8efff,#f0f5ff)", borderRadius: "14px", px: 3, py: 1.5, mb: 2, borderLeft: "4px solid #1a56db", display: "flex", alignItems: "center" }}>
        <Typography sx={{ fontSize: 11, fontWeight: 700, letterSpacing: "2px", textTransform: "uppercase", color: C.primary }}>Agent Portal — Slabpay</Typography>
      </Box>
      <Typography sx={{ fontSize: 20, fontWeight: 800, mb: 3, color: C.text1 }}>BBPS Payments</Typography>

      <Box sx={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 1.5, mb: 3 }}>
        {categories.map(cat => (
          <Box key={cat} onClick={() => setCategory(cat)} sx={{ p: 2, borderRadius: "12px", display: "flex", alignItems: "center", gap: 1.5, cursor: "pointer", background: category === cat ? C.primaryLight : C.surface2, border: `1.5px solid ${category === cat ? C.primary : C.border}`, transition: "all 0.18s" }}>
            <Box sx={{ fontSize: 22 }}>{{ "Electricity": "⚡", "Water": "💧", "Gas": "🔥", "Broadband": "📡", "DTH": "📺", "Insurance": "🛡️", "Fastag": "🚗", "Mobile Postpaid": "📱", "Education": "🎓" }[cat]}</Box>
            <Typography sx={{ fontSize: 13, fontWeight: 600, color: category === cat ? C.primary : C.text2 }}>{cat}</Typography>
          </Box>
        ))}
      </Box>

      {category && (
        <Paper sx={cardStyle}>
          <Typography sx={{ fontSize: 15, fontWeight: 700, color: C.text1, mb: 2.5, pb: 2, borderBottom: `1px solid ${C.border}` }}>Pay {category} Bill</Typography>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}><TextField label="Select Operator" select fullWidth sx={inputStyle}><MenuItem value="">— Select —</MenuItem></TextField></Grid>
            <Grid item xs={12} md={4}><TextField label="Consumer Number / ID" fullWidth sx={inputStyle} /></Grid>
            <Grid item xs={12} md={4}><TextField label="Mobile Number" fullWidth sx={inputStyle} /></Grid>
            <Grid item xs={12} md={4}>
              <Button sx={{ ...btnPrimary, height: 56, width: "100%" }}>Fetch Bill</Button>
            </Grid>
          </Grid>
        </Paper>
      )}
    </Box>
  );
}
