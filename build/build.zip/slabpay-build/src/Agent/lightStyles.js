export const C = {
  primary: "#1a56db",
  primaryLight: "#e8efff",
  secondary: "#0e9f6e",
  secondaryLight: "#e6faf3",
  danger: "#e02424",
  dangerLight: "#fde8e8",
  warning: "#d97706",
  warningLight: "#fef3c7",
  purple: "#7c3aed",
  purpleLight: "#ede9fe",
  cyan: "#0891b2",
  cyanLight: "#e0f2fe",
  surface: "#ffffff",
  surface2: "#f8faff",
  surface3: "#f0f4fb",
  border: "#e5eaf5",
  border2: "#d0d8ee",
  text1: "#0f1623",
  text2: "#3a4563",
  text3: "#7a8aab",
};

export const cardStyle = {
  background: "#ffffff",
  borderRadius: "16px",
  p: 3,
  border: "1px solid #e5eaf5",
  boxShadow: "0 1px 4px rgba(15,22,35,0.04)",
};

export const statCard = {
  background: "#f8faff",
  p: 2,
  borderRadius: "12px",
  border: "1px solid #e5eaf5",
};

export const inputStyle = {
  "& .MuiOutlinedInput-root": {
    background: "#ffffff",
    borderRadius: "10px",
    color: "#0f1623",
    "& fieldset": { borderColor: "#e5eaf5" },
    "&:hover fieldset": { borderColor: "#1a56db" },
    "&.Mui-focused fieldset": { borderColor: "#1a56db" },
  },
  "& .MuiInputLabel-root": { color: "#7a8aab" },
  "& .MuiSelect-icon": { color: "#7a8aab" },
  "& input": { color: "#0f1623" },
  "& input::-webkit-calendar-picker-indicator": { cursor: "pointer", opacity: 0.6 },
};

export const btnPrimary = {
  background: "linear-gradient(135deg, #1a56db, #3b7af7)",
  color: "#fff",
  height: "45px",
  borderRadius: "10px",
  textTransform: "none",
  fontWeight: 600,
  boxShadow: "0 4px 12px rgba(26,86,219,0.25)",
  "&:hover": { boxShadow: "0 6px 16px rgba(26,86,219,0.35)", transform: "translateY(-1px)" },
};

export const btnOutline = {
  color: "#3a4563",
  border: "1px solid #e5eaf5",
  background: "#ffffff",
  borderRadius: "10px",
  textTransform: "none",
  height: "45px",
  fontWeight: 600,
  "&:hover": { borderColor: "#1a56db", color: "#1a56db", background: "#e8efff" },
};

export const btnGreen = {
  background: "#e6faf3",
  color: "#0e9f6e",
  borderRadius: "10px",
  textTransform: "none",
  fontWeight: 600,
  "&:hover": { background: "#0e9f6e", color: "#fff" },
};

export const tableHeader = {
  display: "grid",
  borderBottom: "2px solid #f0f4fb",
  fontSize: 11,
  color: "#7a8aab",
  fontWeight: 700,
  letterSpacing: "0.5px",
  textTransform: "uppercase",
  paddingBottom: "10px",
  paddingTop: "4px",
};
