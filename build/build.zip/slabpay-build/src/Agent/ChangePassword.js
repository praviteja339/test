import { Box, Typography, TextField, Button, InputAdornment } from "@mui/material";
import LockIcon from "@mui/icons-material/Lock";
import { C, cardStyle, inputStyle, btnPrimary } from "./lightStyles";

export default function AgentChangePassword() {
  return (
    <Box sx={{ p: 4 }}>
      <Box sx={{ background: "linear-gradient(135deg,#e8efff,#f0f5ff)", borderRadius: "14px", px: 3, py: 1.5, mb: 3, borderLeft: "4px solid #1a56db" }}>
        <Typography sx={{ fontSize: 11, fontWeight: 700, letterSpacing: "2px", textTransform: "uppercase", color: C.primary }}>Agent Portal — Slabpay</Typography>
      </Box>
      <Typography sx={{ fontSize: 22, fontWeight: 800, mb: 3, color: C.text1 }}>Change Password</Typography>
      <Box sx={{ ...cardStyle, maxWidth: 640 }}>
        <Box sx={{ mb: 2.5 }}>
          <Box sx={{ width: 48, height: 48, borderRadius: "14px", background: C.primaryLight, display: "flex", alignItems: "center", justifyContent: "center", mb: 2 }}>
            <LockIcon sx={{ color: C.primary, fontSize: 24 }} />
          </Box>
          <Typography sx={{ fontSize: 14, color: C.text2, lineHeight: 1.6 }}>Password must be at least 8 characters with a mix of letters and numbers.</Typography>
        </Box>
        <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", md: "1fr 1fr" }, gap: 2 }}>
          {["Current Password", "New Password", "Re-Enter New Password"].map(label => (
            <TextField key={label} label={label} type="password" fullWidth sx={inputStyle}
              InputProps={{ startAdornment: <InputAdornment position="start"><LockIcon sx={{ color: C.text3, fontSize: 18 }} /></InputAdornment> }} />
          ))}
        </Box>
        <Box sx={{ mt: 3, display: "flex", justifyContent: "flex-end" }}>
          <Button sx={{ ...btnPrimary, height: "42px", px: 4 }}>Change Password</Button>
        </Box>
      </Box>
    </Box>
  );
}
