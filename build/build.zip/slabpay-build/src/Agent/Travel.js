import { useState } from "react";
import { Box, Typography, TextField, Button, Paper, Grid } from "@mui/material";
import { C, cardStyle, inputStyle, btnPrimary, btnOutline } from "./lightStyles";

export default function AgentTravel() {
  const [tab, setTab] = useState("flight");
  const tabs = [{ key: "flight", emoji: "✈️", label: "Flight" }, { key: "bus", emoji: "🚌", label: "Bus" }, { key: "hotel", emoji: "🏨", label: "Hotel" }, { key: "train", emoji: "🚂", label: "Train" }];
  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ background: "linear-gradient(135deg,#e8efff,#f0f5ff)", borderRadius: "14px", px: 3, py: 1.5, mb: 2, borderLeft: "4px solid #1a56db", display: "flex", alignItems: "center" }}>
        <Typography sx={{ fontSize: 11, fontWeight: 700, letterSpacing: "2px", textTransform: "uppercase", color: C.primary }}>Agent Portal — Slabpay</Typography>
      </Box>
      <Typography sx={{ fontSize: 20, fontWeight: 800, mb: 3, color: C.text1 }}>Travel Booking</Typography>
      <Box sx={{ display: "flex", gap: 1, mb: 3, p: 0.5, background: "#ffffff", borderRadius: "12px", border: `1px solid ${C.border}`, width: "fit-content" }}>
        {tabs.map(t => (
          <Box key={t.key} onClick={() => setTab(t.key)} sx={{ display: "flex", alignItems: "center", gap: 1, px: 2.5, py: 1.2, borderRadius: "10px", cursor: "pointer", background: tab === t.key ? C.primary : "transparent", color: tab === t.key ? "#fff" : C.text2, fontWeight: 700, fontSize: 14, transition: "all 0.18s" }}>
            <span>{t.emoji}</span>{t.label}
          </Box>
        ))}
      </Box>
      <Paper sx={cardStyle}>
        <Typography sx={{ fontSize: 15, fontWeight: 700, color: C.text1, mb: 2.5, pb: 2, borderBottom: `1px solid ${C.border}` }}>
          {{ flight: "Flight Search", bus: "Bus Search", hotel: "Hotel Search", train: "Train Search" }[tab]}
        </Typography>
        <Grid container spacing={2}>
          {tab === "flight" && <>
            <Grid item xs={12} md={3}><TextField label="From City" fullWidth sx={inputStyle} /></Grid>
            <Grid item xs={12} md={3}><TextField label="To City" fullWidth sx={inputStyle} /></Grid>
            <Grid item xs={12} md={2}><TextField type="date" label="Departure" InputLabelProps={{ shrink: true }} fullWidth sx={inputStyle} /></Grid>
            <Grid item xs={12} md={2}><TextField type="number" label="Passengers" defaultValue={1} fullWidth sx={inputStyle} /></Grid>
          </>}
          {tab === "bus" && <>
            <Grid item xs={12} md={3}><TextField label="From City" fullWidth sx={inputStyle} /></Grid>
            <Grid item xs={12} md={3}><TextField label="To City" fullWidth sx={inputStyle} /></Grid>
            <Grid item xs={12} md={3}><TextField type="date" label="Travel Date" InputLabelProps={{ shrink: true }} fullWidth sx={inputStyle} /></Grid>
          </>}
          {tab === "hotel" && <>
            <Grid item xs={12} md={3}><TextField label="City" fullWidth sx={inputStyle} /></Grid>
            <Grid item xs={12} md={3}><TextField type="date" label="Check In" InputLabelProps={{ shrink: true }} fullWidth sx={inputStyle} /></Grid>
            <Grid item xs={12} md={3}><TextField type="date" label="Check Out" InputLabelProps={{ shrink: true }} fullWidth sx={inputStyle} /></Grid>
          </>}
          {tab === "train" && <>
            <Grid item xs={12} md={3}><TextField label="From Station" fullWidth sx={inputStyle} /></Grid>
            <Grid item xs={12} md={3}><TextField label="To Station" fullWidth sx={inputStyle} /></Grid>
            <Grid item xs={12} md={3}><TextField type="date" label="Journey Date" InputLabelProps={{ shrink: true }} fullWidth sx={inputStyle} /></Grid>
          </>}
          <Grid item xs={12} md={2}>
            <Button sx={{ ...btnPrimary, height: 56, width: "100%" }}>Search</Button>
          </Grid>
        </Grid>
      </Paper>
    </Box>
  );
}
