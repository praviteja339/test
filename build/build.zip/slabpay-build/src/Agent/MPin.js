import { Box, Typography, TextField, Button, InputAdornment } from "@mui/material";
import LockIcon from "@mui/icons-material/Lock";
import { C, cardStyle, inputStyle, btnPrimary } from "./lightStyles";

export default function AgentMPin() {
  return (
    <Box sx={{ p: 4 }}>
      <Box sx={{ background: "linear-gradient(135deg,#e8efff,#f0f5ff)", borderRadius: "14px", px: 3, py: 1.5, mb: 3, borderLeft: "4px solid #1a56db" }}>
        <Typography sx={{ fontSize: 11, fontWeight: 700, letterSpacing: "2px", textTransform: "uppercase", color: C.primary }}>Agent Portal — Slabpay</Typography>
      </Box>
      <Typography sx={{ fontSize: 22, fontWeight: 800, mb: 3, color: C.text1 }}>Change M-Pin</Typography>
      <Box sx={{ ...cardStyle, maxWidth: 640 }}>
        <Box sx={{ mb: 2.5 }}>
          <Box sx={{ width: 48, height: 48, borderRadius: "14px", background: "#fef3c7", display: "flex", alignItems: "center", justifyContent: "center", mb: 2, fontSize: 22 }}>🔑</Box>
          <Typography sx={{ fontSize: 14, color: C.text2, lineHeight: 1.6 }}>Your M-Pin is a 4–6 digit numeric PIN used for quick transaction authentication.</Typography>
        </Box>
        <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", md: "1fr 1fr" }, gap: 2 }}>
          {["Current M-Pin", "New M-Pin", "Re-Enter M-Pin"].map(label => (
            <TextField key={label} label={label} type="password" inputProps={{ maxLength: 6 }} fullWidth sx={inputStyle}
              InputProps={{ startAdornment: <InputAdornment position="start"><LockIcon sx={{ color: C.text3, fontSize: 18 }} /></InputAdornment> }} />
          ))}
        </Box>
        <Box sx={{ mt: 3, display: "flex", justifyContent: "flex-end" }}>
          <Button sx={{ ...btnPrimary, height: "42px", px: 4 }}>Update M-Pin</Button>
        </Box>
      </Box>
    </Box>
  );
}
