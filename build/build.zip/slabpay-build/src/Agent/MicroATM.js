import { useState } from "react";
import { Box, Typography, TextField, Button, Paper, Grid } from "@mui/material";
import { C, cardStyle, inputStyle, btnPrimary } from "./lightStyles";

export default function AgentMicroATM() {
  const [txType, setTxType] = useState("withdrawal");
  const types = [
    { key: "withdrawal", label: "Cash Withdrawal", emoji: "💵" },
    { key: "balance",    label: "Balance Enquiry",  emoji: "🔍" },
    { key: "ministate",  label: "Mini Statement",   emoji: "📄" },
  ];
  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ background: "linear-gradient(135deg,#e8efff,#f0f5ff)", borderRadius: "14px", px: 3, py: 1.5, mb: 2, borderLeft: "4px solid #1a56db", display: "flex", alignItems: "center" }}>
        <Typography sx={{ fontSize: 11, fontWeight: 700, letterSpacing: "2px", textTransform: "uppercase", color: C.primary }}>Agent Portal — Slabpay</Typography>
      </Box>
      <Typography sx={{ fontSize: 20, fontWeight: 800, mb: 3, color: C.text1 }}>Micro ATM</Typography>
      <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", lg: "1fr 340px" }, gap: 2 }}>
        <Paper sx={cardStyle}>
          <Typography sx={{ fontSize: 14, fontWeight: 700, color: C.text1, mb: 2 }}>Transaction Type</Typography>
          <Box sx={{ display: "flex", gap: 1.5, mb: 3 }}>
            {types.map(t => (
              <Box key={t.key} onClick={() => setTxType(t.key)} sx={{ flex: 1, p: 2, borderRadius: "12px", textAlign: "center", cursor: "pointer", background: txType === t.key ? C.primaryLight : C.surface2, border: `1.5px solid ${txType === t.key ? C.primary : C.border}`, transition: "all 0.18s" }}>
                <Box sx={{ fontSize: 26, mb: 1 }}>{t.emoji}</Box>
                <Typography sx={{ fontSize: 12, fontWeight: 700, color: txType === t.key ? C.primary : C.text2 }}>{t.label}</Typography>
              </Box>
            ))}
          </Box>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}><TextField label="Card Number (Last 4 Digits)" fullWidth sx={inputStyle} inputProps={{ maxLength: 4 }} /></Grid>
            <Grid item xs={12} md={6}><TextField label="Cardholder Mobile" fullWidth sx={inputStyle} /></Grid>
            {txType === "withdrawal" && (
              <Grid item xs={12} md={6}><TextField label="Amount (₹)" type="number" fullWidth sx={inputStyle} /></Grid>
            )}
            <Grid item xs={12}>
              <Button sx={{ ...btnPrimary, height: 46, px: 5 }}>Proceed to OTP</Button>
            </Grid>
          </Grid>
        </Paper>
        <Paper sx={cardStyle}>
          <Typography sx={{ fontSize: 14, fontWeight: 700, color: C.text1, mb: 2 }}>Device Status</Typography>
          {[
            { label: "Device", value: "Connected", color: C.secondary },
            { label: "Network", value: "Strong", color: C.secondary },
            { label: "Today Transactions", value: "12", color: C.primary },
            { label: "Today Volume", value: "₹18,500", color: C.primary },
          ].map((s, i) => (
            <Box key={i} sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", py: 1.5, borderBottom: i < 3 ? `1px solid ${C.border}` : "none" }}>
              <Typography sx={{ fontSize: 13, color: C.text3 }}>{s.label}</Typography>
              <Typography sx={{ fontSize: 13, fontWeight: 700, color: s.color }}>{s.value}</Typography>
            </Box>
          ))}
        </Paper>
      </Box>
    </Box>
  );
}
