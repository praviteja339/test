import { Box, Typography, TextField, Button, Paper, Grid, MenuItem } from "@mui/material";
import { C, cardStyle, inputStyle, btnPrimary } from "./lightStyles";

export default function AgentAadhaar() {
  const services = [
    { key: "withdrawal", emoji: "💵", label: "Cash Withdrawal" },
    { key: "deposit",    emoji: "💰", label: "Cash Deposit"    },
    { key: "balance",    emoji: "🔍", label: "Balance Enquiry" },
    { key: "ministate",  emoji: "📄", label: "Mini Statement"  },
  ];
  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ background: "linear-gradient(135deg,#e8efff,#f0f5ff)", borderRadius: "14px", px: 3, py: 1.5, mb: 2, borderLeft: "4px solid #1a56db", display: "flex", alignItems: "center" }}>
        <Typography sx={{ fontSize: 11, fontWeight: 700, letterSpacing: "2px", textTransform: "uppercase", color: C.primary }}>Agent Portal — Slabpay</Typography>
      </Box>
      <Typography sx={{ fontSize: 20, fontWeight: 800, mb: 3, color: C.text1 }}>Aadhaar Banking (AEPS)</Typography>
      <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", md: "1fr 1fr" }, gap: 2 }}>
        <Paper sx={cardStyle}>
          <Typography sx={{ fontSize: 14, fontWeight: 700, color: C.text1, mb: 2 }}>Select Service</Typography>
          <Box sx={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 1.5, mb: 3 }}>
            {services.map(s => (
              <Box key={s.key} sx={{ p: 2, borderRadius: "12px", textAlign: "center", cursor: "pointer", background: C.primaryLight, border: `1px solid ${C.border}`, transition: "all 0.2s", "&:hover": { borderColor: C.primary, background: C.primaryLight } }}>
                <Box sx={{ fontSize: 28, mb: 1 }}>{s.emoji}</Box>
                <Typography sx={{ fontSize: 12, fontWeight: 700, color: C.primary }}>{s.label}</Typography>
              </Box>
            ))}
          </Box>
          <Grid container spacing={2}>
            <Grid item xs={12}><TextField label="Aadhaar Number" fullWidth sx={inputStyle} inputProps={{ maxLength: 12 }} /></Grid>
            <Grid item xs={12}><TextField select label="Bank Name" fullWidth sx={inputStyle}><MenuItem value="sbi">State Bank of India</MenuItem><MenuItem value="hdfc">HDFC Bank</MenuItem><MenuItem value="pnb">Punjab National Bank</MenuItem></TextField></Grid>
            <Grid item xs={12}><TextField label="Amount (₹)" type="number" fullWidth sx={inputStyle} /></Grid>
            <Grid item xs={12}><Button sx={{ ...btnPrimary, height: 46, px: 5 }}>Authenticate (Biometric)</Button></Grid>
          </Grid>
        </Paper>
        <Paper sx={{ ...cardStyle, background: "linear-gradient(135deg, #e8efff, #f0f5ff)" }}>
          <Typography sx={{ fontSize: 14, fontWeight: 700, color: C.text1, mb: 2 }}>AEPS Information</Typography>
          {[
            { label: "Service", value: "Aadhaar Enabled Payment System" },
            { label: "Authentication", value: "Biometric Fingerprint" },
            { label: "Network", value: "NPCI / UIDAI" },
            { label: "Daily Limit", value: "₹10,000" },
            { label: "Today Count", value: "5 transactions" },
          ].map((item, i) => (
            <Box key={i} sx={{ display: "flex", justifyContent: "space-between", py: 1.5, borderBottom: i < 4 ? `1px solid ${C.border}` : "none" }}>
              <Typography sx={{ fontSize: 13, color: C.text3 }}>{item.label}</Typography>
              <Typography sx={{ fontSize: 13, fontWeight: 700, color: C.text1 }}>{item.value}</Typography>
            </Box>
          ))}
        </Paper>
      </Box>
    </Box>
  );
}
