import { Routes, Route, Navigate } from 'react-router-dom';
import DistributorLayout from './Distributor/Layout';
import AgentLayout from './Agent/Layout';
import SuperDistributorLayout from './SuperDistributor/Layout';
import AdminLayout from "./Admin/Layout";
import Dashboard from './Dashboard/Dashboard';
import LoginPage from './pages/LoginPage';
import AdminLoginPage from './pages/AdminLoginPage';
import HomePage from './pages/HomePage';
import ServicesPage from './pages/ServicesPage';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';
import ProtectedRoute from './components/ProtectedRoute';

export default function Router() {
  return (
    <Routes>
      {/* ── Public routes ── */}
      <Route path="/"            element={<HomePage />} />
      <Route path="/services"    element={<ServicesPage />} />
      <Route path="/about"       element={<AboutPage />} />
      <Route path="/contact"     element={<ContactPage />} />
      <Route path="/login"       element={<LoginPage />} />
      <Route path="/admin/login" element={<AdminLoginPage />} />

      {/* ── Protected routes ── */}
      <Route
        path="/dashboard"
        element={
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        }
      />

      <Route
        path="/admin/*"
        element={
          <ProtectedRoute adminRoute>
            <AdminLayout />
          </ProtectedRoute>
        }
      />

      <Route
        path="/distributor/*"
        element={
          <ProtectedRoute>
            <DistributorLayout />
          </ProtectedRoute>
        }
      />

      <Route
        path="/agent/*"
        element={
          <ProtectedRoute>
            <AgentLayout />
          </ProtectedRoute>
        }
      />

      <Route
        path="/superdistributor/*"
        element={
          <ProtectedRoute>
            <SuperDistributorLayout />
          </ProtectedRoute>
        }
      />

      {/* ── Fallback ── */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
