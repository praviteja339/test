# SlabPay – CRA + MUI v5

Migrated from Vite to **Create React App** with **Material UI v5**.

## Requirements

- Node.js **16.x**
- npm **8.x**

## Getting Started

```bash
npm install
npm start
```

## Build

```bash
npm run build
```

## Key Changes from Original Vite Project

| Before (Vite)         | After (CRA + MUI)                        |
|-----------------------|------------------------------------------|
| `vite.config.js`      | Removed                                  |
| `src/main.jsx`        | `src/index.js`                           |
| `index.html` in root  | `public/index.html`                      |
| `"type": "module"`    | Removed from package.json                |
| Custom CSS files      | MUI `sx` prop + `GlobalStyles`           |
| `@vitejs/plugin-react`| Replaced with `react-scripts`            |
| No theme system       | MUI `ThemeProvider` with dark theme      |

## Tech Stack

- React 18
- MUI v5 (`@mui/material`, `@mui/icons-material`)
- Emotion (MUI peer dependency)
- CRA (react-scripts 5)
